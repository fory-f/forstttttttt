import React, { useState } from 'react';
import { Category, Tag, Topic } from '../../types';
import { api } from '../../services/api';
import { Hash, Tags, Plus, Trash2, Edit, CheckCircle, FolderPlus } from 'lucide-react';

interface TopicsViewProps {
  topics: Topic[];
  onRefresh: () => void;
}

export const TopicsView: React.FC<TopicsViewProps> = ({ topics, onRefresh }) => {
  const [showAdd, setShowAdd] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [keywords, setKeywords] = useState<string>('');
  const [priority, setPriority] = useState<Topic['priority']>('high');
  const [instructions, setInstructions] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleSave = async () => {
    if (!name.trim()) return;
    setIsSaving(true);
    try {
      await api.saveTopic({
        name,
        description,
        keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
        priority,
        enabled: true,
        instructions
      });
      setShowAdd(false);
      setName('');
      setDescription('');
      setKeywords('');
      setInstructions('');
      onRefresh();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete topic?')) return;
    try {
      await api.deleteTopic(id);
      onRefresh();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Hash className="w-6 h-6 text-indigo-400" />
            <span>Content Topics & Coverage Strategies</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Define strategic topical pillars, keyword clusters, and permanent instructions for Gemini generation.
          </p>
        </div>

        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>New Topic Pillar</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {topics.map((t) => (
          <div
            key={t.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                  Priority: {t.priority}
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>

              <h3 className="text-base font-bold text-white">{t.name}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{t.description}</p>

              {t.keywords && t.keywords.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-1">
                  {t.keywords.map((k, i) => (
                    <span key={i} className="text-[10px] bg-slate-950 text-indigo-300 px-2 py-0.5 rounded border border-slate-800">
                      {k}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => handleDelete(t.id)}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Delete topic"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Create Topic Pillar</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Topic Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Generative AI Infrastructure"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Target Keywords (comma separated)</label>
                <input
                  type="text"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  placeholder="llm inference, tensorrt, vllm"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAdd(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg"
              >
                Save Topic
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface TaxonomyViewProps {
  categories: Category[];
  tags: Tag[];
  onRefresh: () => void;
}

export const TaxonomyView: React.FC<TaxonomyViewProps> = ({
  categories,
  tags,
  onRefresh
}) => {
  const [showCatModal, setShowCatModal] = useState<boolean>(false);
  const [catName, setCatName] = useState<string>('');
  const [catSlug, setCatSlug] = useState<string>('');
  const [catDesc, setCatDesc] = useState<string>('');
  const [catSeoTitle, setCatSeoTitle] = useState<string>('');
  const [catSeoDesc, setCatSeoDesc] = useState<string>('');

  const [bulkTagsInput, setBulkTagsInput] = useState<string>('');
  const [isAddingTags, setIsAddingTags] = useState<boolean>(false);

  const handleSaveCat = async () => {
    if (!catName.trim()) return;
    try {
      await api.saveCategory({
        name: catName,
        slug: catSlug.trim() || catName.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'),
        description: catDesc,
        seoTitle: catSeoTitle || `${catName} Editorial Intelligence | EditorialPulse`,
        seoDescription: catSeoDesc || catDesc
      });
      setShowCatModal(false);
      setCatName('');
      setCatSlug('');
      setCatDesc('');
      onRefresh();
    } catch (err: any) {
      alert(`Failed to save category: ${err.message}`);
    }
  };

  const handleDeleteCat = async (id: string) => {
    if (!confirm('Permanently delete category?')) return;
    try {
      await api.deleteCategory(id);
      onRefresh();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleBulkAddTags = async () => {
    if (!bulkTagsInput.trim()) return;
    setIsAddingTags(true);
    try {
      await api.bulkAddTags(bulkTagsInput);
      setBulkTagsInput('');
      onRefresh();
    } catch (err: any) {
      alert(`Add tags failed: ${err.message}`);
    } finally {
      setIsAddingTags(false);
    }
  };

  const handleDeleteTag = async (id: string) => {
    try {
      await api.deleteTag(id);
      onRefresh();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <Tags className="w-6 h-6 text-indigo-400" />
          <span>Taxonomy Architecture (Categories & Tags)</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Maintain topical desks, crawlable archive hierarchies, and entity tags for semantic search engines.
        </p>
      </div>

      {/* Categories Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-base font-bold text-white">Topical Desks / Categories</h2>
          <button
            onClick={() => setShowCatModal(true)}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Category</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((c) => (
            <div key={c.id} className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-white text-sm">{c.name}</h3>
                  <span className="font-mono text-[10px] text-indigo-400">/category/{c.slug}</span>
                </div>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-2">{c.description}</p>
              </div>
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => handleDeleteCat(c.id)}
                  className="text-slate-500 hover:text-rose-400 p-1"
                  title="Delete category"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tags Section with Bulk Paste Parser */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-base font-bold text-white">Semantic Tag Entities ({tags.length})</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Bulk paste tags delimited by commas, semicolons, or newlines (Section 48).
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <textarea
              rows={2}
              value={bulkTagsInput}
              onChange={(e) => setBulkTagsInput(e.target.value)}
              placeholder="Paste comma or newline separated tags: ai-ethics, vector-db, semantic-web, rag-architecture"
              className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-600 focus:ring-2 focus:ring-indigo-600"
            />
            <button
              onClick={handleBulkAddTags}
              disabled={isAddingTags || !bulkTagsInput.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg self-start sm:self-auto"
            >
              Add Bulk Tags
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-2 max-h-72 overflow-y-auto">
            {tags.map((t) => (
              <span
                key={t.id}
                className="bg-slate-950 border border-slate-800 text-slate-300 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5"
              >
                <span>#{t.name}</span>
                <button
                  onClick={() => handleDeleteTag(t.id)}
                  className="text-slate-500 hover:text-rose-400 ml-1"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Category Modal */}
      {showCatModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Add Editorial Desk Category</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={catName}
                  onChange={(e) => {
                    setCatName(e.target.value);
                    setCatSlug(e.target.value.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'));
                  }}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Slug</label>
                <input
                  type="text"
                  value={catSlug}
                  onChange={(e) => setCatSlug(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Description</label>
                <textarea
                  rows={3}
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowCatModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCat}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg"
              >
                Save Category
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
