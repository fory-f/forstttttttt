import React, { useState, useEffect, useRef } from 'react';
import { api } from '../../services/api';
import { SiteSettings, AgentActivityLog } from '../../types';
import {
  Sparkles,
  Send,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  Search,
  Database,
  ShieldCheck,
  RefreshCw,
  Terminal,
  Brain
} from 'lucide-react';

interface MagicAgentViewProps {
  settings: SiteSettings;
  onRefreshAll: () => void;
  onOpenArticleEditor: (id?: string) => void;
  onOpenWorkflow: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
  actionProposal?: {
    actionType: string;
    description: string;
    targetTitle?: string;
    params?: any;
    status: 'pending' | 'approved' | 'rejected' | 'executed';
  };
}

export const MagicAgentView: React.FC<MagicAgentViewProps> = ({
  settings,
  onRefreshAll,
  onOpenArticleEditor,
  onOpenWorkflow
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      sender: 'agent',
      text: `Greetings. I am MAGIC, your editorial AI operating layer. I have live access to your database catalog, RSS queue, SEO scoring engine, and project memory. How can I assist your publication today?`,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [logs, setLogs] = useState<AgentActivityLog[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    api.getAgentLogs().then(setLogs).catch(() => {});
  }, []);

  const handleSend = async () => {
    if (!prompt.trim() || isLoading) return;
    const userText = prompt.trim();
    setPrompt('');

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await api.runMagicAgent({ userPrompt: userText });
      const agentMsg: ChatMessage = {
        id: `agt-${Date.now()}`,
        sender: 'agent',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString(),
        actionProposal: res.plannedAction
          ? {
              actionType: res.plannedAction.type,
              description: res.plannedAction.description || 'Approve requested operation',
              params: res.plannedAction.params,
              status: 'pending'
            }
          : undefined
      };
      setMessages((prev) => [...prev, agentMsg]);
      api.getAgentLogs().then(setLogs).catch(() => {});
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'agent',
          text: `Error executing command: ${err.message}`,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveAction = async (msgId: string, proposal: any) => {
    try {
      // Execute the approved action based on type
      if (proposal.actionType === 'create_article') {
        onOpenWorkflow();
      } else if (proposal.actionType === 'seo_audit') {
        alert('Catalog SEO audit complete. Review the Audit & AI Logs tab.');
      } else if (proposal.actionType === 'fetch_rss') {
        await api.fetchAllRSSSources();
        alert('RSS feeds polled and new items ingested into queue.');
        onRefreshAll();
      }

      setMessages((prev) =>
        prev.map((m) =>
          m.id === msgId && m.actionProposal
            ? { ...m, actionProposal: { ...m.actionProposal, status: 'executed' } }
            : m
        )
      );
    } catch (err: any) {
      alert(`Action execution failed: ${err.message}`);
    }
  };

  const handleRejectAction = (msgId: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === msgId && m.actionProposal
          ? { ...m, actionProposal: { ...m.actionProposal, status: 'rejected' } }
          : m
      )
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              MAGIC AI Operating Layer
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Autonomous editorial copilot with permissions enforcement, memory recall, and proposal approval gates.
          </p>
        </div>

        {/* Quick Prompt Starters */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setPrompt('Audit our published articles for missing meta descriptions and low SEO scores.')}
            className="text-[11px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 px-3 py-1.5 rounded-lg"
          >
            Audit Catalog SEO
          </button>
          <button
            onClick={() => setPrompt('Poll all RSS sources and report new editorial opportunities.')}
            className="text-[11px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 px-3 py-1.5 rounded-lg"
          >
            Poll RSS Signals
          </button>
          <button
            onClick={() => setPrompt('Draft a new article about semantic SEO architectures.')}
            className="text-[11px] bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 px-3 py-1.5 rounded-lg"
          >
            Draft New Dispatch
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Chat Interface */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[650px] shadow-md overflow-hidden">
          {/* Messages Container */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'agent' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white flex-shrink-0 mt-1">
                    <Sparkles className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-xl rounded-2xl p-4 text-xs leading-relaxed space-y-3 ${
                    msg.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-br-none'
                      : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-bl-none shadow-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Action Proposal Card with Approval Gate */}
                  {msg.actionProposal && (
                    <div className="bg-slate-900 border border-indigo-500/40 rounded-xl p-3.5 space-y-2 mt-2">
                      <div className="flex items-center gap-1.5 text-indigo-400 font-bold text-xs uppercase tracking-wider">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        <span>Action Proposal: {msg.actionProposal.actionType}</span>
                      </div>

                      <p className="text-slate-300 text-xs">{msg.actionProposal.description}</p>

                      {msg.actionProposal.status === 'pending' ? (
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                          <button
                            onClick={() => handleRejectAction(msg.id)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => handleApproveAction(msg.id, msg.actionProposal)}
                            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Approve & Execute</span>
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] font-bold text-emerald-400 pt-1">
                          Status: {msg.actionProposal.status.toUpperCase()}
                        </div>
                      )}
                    </div>
                  )}

                  <span className="text-[10px] text-slate-500 block text-right mt-1">
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3 items-center text-xs text-slate-400 py-2">
                <Sparkles className="w-4 h-4 text-indigo-400 animate-spin" />
                <span>MAGIC is reviewing catalog state and reasoning...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Bar */}
          <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              placeholder="Ask MAGIC to research, audit SEO, draft content, or execute workflow..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
            />
            <button
              onClick={handleSend}
              disabled={isLoading || !prompt.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white p-3 rounded-xl transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sidebar: Activity Logs & Permissions */}
        <div className="lg:col-span-4 space-y-6">
          {/* Autonomous Permissions Inspector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Permission Guardrails</span>
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              MAGIC requires explicit human confirmation before executing dangerous mutations (publishing, deleting records, altering settings).
            </p>
            <div className="space-y-2 text-xs pt-1">
              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-lg border border-slate-800">
                <span className="text-slate-300">Read & Audit Content</span>
                <span className="text-emerald-400 font-bold text-[11px]">ALLOWED</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-lg border border-slate-800">
                <span className="text-slate-300">Draft Articles</span>
                <span className="text-emerald-400 font-bold text-[11px]">ALLOWED</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-950 rounded-lg border border-slate-800">
                <span className="text-slate-300">Direct Auto-Publish</span>
                <span className="text-amber-400 font-bold text-[11px]">APPROVAL GATE</span>
              </div>
            </div>
          </div>

          {/* Activity Log Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span>Recent Activity Logs</span>
            </h3>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {logs.slice(0, 6).map((log) => (
                <div key={log.id} className="p-2.5 bg-slate-950 rounded-lg border border-slate-850 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span className="font-bold text-indigo-400">{log.action}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-slate-300 text-[11px] line-clamp-2">{log.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
