import React, { useState, useEffect, useRef } from 'react';
import { Article, Category, Tag, ArticleRevision, InternalLinkSuggestion } from '../../types';
import { api } from '../../services/api';
import {
  Save,
  Send,
  Sparkles,
  Search,
  Link,
  Image as ImageIcon,
  Bold,
  Italic,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Code,
  Undo,
  Redo,
  History,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Eye,
  Wand2,
  ArrowRight,
  Clock,
  Trash2
} from 'lucide-react';

interface ArticleEditorViewProps {
  articleId?: string | null;
  categories: Category[];
  tags: Tag[];
  onSaveSuccess: (saved: Article) => void;
  onNavigateCatalog: () => void;
  onNavigatePublic: (path: string) => void;
}

export const ArticleEditorView: React.FC<ArticleEditorViewProps> = ({
  articleId,
  categories,
  tags,
  onSaveSuccess,
  onNavigateCatalog,
  onNavigatePublic
}) => {
  // Main form fields
  const [id, setId] = useState<string | undefined>(articleId || undefined);
  const [title, setTitle] = useState<string>('');
  const [slug, setSlug] = useState<string>('');
  const [leadSummary, setLeadSummary] = useState<string>('');
  const [excerpt, setExcerpt] = useState<string>('');
  const [content, setContent] = useState<string>('<p></p>');
  const [categoryId, setCategoryId] = useState<string>(categories[0]?.id || 'cat-1');
  const [primaryFocusKeyword, setPrimaryFocusKeyword] = useState<string>('');
  const [secondaryKeywords, setSecondaryKeywords] = useState<string[]>([]);
  const [secondaryInput, setSecondaryInput] = useState<string>('');
  const [articleTags, setArticleTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState<string>('');
  const [featuredImage, setFeaturedImage] = useState<string>('https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=630&fit=crop&q=80');
  const [featuredImageAlt, setFeaturedImageAlt] = useState<string>('');
  const [seoTitle, setSeoTitle] = useState<string>('');
  const [metaDescription, setMetaDescription] = useState<string>('');
  const [canonicalUrl, setCanonicalUrl] = useState<string>('');
  const [status, setStatus] = useState<Article['status']>('draft');
  const [workflowStage, setWorkflowStage] = useState<number>(9);

  // Editor states
  const [isSourceMode, setIsSourceMode] = useState<boolean>(false);
  const [autosaveState, setAutosaveState] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<string>('');
  const editorRef = useRef<HTMLDivElement>(null);

  // SEO Analysis state
  const [seoAnalysis, setSeoAnalysis] = useState<Article['aiSeoAnalysis'] | null>(null);
  const [isAnalyzingSeo, setIsAnalyzingSeo] = useState<boolean>(false);

  // Link Insertion Modal state
  const [showLinkModal, setShowLinkModal] = useState<boolean>(false);
  const [linkUrl, setLinkUrl] = useState<string>('');
  const [linkOpenNewTab, setLinkOpenNewTab] = useState<boolean>(false);
  const [linkRel, setLinkRel] = useState<string>('');
  const [savedSelectionRange, setSavedSelectionRange] = useState<Range | null>(null);

  // AI Humanize Modal state
  const [showHumanizeModal, setShowHumanizeModal] = useState<boolean>(false);
  const [humanizeDiff, setHumanizeDiff] = useState<{ original: string; humanized: string; diffNotes: string[] } | null>(null);
  const [isHumanizing, setIsHumanizing] = useState<boolean>(false);

  // AI Section Refine state
  const [selectedSectionText, setSelectedSectionText] = useState<string>('');
  const [isRefiningSection, setIsRefiningSection] = useState<boolean>(false);

  // Internal link suggestions state
  const [linkSuggestions, setLinkSuggestions] = useState<InternalLinkSuggestion[]>([]);

  // Revision History state
  const [showRevisions, setShowRevisions] = useState<boolean>(false);
  const [revisions, setRevisions] = useState<ArticleRevision[]>([]);
  const [isLoadingRevs, setIsLoadingRevs] = useState<boolean>(false);

  // Load article if articleId provided
  useEffect(() => {
    if (articleId) {
      api.getArticle(articleId).then(art => {
        setId(art.id);
        setTitle(art.title);
        setSlug(art.slug);
        setLeadSummary(art.leadSummary || '');
        setExcerpt(art.excerpt || '');
        setContent(art.content || '<p></p>');
        setCategoryId(art.categoryId);
        setPrimaryFocusKeyword(art.primaryFocusKeyword || '');
        setSecondaryKeywords(art.secondaryKeywords || []);
        setArticleTags(art.tags || []);
        setFeaturedImage(art.featuredImage);
        setFeaturedImageAlt(art.featuredImageAlt || '');
        setSeoTitle(art.seoTitle || '');
        setMetaDescription(art.metaDescription || '');
        setCanonicalUrl(art.canonicalUrl || '');
        setStatus(art.status);
        setWorkflowStage(art.workflowStage || 9);
        setSeoAnalysis(art.aiSeoAnalysis || null);
        setLastSavedTime(new Date(art.updatedAt || art.createdAt).toLocaleTimeString());

        // Also fetch internal link suggestions
        api.suggestInternalLinks({ currentArticleId: art.id, currentContent: art.content })
          .then(setLinkSuggestions)
          .catch(() => {});
      }).catch(err => console.error('Failed to load article:', err));
    }
  }, [articleId]);

  // Sync content into editable div when in visual mode
  useEffect(() => {
    if (editorRef.current && !isSourceMode) {
      if (editorRef.current.innerHTML !== content) {
        editorRef.current.innerHTML = content;
      }
    }
  }, [content, isSourceMode]);

  // Live SEO scoring debounced
  useEffect(() => {
    const timer = setTimeout(() => {
      if (title.trim()) {
        setIsAnalyzingSeo(true);
        api.runSeoCheck({
          title,
          content,
          focusKeyword: primaryFocusKeyword,
          secondaryKeywords,
          metaDescription,
          slug
        }).then(res => {
          setSeoAnalysis(res);
        }).finally(() => setIsAnalyzingSeo(false));
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [title, content, primaryFocusKeyword, metaDescription, slug]);

  // Autosave periodically
  useEffect(() => {
    if (!title.trim()) return;
    setAutosaveState('unsaved');
    const saveTimer = setTimeout(() => {
      handleSave(status, false);
    }, 3000);
    return () => clearTimeout(saveTimer);
  }, [title, content, leadSummary, excerpt, primaryFocusKeyword, categoryId]);

  const handleSave = async (targetStatus: Article['status'] = status, notify = true) => {
    if (!title.trim()) {
      if (notify) alert('Please provide an article title.');
      return;
    }

    setAutosaveState('saving');
    try {
      const payload: Partial<Article> & { title: string } = {
        id,
        title,
        slug: slug.trim() || title.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'),
        leadSummary,
        excerpt: excerpt || leadSummary.slice(0, 150),
        content,
        categoryId,
        primaryFocusKeyword,
        secondaryKeywords,
        tags: articleTags,
        featuredImage,
        featuredImageAlt: featuredImageAlt || title,
        seoTitle: seoTitle || title,
        metaDescription: metaDescription || excerpt || leadSummary.slice(0, 155),
        canonicalUrl,
        status: targetStatus,
        workflowStage: 14,
        aiSeoScore: seoAnalysis?.score
      };

      const saved = await api.saveArticle(payload);
      setId(saved.id);
      setStatus(saved.status);
      setAutosaveState('saved');
      setLastSavedTime(new Date().toLocaleTimeString());
      if (notify) {
        onSaveSuccess(saved);
      }
    } catch (err: any) {
      setAutosaveState('unsaved');
      if (notify) alert(`Failed to save: ${err.message}`);
    }
  };

  // Editor formatting commands
  const execFormat = (command: string, value: string | undefined = undefined) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
  };

  // Link Insertion
  const openLinkDialog = () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      setSavedSelectionRange(sel.getRangeAt(0).cloneRange());
    }
    setShowLinkModal(true);
  };

  const applyLink = () => {
    if (!linkUrl.trim()) return;
    if (savedSelectionRange) {
      const sel = window.getSelection();
      sel?.removeAllRanges();
      sel?.addRange(savedSelectionRange);
    }

    const anchor = document.createElement('a');
    anchor.href = linkUrl;
    if (linkOpenNewTab) anchor.target = '_blank';
    if (linkRel) anchor.rel = linkRel;

    document.execCommand('createLink', false, linkUrl);

    // Update state
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
    setShowLinkModal(false);
    setLinkUrl('');
    setLinkRel('');
  };

  // Insert image modal
  const handleInsertImage = () => {
    const url = prompt('Enter Image URL:');
    if (url) {
      execFormat('insertImage', url);
    }
  };

  // Humanize It tool
  const runHumanize = async () => {
    // Check if selection exists, otherwise humanize entire content
    const sel = window.getSelection()?.toString();
    const textToHumanize = sel && sel.trim().length > 20 ? sel : content;

    setIsHumanizing(true);
    setShowHumanizeModal(true);
    try {
      const res = await api.humanizeContent({
        text: textToHumanize,
        focusKeyword: primaryFocusKeyword
      });
      setHumanizeDiff(res);
    } catch (err: any) {
      alert(`Humanize failed: ${err.message}`);
      setShowHumanizeModal(false);
    } finally {
      setIsHumanizing(false);
    }
  };

  const applyHumanizedContent = () => {
    if (!humanizeDiff) return;
    const sel = window.getSelection();
    if (sel && sel.toString().trim().length > 20) {
      document.execCommand('insertHTML', false, humanizeDiff.humanized);
      if (editorRef.current) setContent(editorRef.current.innerHTML);
    } else {
      setContent(humanizeDiff.humanized);
      if (editorRef.current) editorRef.current.innerHTML = humanizeDiff.humanized;
    }
    setShowHumanizeModal(false);
    setHumanizeDiff(null);
  };

  // Section Refinement
  const handleRefineSection = async (action: string) => {
    const sel = window.getSelection()?.toString();
    if (!sel || sel.trim().length === 0) {
      alert('Please highlight a section of text in the editor first.');
      return;
    }

    setIsRefiningSection(true);
    try {
      const res = await api.refineSection({
        sectionText: sel,
        action,
        focusKeyword: primaryFocusKeyword
      });
      document.execCommand('insertHTML', false, res.refined);
      if (editorRef.current) setContent(editorRef.current.innerHTML);
    } catch (err: any) {
      alert(`Refinement failed: ${err.message}`);
    } finally {
      setIsRefiningSection(false);
    }
  };

  // Internal link insertion from suggestions
  const insertInternalLink = (suggestion: InternalLinkSuggestion) => {
    const pattern = new RegExp(suggestion.anchorText, 'i');
    if (content.match(pattern)) {
      const replacement = `<a href="${suggestion.targetUrl}" title="${suggestion.targetTitle}">${suggestion.anchorText}</a>`;
      const updated = content.replace(pattern, replacement);
      setContent(updated);
      if (editorRef.current) editorRef.current.innerHTML = updated;
      // Remove suggestion from list
      setLinkSuggestions(prev => prev.filter(s => s.targetUrl !== suggestion.targetUrl));
    } else {
      // Append as related link reference at bottom
      const appendHtml = `<p>Related reading: <a href="${suggestion.targetUrl}">${suggestion.targetTitle}</a></p>`;
      const updated = content + appendHtml;
      setContent(updated);
      if (editorRef.current) editorRef.current.innerHTML = updated;
    }
  };

  // Bulk tag parsing
  const handleBulkTagAdd = () => {
    if (!tagInput.trim()) return;
    const newTags = tagInput
      .split(/[,;\n\r]+/)
      .map(t => t.trim())
      .filter(t => t.length > 0);
    const combined = Array.from(new Set([...articleTags, ...newTags]));
    setArticleTags(combined);
    setTagInput('');
  };

  const removeTag = (t: string) => {
    setArticleTags(articleTags.filter(item => item !== t));
  };

  // Version History
  const openRevisions = async () => {
    if (!id) {
      alert('Please save the article draft first to view revision history.');
      return;
    }
    setIsLoadingRevs(true);
    setShowRevisions(true);
    try {
      const revs = await api.getRevisions(id);
      setRevisions(revs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingRevs(false);
    }
  };

  const restoreRevision = async (revId: string) => {
    if (!id) return;
    if (!confirm('Restore this revision? A snapshot of current edits will be preserved.')) return;
    try {
      const restored = await api.restoreRevision(id, revId);
      setTitle(restored.title);
      setContent(restored.content);
      if (editorRef.current) editorRef.current.innerHTML = restored.content;
      setShowRevisions(false);
      alert('Revision restored successfully.');
    } catch (err: any) {
      alert(`Failed to restore: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onNavigateCatalog}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-medium"
          >
            &larr; Catalog
          </button>
          <span className="text-slate-600">|</span>
          <span className="text-xs text-slate-400">
            Status: <span className="font-bold text-white uppercase">{status}</span>
          </span>
          <span className="text-slate-600">&bull;</span>
          <div className="flex items-center gap-1.5 text-xs">
            <span
              className={`w-2 h-2 rounded-full ${
                autosaveState === 'saved'
                  ? 'bg-emerald-400'
                  : autosaveState === 'saving'
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-rose-400'
              }`}
            />
            <span className="text-slate-400 text-[11px]">
              {autosaveState === 'saved'
                ? `Saved ${lastSavedTime ? `at ${lastSavedTime}` : ''}`
                : autosaveState === 'saving'
                ? 'Autosaving changes...'
                : 'Unsaved changes'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={openRevisions}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-700 transition-colors"
            title="View revision history"
          >
            <History className="w-3.5 h-3.5 text-indigo-400" />
            <span>Revisions</span>
          </button>

          {id && status === 'published' && (
            <button
              onClick={() => onNavigatePublic(`/article/${slug}`)}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-700 transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-slate-400" />
              <span>View Public</span>
            </button>
          )}

          <button
            onClick={() => handleSave('draft', true)}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3.5 py-2 rounded-lg border border-slate-700 transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Draft</span>
          </button>

          <button
            onClick={() => handleSave('published', true)}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-lg shadow-sm transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish Article</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Column: Title, Content, Semantic HTML Editor */}
        <div className="lg:col-span-8 space-y-6">
          {/* Article Title */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Article Title (H1) <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (!id) {
                  setSlug(e.target.value.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'));
                }
              }}
              placeholder="e.g. Architecting Semantic SEO: Why Crawlable HTML Outranks SPAs"
              className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-lg font-bold text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 placeholder-slate-600"
            />
          </div>

          {/* Slug & Permalinks */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <label className="font-semibold">Canonical Slug:</label>
              <span className="font-mono text-[11px] text-indigo-400">/article/{slug || 'untitled'}</span>
            </div>
            <input
              type="text"
              value={slug}
              onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'))}
              placeholder="url-slug"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {/* Lead Summary Callout */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Editorial Lead Summary (2-Sentence Thesis)
            </label>
            <textarea
              rows={2}
              value={leadSummary}
              onChange={(e) => setLeadSummary(e.target.value)}
              placeholder="A concise, high-impact summary displayed prominently below the H1."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 leading-relaxed"
            />
          </div>

          {/* Semantic HTML WYSIWYG Editor */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <span>Main Article Content (Semantic HTML)</span>
              </label>

              {/* Source vs Visual Toggle */}
              <button
                type="button"
                onClick={() => setIsSourceMode(!isSourceMode)}
                className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 bg-slate-800 rounded border border-slate-700 transition-colors"
              >
                <Code className="w-3 h-3 text-indigo-400" />
                <span>{isSourceMode ? 'Visual Mode' : 'HTML Source'}</span>
              </button>
            </div>

            {/* Formatting Toolbar */}
            <div className="bg-slate-900 border border-slate-800 rounded-t-xl p-2 flex items-center flex-wrap gap-1 sticky top-16 z-20 shadow-sm">
              <button
                type="button"
                onClick={() => execFormat('bold')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Bold (Ctrl+B)"
              >
                <Bold className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => execFormat('italic')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Italic (Ctrl+I)"
              >
                <Italic className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-800 mx-1" />

              <button
                type="button"
                onClick={() => execFormat('formatBlock', '<h2>')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Subheading H2"
              >
                <Heading2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => execFormat('formatBlock', '<h3>')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Subheading H3"
              >
                <Heading3 className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-800 mx-1" />

              <button
                type="button"
                onClick={() => execFormat('insertUnorderedList')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Bullet List"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => execFormat('insertOrderedList')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Numbered List"
              >
                <ListOrdered className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => execFormat('formatBlock', '<blockquote>')}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Blockquote"
              >
                <Quote className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-800 mx-1" />

              <button
                type="button"
                onClick={openLinkDialog}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors flex items-center gap-1"
                title="Insert Link on Selected Text"
              >
                <Link className="w-4 h-4 text-indigo-400" />
                <span className="text-[11px]">Link</span>
              </button>

              <button
                type="button"
                onClick={handleInsertImage}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                title="Insert Inline Image"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-800 mx-1" />

              {/* AI Tools inside toolbar */}
              <button
                type="button"
                onClick={runHumanize}
                className="flex items-center gap-1 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-[11px] font-bold px-2.5 py-1 rounded shadow-xs ml-auto transition-all"
                title="Humanize Content (Eliminate AI clichés)"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>HUMANIZE IT</span>
              </button>

              {/* Section Refine Dropdown */}
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleRefineSection(e.target.value);
                    e.target.value = '';
                  }
                }}
                disabled={isRefiningSection}
                className="bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-semibold py-1 px-2 rounded focus:outline-hidden"
              >
                <option value="">Refine Selection...</option>
                <option value="rewrite">Rewrite clearly</option>
                <option value="expand">Expand with depth</option>
                <option value="shorten">Make concise</option>
                <option value="naturalize">Naturalize flow</option>
                <option value="improve_seo">Target focus keyword</option>
                <option value="convert_to_list">Convert to bullet list</option>
              </select>
            </div>

            {/* Editable Content Area */}
            {isSourceMode ? (
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={18}
                className="w-full bg-slate-950 border border-slate-800 rounded-b-xl p-4 font-mono text-xs text-indigo-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 leading-relaxed"
              />
            ) : (
              <div
                ref={editorRef}
                contentEditable
                onInput={(e) => setContent((e.target as HTMLDivElement).innerHTML)}
                className="w-full min-h-[420px] bg-slate-950 border border-slate-800 rounded-b-xl p-6 text-sm text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 leading-relaxed prose prose-invert prose-headings:font-bold prose-h2:text-xl prose-h2:mt-6 prose-h2:mb-3 prose-h3:text-lg prose-h3:mt-4 prose-h3:mb-2 prose-p:my-3 prose-p:leading-relaxed prose-blockquote:border-l-indigo-500 prose-a:text-indigo-400 prose-a:underline"
                style={{ outline: 'none' }}
              />
            )}
          </div>

          {/* Internal Link Recommendations Section */}
          {linkSuggestions.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Link className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Suggested Internal Anchors ({linkSuggestions.length})</span>
                </h4>
                <span className="text-[11px] text-slate-500">AI contextual link matching</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {linkSuggestions.map((sug, i) => (
                  <div key={i} className="bg-slate-950 border border-slate-800/80 rounded-lg p-2.5 text-xs flex items-center justify-between gap-2">
                    <div className="truncate">
                      <span className="font-bold text-indigo-400 block truncate">"{sug.anchorText}"</span>
                      <span className="text-[10px] text-slate-400 block truncate">&rarr; {sug.targetTitle}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => insertInternalLink(sug)}
                      className="bg-indigo-600/80 hover:bg-indigo-600 text-white text-[10px] font-bold px-2 py-1 rounded transition-colors whitespace-nowrap"
                    >
                      Insert Link
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar: SEO Health, Keywords, Taxonomy, Featured Image, SERP */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Article SEO Score Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>AI Article SEO Score</span>
              </h3>
              {seoAnalysis ? (
                <span
                  className={`text-sm font-extrabold px-2.5 py-0.5 rounded-full ${
                    seoAnalysis.score >= 90
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : seoAnalysis.score >= 75
                      ? 'bg-amber-500/20 text-amber-400'
                      : 'bg-rose-500/20 text-rose-400'
                  }`}
                >
                  {seoAnalysis.score}/100
                </span>
              ) : (
                <span className="text-xs text-slate-500">Evaluating...</span>
              )}
            </div>

            {seoAnalysis && (
              <div className="space-y-3 text-xs">
                {/* Score breakdown metrics */}
                <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-500 block">Keyword in H1:</span>
                    <span className={seoAnalysis.breakdown.keywordInH1 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {seoAnalysis.breakdown.keywordInH1 ? 'Passed' : 'Missing'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Keyword in Intro:</span>
                    <span className={seoAnalysis.breakdown.keywordInIntro ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {seoAnalysis.breakdown.keywordInIntro ? 'Passed' : 'Missing'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Keyword Density:</span>
                    <span className="text-slate-200 font-mono font-bold">{seoAnalysis.breakdown.keywordDensity}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Word Count:</span>
                    <span className="text-slate-200 font-mono font-bold">{seoAnalysis.breakdown.wordCount} words</span>
                  </div>
                </div>

                {/* Strengths & Warnings */}
                {seoAnalysis.warnings.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      <span>Opportunities for Improvement:</span>
                    </span>
                    <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-400">
                      {seoAnalysis.warnings.map((w, idx) => (
                        <li key={idx}>{w}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Focus Keyword & Secondary Keywords */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Keyword Targeting
            </h4>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 block font-semibold">
                Primary Focus Keyword
              </label>
              <input
                type="text"
                value={primaryFocusKeyword}
                onChange={(e) => setPrimaryFocusKeyword(e.target.value)}
                placeholder="e.g. semantic SEO"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 block font-semibold">
                Secondary Keywords
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={secondaryInput}
                  onChange={(e) => setSecondaryInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (secondaryInput.trim()) {
                        setSecondaryKeywords([...secondaryKeywords, secondaryInput.trim()]);
                        setSecondaryInput('');
                      }
                    }
                  }}
                  placeholder="Add keyword + Enter"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {secondaryKeywords.map((kw, i) => (
                  <span
                    key={i}
                    onClick={() => setSecondaryKeywords(secondaryKeywords.filter((_, idx) => idx !== i))}
                    className="bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-300 px-2 py-0.5 rounded text-[11px] cursor-pointer border border-slate-700 transition-colors"
                    title="Click to remove"
                  >
                    {kw} &times;
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Category & Tags */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Taxonomy & Categorization
            </h4>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 block font-semibold">
                Topical Desk Category
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 block font-semibold">
                Indexed Tags (Bulk Paste: comma, newline, semicolon)
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleBulkTagAdd();
                    }
                  }}
                  placeholder="tag1, tag2, tag3"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
                <button
                  type="button"
                  onClick={handleBulkTagAdd}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-2.5 py-1 rounded-lg border border-slate-700"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {articleTags.map((t, idx) => (
                  <span
                    key={idx}
                    onClick={() => removeTag(t)}
                    className="bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-300 text-[11px] px-2 py-0.5 rounded cursor-pointer border border-slate-700"
                    title="Click to remove"
                  >
                    #{t} &times;
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Featured Image */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Featured Hero Media
            </h4>

            <div className="space-y-2">
              <input
                type="text"
                value={featuredImage}
                onChange={(e) => setFeaturedImage(e.target.value)}
                placeholder="https://..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              />
              <div className="aspect-[16/9] rounded-lg overflow-hidden bg-slate-950 border border-slate-800">
                {featuredImage ? (
                  <img
                    src={featuredImage}
                    alt={featuredImageAlt || 'Preview'}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&fit=crop&q=80';
                    }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-slate-500">
                    No image URL specified
                  </div>
                )}
              </div>
              <input
                type="text"
                value={featuredImageAlt}
                onChange={(e) => setFeaturedImageAlt(e.target.value)}
                placeholder="Descriptive image alt text for SEO & accessibility"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          </div>

          {/* SERP Search Engine Result Preview */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Google SERP Preview</span>
              <span className="text-[10px] text-slate-500 font-mono">Desktop Snippet</span>
            </h4>

            {/* Google Result Card Mockup */}
            <div className="bg-white text-slate-900 p-4 rounded-xl space-y-1 shadow-sm font-sans">
              <div className="text-[11px] text-slate-600 flex items-center gap-1 font-mono truncate">
                <span>https://editorialpulse.com &rsaquo; article &rsaquo; {slug || 'slug'}</span>
              </div>
              <div className="text-base text-blue-800 font-medium hover:underline cursor-pointer truncate">
                {seoTitle || title || 'Article Title'}
              </div>
              <div className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                {metaDescription || excerpt || leadSummary || 'Meta description snippet appears here in search engine results.'}
              </div>
            </div>

            {/* Meta Description Field */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <label className="font-semibold">Meta Description:</label>
                <span className={metaDescription.length >= 130 && metaDescription.length <= 160 ? 'text-emerald-400 font-mono' : 'text-amber-400 font-mono'}>
                  {metaDescription.length}/155 chars
                </span>
              </div>
              <textarea
                rows={3}
                value={metaDescription}
                onChange={(e) => setMetaDescription(e.target.value)}
                placeholder="Concise 130-155 character description satisfying search intent."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Link Insertion Modal */}
      {showLinkModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Link className="w-4 h-4 text-indigo-400" />
              <span>Insert Semantic Hyperlink</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Target URL</label>
                <input
                  type="text"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://... or /article/example"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-mono"
                  autoFocus
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="newTabCheck"
                  checked={linkOpenNewTab}
                  onChange={(e) => setLinkOpenNewTab(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-800 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="newTabCheck" className="text-slate-300">
                  Open in new tab (<code>target="_blank"</code>)
                </label>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">rel attribute (optional)</label>
                <input
                  type="text"
                  value={linkRel}
                  onChange={(e) => setLinkRel(e.target.value)}
                  placeholder="noopener noreferrer nofollow"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLinkModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={applyLink}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-500"
              >
                Insert Link
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Humanize It Diff Preview Modal */}
      {showHumanizeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white">
                  HUMANIZE IT &bull; AI Polish & Cadence Diff
                </h3>
              </div>
              <span className="text-xs text-emerald-400 font-medium">
                Eliminates canned formulas &bull; Preserves facts & entities
              </span>
            </div>

            {isHumanizing ? (
              <div className="text-center py-16 space-y-3">
                <Sparkles className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
                <p className="text-sm text-slate-300">Applying Humanizer rules and cadence polish...</p>
              </div>
            ) : humanizeDiff ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-400 uppercase">Original Draft</span>
                    <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 max-h-72 overflow-y-auto font-mono whitespace-pre-wrap">
                      {humanizeDiff.original}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs font-bold text-emerald-400 uppercase">Humanized Prose</span>
                    <div className="bg-slate-950 border border-emerald-900/60 rounded-xl p-4 text-xs text-slate-200 max-h-72 overflow-y-auto font-mono whitespace-pre-wrap">
                      {humanizeDiff.humanized}
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3">
                  <span className="text-xs font-bold text-slate-300 block mb-1">Modifications Applied:</span>
                  <ul className="list-disc pl-4 text-xs text-slate-400 space-y-0.5">
                    {humanizeDiff.diffNotes.map((note, idx) => (
                      <li key={idx}>{note}</li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowHumanizeModal(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-700"
                  >
                    Discard Changes
                  </button>
                  <button
                    type="button"
                    onClick={applyHumanizedContent}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-sm"
                  >
                    Apply Humanized Content
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Revisions Drawer Modal */}
      {showRevisions && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-indigo-400" />
                <span>Article Revision History</span>
              </h3>
              <button
                onClick={() => setShowRevisions(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close &times;
              </button>
            </div>

            {isLoadingRevs ? (
              <p className="text-xs text-slate-400 text-center py-8">Loading history...</p>
            ) : revisions.length > 0 ? (
              <div className="divide-y divide-slate-800">
                {revisions.map((rev) => (
                  <div key={rev.id} className="py-3 flex items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-bold text-white">
                        {rev.action}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(rev.timestamp).toLocaleString()} &bull; By {rev.author}
                      </div>
                    </div>
                    <button
                      onClick={() => restoreRevision(rev.id)}
                      className="flex items-center gap-1 bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Restore</span>
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 text-center py-8">
                No past revisions recorded yet for this article.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
