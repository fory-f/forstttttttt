import React, { useState, useEffect } from 'react';
import {
  RSSItem,
  Topic,
  Category,
  EditorialTone,
  TitleCandidate,
  Article,
  InternalLinkSuggestion
} from '../../types';
import { api } from '../../services/api';
import {
  Cpu,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Wand2,
  RefreshCw,
  Search,
  Link,
  Send,
  Save,
  Clock,
  Layers,
  FileText
} from 'lucide-react';

interface AIWorkflowViewProps {
  initialRssItem?: RSSItem | null;
  categories: Category[];
  topics: Topic[];
  editorialTones: EditorialTone[];
  onFinish: (article: Article) => void;
  onCancel: () => void;
}

export const AIWorkflowView: React.FC<AIWorkflowViewProps> = ({
  initialRssItem,
  categories,
  topics,
  editorialTones,
  onFinish,
  onCancel
}) => {
  // Current stage: 1 to 14
  const [currentStage, setCurrentStage] = useState<number>(1);

  // Workflow context data
  const [sourceTitle, setSourceTitle] = useState<string>(initialRssItem?.originalTitle || '');
  const [sourceUrl, setSourceUrl] = useState<string>(initialRssItem?.originalUrl || '');
  const [sourceContent, setSourceContent] = useState<string>(initialRssItem?.description || initialRssItem?.content || '');
  const [sourceItem, setSourceItem] = useState<RSSItem | null>(initialRssItem || null);

  const [selectedTopic, setSelectedTopic] = useState<string>(topics[0]?.name || 'Artificial Intelligence');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(categories[0]?.id || 'cat-1');
  const [focusKeyword, setFocusKeyword] = useState<string>('generative AI journalism');
  const [secondaryKeywords, setSecondaryKeywords] = useState<string[]>(['editorial workflow', 'RSS aggregation', 'semantic SEO']);
  const [secondaryInput, setSecondaryInput] = useState<string>('');
  const [selectedToneId, setSelectedToneId] = useState<string>(editorialTones[0]?.id || 'tone-1');

  // Title generation
  const [isGeneratingTitles, setIsGeneratingTitles] = useState<boolean>(false);
  const [titleCandidates, setTitleCandidates] = useState<TitleCandidate[]>([]);
  const [selectedTitle, setSelectedTitle] = useState<string>('');

  // Article generation
  const [isGeneratingArticle, setIsGeneratingArticle] = useState<boolean>(false);
  const [generatedArticle, setGeneratedArticle] = useState<any>(null);

  // Editable article fields
  const [articleContent, setArticleContent] = useState<string>('');
  const [leadSummary, setLeadSummary] = useState<string>('');
  const [excerpt, setExcerpt] = useState<string>('');
  const [metaDescription, setMetaDescription] = useState<string>('');
  const [tags, setTags] = useState<string[]>([]);
  const [featuredImage, setFeaturedImage] = useState<string>('https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&h=630&fit=crop&q=80');
  const [featuredImageAlt, setFeaturedImageAlt] = useState<string>('');

  // Humanize pass
  const [isHumanizing, setIsHumanizing] = useState<boolean>(false);
  const [humanizeNotes, setHumanizeNotes] = useState<string[]>([]);

  // Internal links
  const [internalLinkSuggestions, setInternalLinkSuggestions] = useState<InternalLinkSuggestion[]>([]);

  // SEO Score
  const [seoScore, setSeoScore] = useState<number>(85);
  const [seoWarnings, setSeoWarnings] = useState<string[]>([]);

  // Saving final
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // If passed an initial RSS item, jump to Stage 2 automatically
  useEffect(() => {
    if (initialRssItem) {
      setSourceTitle(initialRssItem.originalTitle);
      setSourceUrl(initialRssItem.originalUrl);
      setSourceContent(initialRssItem.description || initialRssItem.content || '');
      setSourceItem(initialRssItem);
      setCurrentStage(2);
    }
  }, [initialRssItem]);

  // Handle Stage 5: Title generation
  const handleGenerateTitles = async () => {
    setIsGeneratingTitles(true);
    try {
      const tone = editorialTones.find(t => t.id === selectedToneId);
      const cat = categories.find(c => c.id === selectedCategoryId);
      const candidates = await api.generateTitles({
        topic: selectedTopic,
        focusKeyword,
        sourceTitle,
        sourceContent,
        tonePrompt: tone?.prompt,
        categoryName: cat?.name
      });
      setTitleCandidates(candidates);
      if (candidates.length > 0) {
        setSelectedTitle(candidates[0].title);
      }
      setCurrentStage(5);
    } catch (err: any) {
      alert(`Title generation failed: ${err.message}`);
    } finally {
      setIsGeneratingTitles(false);
    }
  };

  // Handle Stage 7: Full Article Generation
  const handleGenerateArticle = async () => {
    setIsGeneratingArticle(true);
    try {
      const tone = editorialTones.find(t => t.id === selectedToneId);
      const cat = categories.find(c => c.id === selectedCategoryId);

      const res = await api.generateArticle({
        title: selectedTitle,
        focusKeyword,
        secondaryKeywords,
        topic: selectedTopic,
        categoryName: cat?.name || 'Technology',
        categoryId: selectedCategoryId,
        sourceContent: `${sourceTitle}\n\n${sourceContent}`,
        tonePrompt: tone?.prompt
      });

      setGeneratedArticle(res);
      setArticleContent(res.content);
      setLeadSummary(res.leadSummary);
      setExcerpt(res.excerpt);
      setMetaDescription(res.metaDescription);
      setTags(res.tags);
      setFeaturedImageAlt(res.featuredImageAlt);
      setSeoScore(res.aiSeoScore);
      if (res.aiSeoAnalysis?.warnings) {
        setSeoWarnings(res.aiSeoAnalysis.warnings);
      }

      // Fetch internal link suggestions
      api.suggestInternalLinks({ currentContent: res.content })
        .then(setInternalLinkSuggestions)
        .catch(() => {});

      setCurrentStage(8);
    } catch (err: any) {
      alert(`Article generation failed: ${err.message}`);
    } finally {
      setIsGeneratingArticle(false);
    }
  };

  // Handle Stage 10: Humanize Pass
  const handleRunHumanize = async () => {
    setIsHumanizing(true);
    try {
      const res = await api.humanizeContent({
        text: articleContent,
        focusKeyword
      });
      setArticleContent(res.humanized);
      setHumanizeNotes(res.diffNotes);
      setCurrentStage(11);
    } catch (err: any) {
      alert(`Humanize pass failed: ${err.message}`);
      setCurrentStage(11);
    } finally {
      setIsHumanizing(false);
    }
  };

  // Save final article
  const handleFinalSave = async (publishNow: boolean) => {
    setIsSaving(true);
    try {
      const payload: Partial<Article> & { title: string } = {
        title: selectedTitle,
        slug: selectedTitle.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'),
        leadSummary,
        excerpt,
        content: articleContent,
        categoryId: selectedCategoryId,
        primaryFocusKeyword: focusKeyword,
        secondaryKeywords,
        tags,
        featuredImage,
        featuredImageAlt: featuredImageAlt || selectedTitle,
        seoTitle: selectedTitle,
        metaDescription,
        status: publishNow ? 'published' : 'draft',
        workflowStage: 14,
        aiSeoScore: seoScore,
        sourceRssId: sourceItem?.id,
        sourceUrl: sourceUrl || undefined,
        sourceTitle: sourceTitle || undefined
      };

      const saved = await api.saveArticle(payload);
      if (sourceItem?.id) {
        await api.updateRSSItem(sourceItem.id, { status: 'PROCESSED', articleId: saved.id });
      }
      onFinish(saved);
    } catch (err: any) {
      alert(`Failed to save article: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      {/* Top Workflow Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-white tracking-tight">
                14-Stage AI Editorial Workflow Wizard
              </h1>
              <p className="text-xs text-slate-400">
                End-to-end transformation: RSS Signal &rarr; Topic &rarr; Gemini Generation &rarr; Human Review &rarr; Publish.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-indigo-400 bg-indigo-950 px-3 py-1 rounded-full border border-indigo-800">
              Stage {currentStage} of 14
            </span>
            <button
              onClick={onCancel}
              className="text-xs text-slate-400 hover:text-white px-2 py-1"
            >
              Exit
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-950 rounded-full h-1.5 mt-4 overflow-hidden">
          <div
            className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full transition-all duration-300"
            style={{ width: `${(currentStage / 14) * 100}%` }}
          />
        </div>
      </div>

      {/* Stage Views */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xs min-h-[420px]">
        {/* STAGE 1: RSS Discovery & Ingestion */}
        {currentStage === 1 && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 1: Content Ingestion & RSS Discovery</h3>
              <p className="text-xs text-slate-400">
                Provide source information from an RSS feed item or paste a research summary.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Source Headline / Title</label>
                <input
                  type="text"
                  value={sourceTitle}
                  onChange={(e) => setSourceTitle(e.target.value)}
                  placeholder="e.g. OpenAI announces new research preview into reasoning models"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Source URL (Attribution)</label>
                <input
                  type="text"
                  value={sourceUrl}
                  onChange={(e) => setSourceUrl(e.target.value)}
                  placeholder="https://example.com/news-story"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Source Excerpt / Raw Facts</label>
                <textarea
                  rows={4}
                  value={sourceContent}
                  onChange={(e) => setSourceContent(e.target.value)}
                  placeholder="Paste excerpt or factual bullet points from the primary reporting..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(2)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Continue to Topic & Category</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 2: Topic & Category Selection */}
        {currentStage === 2 && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 2: Topic Selection & Category Desk</h3>
              <p className="text-xs text-slate-400">
                Organize this article under your strategic content topics and editorial desks.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <label className="text-slate-300 font-semibold block">Editorial Topic</label>
                <div className="space-y-1.5 max-h-56 overflow-y-auto">
                  {topics.map(t => (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTopic(t.name)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedTopic === t.name
                          ? 'bg-indigo-600/20 border-indigo-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <span className="font-bold block text-slate-200">{t.name}</span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">{t.description}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-slate-300 font-semibold block">Topical Desk Category</label>
                <div className="space-y-1.5 max-h-56 overflow-y-auto">
                  {categories.map(c => (
                    <div
                      key={c.id}
                      onClick={() => setSelectedCategoryId(c.id)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedCategoryId === c.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <span className="font-bold block text-slate-200">{c.name}</span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">{c.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(1)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back
              </button>
              <button
                type="button"
                onClick={() => setCurrentStage(3)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Continue to Keyword Targeting</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 3: Keyword Targeting */}
        {currentStage === 3 && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 3: Search Intent & Keyword Targeting</h3>
              <p className="text-xs text-slate-400">
                Identify the primary query users enter into search engines for this topic.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Primary Focus Keyword</label>
                <input
                  type="text"
                  value={focusKeyword}
                  onChange={(e) => setFocusKeyword(e.target.value)}
                  placeholder="e.g. generative AI in journalism"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-mono text-sm"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Secondary Semantic Keywords</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={secondaryInput}
                    onChange={(e) => setSecondaryInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (secondaryInput.trim()) {
                          setSecondaryKeywords([...secondaryKeywords, secondaryInput.trim()]);
                          setSecondaryInput('');
                        }
                      }
                    }}
                    placeholder="Add secondary keyword + Enter"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (secondaryInput.trim()) {
                        setSecondaryKeywords([...secondaryKeywords, secondaryInput.trim()]);
                        setSecondaryInput('');
                      }
                    }}
                    className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {secondaryKeywords.map((kw, i) => (
                    <span
                      key={i}
                      onClick={() => setSecondaryKeywords(secondaryKeywords.filter((_, idx) => idx !== i))}
                      className="bg-slate-800 hover:bg-rose-900 text-slate-300 px-2.5 py-1 rounded text-xs cursor-pointer border border-slate-700"
                    >
                      {kw} &times;
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(2)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back
              </button>
              <button
                type="button"
                onClick={() => setCurrentStage(4)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Continue to Tone Selection</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 4: Editorial Tone Selection */}
        {currentStage === 4 && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 4: Editorial Tone & Voice Configuration</h3>
              <p className="text-xs text-slate-400">
                Select the target editorial tone to guide Gemini's generation style.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {editorialTones.map((tone) => (
                <div
                  key={tone.id}
                  onClick={() => setSelectedToneId(tone.id)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    selectedToneId === tone.id
                      ? 'bg-indigo-600/20 border-indigo-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-slate-200">{tone.name}</span>
                    {tone.isDefault && (
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">Default</span>
                    )}
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed">{tone.description}</p>
                </div>
              ))}
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(3)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back
              </button>
              <button
                type="button"
                onClick={handleGenerateTitles}
                disabled={isGeneratingTitles}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-indigo-300" />
                <span>{isGeneratingTitles ? 'Consulting Gemini...' : 'Generate 5-7 AI Titles'}</span>
              </button>
            </div>
          </div>
        )}

        {/* STAGE 5 & 6: AI Title Generation & Approval */}
        {(currentStage === 5 || currentStage === 6) && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 5 & 6: AI Title Candidate Evaluation</h3>
              <p className="text-xs text-slate-400">
                Review Gemini's evaluated headlines with AI SEO scores, keyword positioning, and CTR estimation.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              {titleCandidates.map((cand, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedTitle(cand.title);
                    setCurrentStage(6);
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all space-y-2 ${
                    selectedTitle === cand.title
                      ? 'bg-indigo-600/20 border-indigo-500 shadow-sm'
                      : 'bg-slate-950 border-slate-800 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-slate-100">{cand.title}</h4>
                    <span className="bg-emerald-500/20 text-emerald-400 text-[11px] font-bold px-2 py-0.5 rounded">
                      SEO {cand.aiSeoScore}/100
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                    <span>Placement: <strong className="text-slate-300">{cand.keywordPlacement}</strong></span>
                    <span>Intent: <strong className="text-slate-300">{cand.searchIntent}</strong></span>
                    <span>CTR: <strong className="text-slate-300">{cand.ctrPotential}</strong></span>
                    <span>Chars: <strong className="text-slate-300">{cand.charCount}</strong></span>
                    {cand.clickbaitWarning && (
                      <span className="text-amber-400 font-semibold">&bull; Clickbait risk</span>
                    )}
                  </div>

                  <p className="text-slate-400 text-[11px] italic">{cand.explanation}</p>
                </div>
              ))}
            </div>

            {/* Editable Selected Title */}
            <div className="pt-2">
              <label className="text-xs text-slate-300 font-semibold block mb-1">
                Approved Title for Article Generation:
              </label>
              <input
                type="text"
                value={selectedTitle}
                onChange={(e) => setSelectedTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white font-bold text-sm focus:ring-2 focus:ring-indigo-600"
              />
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={handleGenerateTitles}
                disabled={isGeneratingTitles}
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Regenerate Titles</span>
              </button>

              <button
                type="button"
                onClick={handleGenerateArticle}
                disabled={isGeneratingArticle || !selectedTitle.trim()}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-indigo-300" />
                <span>{isGeneratingArticle ? 'Synthesizing Full Article...' : 'Stage 7: Generate Full Article'}</span>
              </button>
            </div>
          </div>
        )}

        {/* STAGE 8 & 9: Semantic Article Review */}
        {(currentStage === 8 || currentStage === 9) && (
          <div className="space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-white">Stage 8 & 9: Semantic Content & SEO Review</h3>
                <p className="text-xs text-slate-400">
                  AI SEO Score: <strong className="text-emerald-400">{seoScore}/100</strong> &bull; Complete semantic HTML structure generated.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRunHumanize}
                  disabled={isHumanizing}
                  className="flex items-center gap-1.5 bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-xs font-bold px-3.5 py-2 rounded-lg"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>{isHumanizing ? 'Humanizing...' : 'Stage 10: Humanize It'}</span>
                </button>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Lead Summary (H1 Subtitle)</label>
                <textarea
                  rows={2}
                  value={leadSummary}
                  onChange={(e) => setLeadSummary(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Main Semantic HTML Body</label>
                <div
                  contentEditable
                  onInput={(e) => setArticleContent((e.target as HTMLDivElement).innerHTML)}
                  dangerouslySetInnerHTML={{ __html: articleContent }}
                  className="w-full min-h-[300px] max-h-[450px] overflow-y-auto bg-slate-950 border border-slate-800 rounded-xl p-5 text-slate-200 text-xs leading-relaxed prose prose-invert"
                  style={{ outline: 'none' }}
                />
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(6)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back to Titles
              </button>

              <button
                type="button"
                onClick={() => setCurrentStage(10)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Continue to Humanize Pass</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 10 & 11: Humanize Pass & Internal Links */}
        {(currentStage === 10 || currentStage === 11) && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 10 & 11: Humanize Polish & Internal Links</h3>
              <p className="text-xs text-slate-400">
                Ensuring human cadence and connecting this dispatch with existing topical catalog.
              </p>
            </div>

            {/* Humanize summary */}
            {humanizeNotes.length > 0 && (
              <div className="bg-slate-950 border border-emerald-900/60 rounded-xl p-4 text-xs">
                <span className="font-bold text-emerald-400 block mb-1">Humanizer Improvements Applied:</span>
                <ul className="list-disc pl-4 text-slate-300 space-y-0.5">
                  {humanizeNotes.map((n, i) => (
                    <li key={i}>{n}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Internal Links Suggestions */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase">Suggested Internal Links</label>
              {internalLinkSuggestions.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {internalLinkSuggestions.map((sug, i) => (
                    <div key={i} className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-indigo-400 block">"{sug.anchorText}"</span>
                        <span className="text-[10px] text-slate-400 block truncate">&rarr; {sug.targetTitle}</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded">
                        Available
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500">No other articles in database yet to link with.</p>
              )}
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(9)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back
              </button>

              <button
                type="button"
                onClick={() => setCurrentStage(12)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Continue to Media & Metadata</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 12 & 13: Media & SERP Metadata */}
        {(currentStage === 12 || currentStage === 13) && (
          <div className="space-y-5">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Stage 12 & 13: Featured Media & SERP Metadata</h3>
              <p className="text-xs text-slate-400">
                Confirm search engine snippet and OpenGraph social share card parameters.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <label className="text-slate-300 font-semibold block">Featured Image URL</label>
                <input
                  type="text"
                  value={featuredImage}
                  onChange={(e) => setFeaturedImage(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
                <input
                  type="text"
                  value={featuredImageAlt}
                  onChange={(e) => setFeaturedImageAlt(e.target.value)}
                  placeholder="Alt text"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-400"
                />
                <div className="aspect-[16/9] rounded-lg overflow-hidden bg-slate-950 border border-slate-800">
                  {featuredImage ? (
                    <img src={featuredImage} alt="preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs text-slate-500">
                      No image URL specified
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Meta Description</label>
                  <textarea
                    rows={4}
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                  />
                  <span className="text-[11px] text-slate-500 block text-right mt-1">
                    {metaDescription.length}/155 characters
                  </span>
                </div>

                {/* Google Preview */}
                <div className="bg-white text-slate-900 p-3.5 rounded-xl space-y-1">
                  <div className="text-[10px] text-slate-500 font-mono">https://editorialpulse.com/article/...</div>
                  <div className="text-xs font-bold text-blue-800 truncate">{selectedTitle}</div>
                  <div className="text-[11px] text-slate-600 line-clamp-2">{metaDescription}</div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(11)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back
              </button>

              <button
                type="button"
                onClick={() => setCurrentStage(14)}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg"
              >
                <span>Stage 14: Final Human Approval</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STAGE 14: Final Human Approval & Publishing Decision */}
        {currentStage === 14 && (
          <div className="space-y-6">
            <div className="space-y-1">
              <h3 className="text-xl font-extrabold text-white">Stage 14: Final Human Approval & Dispatch</h3>
              <p className="text-xs text-slate-400">
                Your article has passed all 13 editorial stages. Decide whether to publish immediately or save as a draft.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Article Title:</span>
                <span className="font-bold text-white">{selectedTitle}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Primary Focus Keyword:</span>
                <span className="font-mono text-indigo-400">{focusKeyword}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">AI SEO Score:</span>
                <span className="text-emerald-400 font-bold">{seoScore}/100</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Editorial Desk:</span>
                <span className="text-slate-200 font-semibold">
                  {categories.find(c => c.id === selectedCategoryId)?.name}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStage(13)}
                className="text-xs text-slate-400 hover:text-white"
              >
                &larr; Back to Metadata
              </button>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleFinalSave(false)}
                  disabled={isSaving}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors"
                >
                  <Save className="w-3.5 h-3.5 inline mr-1" />
                  <span>Save as Draft</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleFinalSave(true)}
                  disabled={isSaving}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                >
                  <Send className="w-3.5 h-3.5 inline mr-1" />
                  <span>{isSaving ? 'Publishing...' : 'Approve & Publish to Public Blog'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
