import React, { useState, useEffect } from 'react';
import { SiteSettings, EditorialTone, AIInstruction, AIPermission, AutomationRule, PromptTemplate } from '../../types';
import { api } from '../../services/api';
import { Settings, User, Sliders, Shield, FileText, Cpu, Save, Plus, Trash2, CheckCircle2 } from 'lucide-react';

interface SettingsViewProps {
  settings: SiteSettings;
  onRefreshSettings: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, onRefreshSettings }) => {
  const [activeTab, setActiveTab] = useState<'site' | 'author' | 'tones' | 'instructions' | 'rules' | 'permissions'>('site');

  // Site Identity State
  const [siteName, setSiteName] = useState<string>(settings.siteName);
  const [tagline, setTagline] = useState<string>(settings.tagline);
  const [siteDescription, setSiteDescription] = useState<string>(settings.siteDescription);
  const [publishMode, setPublishMode] = useState<SiteSettings['publishMode']>(settings.publishMode);
  const [activeAiModel, setActiveAiModel] = useState<string>(settings.activeAiModel);

  // Author E-E-A-T Profile State
  const [authorName, setAuthorName] = useState<string>(settings.authorProfile.name);
  const [authorBio, setAuthorBio] = useState<string>(settings.authorProfile.shortBio);
  const [authorFullBio, setAuthorFullBio] = useState<string>(settings.authorProfile.fullBio);
  const [authorAvatar, setAuthorAvatar] = useState<string>(settings.authorProfile.avatar);
  const [authorCredentials, setAuthorCredentials] = useState<string>(settings.authorProfile.credentials);
  const [authorOrg, setAuthorOrg] = useState<string>(settings.authorProfile.organization);
  const [authorWebsite, setAuthorWebsite] = useState<string>(settings.authorProfile.website);
  const [authorTwitter, setAuthorTwitter] = useState<string>(settings.authorProfile.socialTwitter);
  const [authorLinkedin, setAuthorLinkedin] = useState<string>(settings.authorProfile.socialLinkedin);
  const [authorExpertise, setAuthorExpertise] = useState<string>(settings.authorProfile.expertise.join(', '));

  // Editorial Tones
  const [tones, setTones] = useState<EditorialTone[]>([]);
  const [newToneName, setNewToneName] = useState<string>('');
  const [newTonePrompt, setNewTonePrompt] = useState<string>('');
  const [newToneDesc, setNewToneDesc] = useState<string>('');

  // Instructions
  const [instructions, setInstructions] = useState<AIInstruction[]>([]);
  const [newInstTitle, setNewInstTitle] = useState<string>('');
  const [newInstText, setNewInstText] = useState<string>('');
  const [newInstLevel, setNewInstLevel] = useState<AIInstruction['level']>('global');

  // Permissions
  const [permissions, setPermissions] = useState<AIPermission[]>([]);

  // Saving state
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  useEffect(() => {
    api.getEditorialTones().then(setTones).catch(() => {});
    api.getAIInstructions().then(setInstructions).catch(() => {});
    api.getPermissions().then(setPermissions).catch(() => {});
  }, []);

  const handleSaveGeneral = async () => {
    setIsSaving(true);
    setSavedSuccess(false);
    try {
      await api.saveSettings({
        siteName,
        tagline,
        siteDescription,
        publishMode,
        activeAiModel,
        authorProfile: {
          name: authorName,
          slug: authorName.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-'),
          shortBio: authorBio,
          fullBio: authorFullBio,
          avatar: authorAvatar,
          website: authorWebsite,
          socialTwitter: authorTwitter,
          socialLinkedin: authorLinkedin,
          socialGithub: settings.authorProfile.socialGithub,
          expertise: authorExpertise.split(',').map(e => e.trim()).filter(Boolean),
          credentials: authorCredentials,
          organization: authorOrg
        }
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
      onRefreshSettings();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddTone = async () => {
    if (!newToneName.trim() || !newTonePrompt.trim()) return;
    try {
      await api.saveEditorialTone({
        name: newToneName,
        prompt: newTonePrompt,
        description: newToneDesc,
        isDefault: false,
        enabled: true
      });
      setNewToneName('');
      setNewTonePrompt('');
      setNewToneDesc('');
      api.getEditorialTones().then(setTones);
    } catch (err: any) {
      alert(`Tone save failed: ${err.message}`);
    }
  };

  const handleDeleteTone = async (id: string) => {
    try {
      await api.deleteEditorialTone(id);
      api.getEditorialTones().then(setTones);
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleAddInstruction = async () => {
    if (!newInstTitle.trim() || !newInstText.trim()) return;
    try {
      await api.saveAIInstruction({
        title: newInstTitle,
        instruction: newInstText,
        level: newInstLevel,
        enabled: true
      });
      setNewInstTitle('');
      setNewInstText('');
      api.getAIInstructions().then(setInstructions);
    } catch (err: any) {
      alert(`Instruction save failed: ${err.message}`);
    }
  };

  const handleDeleteInstruction = async (id: string) => {
    try {
      await api.deleteAIInstruction(id);
      api.getAIInstructions().then(setInstructions);
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleTogglePermission = async (key: string, current: boolean) => {
    try {
      await api.updatePermission(key, !current);
      api.getPermissions().then(setPermissions);
    } catch (err: any) {
      alert(`Permission update failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-indigo-400" />
            <span>Platform Settings & Governance</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Configure site metadata, E-E-A-T author attribution, Gemini prompts, and publishing automation rules.
          </p>
        </div>

        <button
          onClick={handleSaveGeneral}
          disabled={isSaving}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-5 py-2.5 rounded-lg shadow-sm"
        >
          {savedSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
          <span>{savedSuccess ? 'Settings Saved!' : isSaving ? 'Saving...' : 'Save Configuration'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'site', label: 'Site Identity & Mode' },
          { id: 'author', label: 'Author Profile (E-E-A-T)' },
          { id: 'tones', label: 'Editorial Tones' },
          { id: 'instructions', label: 'Permanent AI Instructions' },
          { id: 'permissions', label: 'AI Guardrails & Permissions' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === t.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: Site Identity & Mode */}
      {activeTab === 'site' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">Platform Identity & Automation Mode</h3>
            <p className="text-xs text-slate-400">Controls public metadata, crawlable tags, and publishing pipeline.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold block">Publication Name</label>
              <input
                type="text"
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-bold"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold block">Editorial Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
              />
            </div>

            <div className="md:col-span-2 space-y-1.5">
              <label className="text-slate-300 font-semibold block">Public Meta Description</label>
              <textarea
                rows={3}
                value={siteDescription}
                onChange={(e) => setSiteDescription(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold block">Automation Operating Mode</label>
              <select
                value={publishMode}
                onChange={(e) => setPublishMode(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-semibold"
              >
                <option value="manual">Manual (All articles saved as Drafts for human review)</option>
                <option value="semi-automatic">Semi-Automatic (Generated articles queued for 1-click approval)</option>
                <option value="automatic">Automatic (Auto-publish if AI SEO score meets threshold)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold block">Active AI Model</label>
              <select
                value={activeAiModel}
                onChange={(e) => setActiveAiModel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-indigo-400 font-mono"
              >
                <option value="gemini-2.5-flash">gemini-2.5-flash (Fast & High Capability)</option>
                <option value="gemini-2.5-pro">gemini-2.5-pro (Deep Editorial Reasoning)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Author Profile (E-E-A-T) */}
      {activeTab === 'author' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">Default Editorial Author Profile (E-E-A-T)</h3>
            <p className="text-xs text-slate-400">
              Essential for Google Experience, Expertise, Authoritativeness, and Trustworthiness guidelines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-300 font-semibold block mb-1">Author Name</label>
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Credentials & Degree</label>
              <input
                type="text"
                value={authorCredentials}
                onChange={(e) => setAuthorCredentials(e.target.value)}
                placeholder="e.g. M.S. Computer Science, AI Systems Researcher"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Affiliated Organization</label>
              <input
                type="text"
                value={authorOrg}
                onChange={(e) => setAuthorOrg(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Avatar Image URL</label>
              <input
                type="url"
                value={authorAvatar}
                onChange={(e) => setAuthorAvatar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
              />
            </div>

            <div className="md:col-span-2">
              <label className="text-slate-300 font-semibold block mb-1">Short Bio (Article Header)</label>
              <textarea
                rows={2}
                value={authorBio}
                onChange={(e) => setAuthorBio(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300"
              />
            </div>

            <div className="md:col-span-2">
              <label className="text-slate-300 font-semibold block mb-1">Full Bio (Author Archive Page)</label>
              <textarea
                rows={4}
                value={authorFullBio}
                onChange={(e) => setAuthorFullBio(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300"
              />
            </div>

            <div className="md:col-span-2">
              <label className="text-slate-300 font-semibold block mb-1">Expertise Domains (comma separated)</label>
              <input
                type="text"
                value={authorExpertise}
                onChange={(e) => setAuthorExpertise(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Personal Website URL</label>
              <input
                type="url"
                value={authorWebsite}
                onChange={(e) => setAuthorWebsite(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">Twitter / X URL</label>
              <input
                type="url"
                value={authorTwitter}
                onChange={(e) => setAuthorTwitter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Editorial Tones */}
      {activeTab === 'tones' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white">Editorial Tones & Stylistic Personas</h3>
              <p className="text-xs text-slate-400">Pre-configured writing instructions fed into Gemini prompts.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tones.map((t) => (
              <div key={t.id} className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-white text-sm">{t.name}</h4>
                    {t.isDefault && <span className="text-[10px] bg-indigo-950 text-indigo-400 px-2 py-0.5 rounded font-bold">Default</span>}
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{t.description}</p>
                  <p className="text-[11px] text-slate-500 font-mono mt-2 bg-slate-900 p-2 rounded line-clamp-3">
                    {t.prompt}
                  </p>
                </div>
                <div className="pt-2 flex justify-end">
                  <button onClick={() => handleDeleteTone(t.id)} className="text-slate-500 hover:text-rose-400 p-1">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add Tone Form */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
            <h4 className="font-bold text-white">Create New Editorial Tone</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={newToneName}
                onChange={(e) => setNewToneName(e.target.value)}
                placeholder="Tone Name (e.g. Socratic Breakdown)"
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
              />
              <input
                type="text"
                value={newToneDesc}
                onChange={(e) => setNewToneDesc(e.target.value)}
                placeholder="Description"
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-300"
              />
            </div>
            <textarea
              rows={3}
              value={newTonePrompt}
              onChange={(e) => setNewTonePrompt(e.target.value)}
              placeholder="Detailed system prompt directives for this tone..."
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200"
            />
            <button
              onClick={handleAddTone}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg"
            >
              Add Tone
            </button>
          </div>
        </div>
      )}

      {/* TAB 4: Instructions */}
      {activeTab === 'instructions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Permanent AI System Instructions Hierarchy</h3>
            <p className="text-xs text-slate-400">Rules applied globally across all Gemini article generation tasks.</p>
          </div>

          <div className="space-y-3">
            {instructions.map((inst) => (
              <div key={inst.id} className="bg-slate-950 border border-slate-850 rounded-xl p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded">
                      {inst.level}
                    </span>
                    <h4 className="font-bold text-white text-xs">{inst.title}</h4>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed pt-1">{inst.instruction}</p>
                </div>
                <button onClick={() => handleDeleteInstruction(inst.id)} className="text-slate-500 hover:text-rose-400 p-1">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Instruction */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
            <h4 className="font-bold text-white">Add Permanent Instruction Rule</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={newInstTitle}
                onChange={(e) => setNewInstTitle(e.target.value)}
                placeholder="Rule Title"
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
              />
              <select
                value={newInstLevel}
                onChange={(e) => setNewInstLevel(e.target.value as any)}
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-300"
              >
                <option value="global">Global (All generations)</option>
                <option value="category">Category-specific</option>
                <option value="source">Source-specific</option>
              </select>
            </div>
            <textarea
              rows={3}
              value={newInstText}
              onChange={(e) => setNewInstText(e.target.value)}
              placeholder="Directive text..."
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200"
            />
            <button
              onClick={handleAddInstruction}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg"
            >
              Save Rule
            </button>
          </div>
        </div>
      )}

      {/* TAB 5: AI Permissions */}
      {activeTab === 'permissions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Autonomous Agent Permissions & Safety Gates</h3>
            <p className="text-xs text-slate-400">
              Configure what MAGIC and background automation are permitted to do without human confirmation.
            </p>
          </div>

          <div className="divide-y divide-slate-800">
            {permissions.map((perm) => (
              <div key={perm.id} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">{perm.name}</span>
                    {perm.dangerous && (
                      <span className="text-[10px] bg-rose-950 text-rose-400 font-bold px-1.5 py-0.2 rounded border border-rose-900">
                        High Impact
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{perm.description}</p>
                </div>

                <button
                  onClick={() => handleTogglePermission(perm.key, perm.allowed)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    perm.allowed ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {perm.allowed ? 'ALLOWED' : 'APPROVAL REQUIRED'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
