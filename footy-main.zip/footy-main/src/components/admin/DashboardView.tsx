import React from 'react';
import { Article, RSSItem, SiteSettings } from '../../types';
import {
  FileText,
  CheckCircle,
  Clock,
  Inbox,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  Plus,
  Rss,
  Trash2,
  Edit,
  ExternalLink
} from 'lucide-react';

interface DashboardViewProps {
  articles: Article[];
  rssItems: RSSItem[];
  settings: SiteSettings;
  onSelectTab: (tab: string) => void;
  onEditArticle: (articleId: string) => void;
  onProcessRssItem: (item: RSSItem) => void;
  onDeleteArticle: (articleId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  articles,
  rssItems,
  settings,
  onSelectTab,
  onEditArticle,
  onProcessRssItem,
  onDeleteArticle
}) => {
  const published = articles.filter(a => a.status === 'published');
  const drafts = articles.filter(a => a.status === 'draft');
  const scheduled = articles.filter(a => a.status === 'scheduled');
  const queuePending = rssItems.filter(i => i.status === 'NEW' || i.status === 'SELECTED');

  const avgSeoScore = published.length > 0
    ? Math.round(published.reduce((acc, a) => acc + (a.aiSeoScore || 85), 0) / published.length)
    : 90;

  const seoWarnings = articles.filter(a => (a.aiSeoScore || 0) < 80 || !a.metaDescription);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Editorial Operations Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time control for content ingestion, Gemini AI editorial pipeline, and SEO indexing health.
          </p>
        </div>

        {/* Quick Actions Bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onSelectTab('editor')}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow-sm transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Article</span>
          </button>

          <button
            onClick={() => onSelectTab('ai-workflow')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold px-3.5 py-2 rounded-lg border border-slate-700 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>14-Stage AI Pipeline</span>
          </button>

          <button
            onClick={() => onSelectTab('rss')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold px-3.5 py-2 rounded-lg border border-slate-700 transition-all"
          >
            <Rss className="w-3.5 h-3.5 text-amber-400" />
            <span>Fetch RSS</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              Published Articles
            </span>
            <span className="text-3xl font-extrabold text-white block">
              {published.length}
            </span>
            <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
              <CheckCircle className="w-3 h-3" />
              <span>Publicly indexed</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              Drafts in Progress
            </span>
            <span className="text-3xl font-extrabold text-white block">
              {drafts.length}
            </span>
            <span className="text-[11px] text-amber-400 flex items-center gap-1 mt-1">
              <Clock className="w-3 h-3" />
              <span>Awaiting review</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              RSS Content Queue
            </span>
            <span className="text-3xl font-extrabold text-white block">
              {queuePending.length}
            </span>
            <span className="text-[11px] text-indigo-400 flex items-center gap-1 mt-1">
              <Inbox className="w-3 h-3" />
              <span>Ready for AI synthesis</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
            <Inbox className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              Average AI SEO Score
            </span>
            <span className="text-3xl font-extrabold text-white block">
              {avgSeoScore}<span className="text-lg text-slate-500 font-normal">/100</span>
            </span>
            <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>High topical depth</span>
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-violet-500/10 border border-violet-500/20 text-violet-400 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* SEO Health Banner if issues exist */}
      {seoWarnings.length > 0 && (
        <div className="bg-amber-950/40 border border-amber-800/60 rounded-2xl p-4 sm:p-5 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-bold text-amber-200">
                SEO & Metadata Attention Needed ({seoWarnings.length} articles)
              </h4>
              <p className="text-xs text-amber-300/80 mt-0.5">
                Certain articles are missing optimized meta descriptions or have AI SEO scores under 80.
              </p>
            </div>
          </div>
          <button
            onClick={() => onSelectTab('logs')}
            className="text-xs font-semibold text-amber-300 hover:text-white underline whitespace-nowrap"
          >
            Review SEO Audit &rarr;
          </button>
        </div>
      )}

      {/* Dual Column: Recent Articles & Content Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Recent Articles */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-400" />
              <span>Recent Articles</span>
            </h3>
            <button
              onClick={() => onSelectTab('articles')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
            >
              <span>View catalog ({articles.length})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-800/80">
            {articles.slice(0, 5).map((article) => (
              <div key={article.id} className="py-3 flex items-center justify-between gap-4 group">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                        article.status === 'published'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {article.status}
                    </span>
                    {article.aiSeoScore && (
                      <span className="text-[10px] bg-indigo-950 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-800/60 font-semibold">
                        SEO: {article.aiSeoScore}
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-semibold text-slate-200 truncate group-hover:text-indigo-400 transition-colors">
                    {article.title}
                  </h4>
                  <span className="text-xs text-slate-500 block truncate">
                    Focus: "{article.primaryFocusKeyword || 'None'}" &bull; {new Date(article.updatedAt || article.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onEditArticle(article.id)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
                    title="Edit Article"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteArticle(article.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-md transition-colors"
                    title="Delete Article"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: RSS Ingestion Queue */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Inbox className="w-4 h-4 text-amber-400" />
              <span>Pending RSS Signals</span>
            </h3>
            <button
              onClick={() => onSelectTab('queue')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
            >
              <span>Queue ({rssItems.length})</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3">
            {rssItems.slice(0, 4).map((item) => (
              <div
                key={item.id}
                className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 space-y-2"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-semibold text-amber-400">{item.sourceName}</span>
                  <span>{new Date(item.publicationDate).toLocaleDateString()}</span>
                </div>

                <h4 className="text-xs font-bold text-slate-200 line-clamp-2">
                  {item.originalTitle}
                </h4>

                <div className="pt-1 flex items-center justify-between">
                  <a
                    href={item.originalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
                  >
                    <span>Inspect source</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    onClick={() => onProcessRssItem(item)}
                    className="inline-flex items-center gap-1 bg-indigo-600/90 hover:bg-indigo-600 text-white text-[11px] font-semibold px-2.5 py-1 rounded-md shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Process with AI</span>
                  </button>
                </div>
              </div>
            ))}

            {rssItems.length === 0 && (
              <div className="text-center py-8 text-slate-500 text-xs">
                No new items in RSS queue. Click "Fetch RSS" to poll active sources.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
