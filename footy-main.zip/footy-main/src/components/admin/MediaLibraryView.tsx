import React, { useState, useEffect } from 'react';
import { MediaItem } from '../../types';
import { api } from '../../services/api';
import { Image as ImageIcon, Plus, Trash2, Copy, Check, ExternalLink } from 'lucide-react';

export const MediaLibraryView: React.FC = () => {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [showAdd, setShowAdd] = useState<boolean>(false);
  const [url, setUrl] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [altText, setAltText] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const loadMedia = async () => {
    try {
      const data = await api.getMedia();
      setItems(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadMedia();
  }, []);

  const handleAdd = async () => {
    if (!url.trim()) return;
    try {
      await api.saveMedia({
        url,
        title: title || 'Featured Media',
        altText: altText || title || 'Editorial illustration',
        caption: title || '',
        filename: url.split('/').pop() || 'media.jpg',
        mimeType: 'image/jpeg',
        fileSize: 102400
      });
      setShowAdd(false);
      setUrl('');
      setTitle('');
      setAltText('');
      loadMedia();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Permanently delete media item?')) return;
    try {
      await api.deleteMedia(id);
      loadMedia();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const copyUrl = (id: string, u: string) => {
    navigator.clipboard.writeText(u);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-indigo-400" />
            <span>Media Library</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Optimized responsive hero images with mandatory SEO alt text and accessibility captions.
          </p>
        </div>

        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add Media Image</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {items.map((m) => (
          <div
            key={m.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between group"
          >
            <div>
              <div className="aspect-[16/10] bg-slate-950 overflow-hidden relative">
                <img
                  src={m.url || 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&fit=crop&q=80'}
                  alt={m.altText || 'Media image'}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 space-y-1">
                <h4 className="text-xs font-bold text-white truncate">{m.title}</h4>
                <p className="text-[11px] text-slate-400 truncate italic">Alt: {m.altText}</p>
              </div>
            </div>

            <div className="px-4 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => copyUrl(m.id, m.url)}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
              >
                {copiedId === m.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === m.id ? 'Copied' : 'Copy URL'}</span>
              </button>

              <button
                onClick={() => handleDelete(m.id)}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Delete image"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Add Image to Media Library</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Image URL</label>
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. AI Datacenter Infrastructure"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Alt Text (Critical for SEO & Accessibility)</label>
                <input
                  type="text"
                  value={altText}
                  onChange={(e) => setAltText(e.target.value)}
                  placeholder="Detailed visual description"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAdd(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAdd}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg"
              >
                Save Media
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
