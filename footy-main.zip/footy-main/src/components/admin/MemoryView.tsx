import React, { useState, useEffect } from 'react';
import { MemoryItem, Article } from '../../types';
import { api } from '../../services/api';
import { Brain, Plus, Search, Trash2, Tag, ShieldCheck } from 'lucide-react';

export const MemoryView: React.FC = () => {
  const [items, setItems] = useState<MemoryItem[]>([]);
  const [search, setSearch] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [type, setType] = useState<MemoryItem['type']>('guideline');
  const [content, setContent] = useState<string>('');
  const [tagsInput, setTagsInput] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const loadMemory = async () => {
    try {
      const data = await api.getMemory(search);
      setItems(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadMemory();
  }, [search]);

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      alert('Please provide title and content.');
      return;
    }
    setIsSaving(true);
    try {
      const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
      await api.saveMemory({ title, type, content, tags });
      setShowAddModal(false);
      setTitle('');
      setContent('');
      setTagsInput('');
      loadMemory();
    } catch (err: any) {
      alert(`Failed to save: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Permanently delete this memory item?')) return;
    try {
      await api.deleteMemory(id);
      loadMemory();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Brain className="w-6 h-6 text-indigo-400" />
            <span>Project Memory & Knowledge Base</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Permanent institutional guidelines, technical standards, and research items used to anchor Gemini generations.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add Knowledge Item</span>
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search guidelines, rules, research notes..."
          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800/60">
                  {item.type}
                </span>
                <span className="text-[10px] text-slate-500">
                  {new Date(item.lastUpdated).toLocaleDateString()}
                </span>
              </div>

              <h3 className="text-sm font-bold text-white leading-snug">
                {item.title}
              </h3>

              <p className="text-xs text-slate-300 whitespace-pre-wrap line-clamp-4 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-850">
                {item.content}
              </p>

              <div className="flex flex-wrap gap-1 pt-1">
                {item.tags.map((t, idx) => (
                  <span key={idx} className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => handleDelete(item.id)}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Delete memory"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Add Knowledge Memory Document</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Core Editorial Writing Principles"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Category / Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
                >
                  <option value="guideline">Editorial Guideline</option>
                  <option value="brand">Brand Voice</option>
                  <option value="research">Technical Research</option>
                  <option value="document">Reference Document</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Content / Rules</label>
                <textarea
                  rows={5}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Detailed guidelines or factual knowledge for the AI agent..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="seo, writing, tone"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg"
              >
                {isSaving ? 'Saving...' : 'Save Item'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface ReviewQueueViewProps {
  articles: Article[];
  onApprovePublish: (id: string) => Promise<void>;
  onEditArticle: (id: string) => void;
  onRejectDraft: (id: string) => Promise<void>;
}

export const ReviewQueueView: React.FC<ReviewQueueViewProps> = ({
  articles,
  onApprovePublish,
  onEditArticle,
  onRejectDraft
}) => {
  const pending = articles.filter(a => a.status === 'draft');

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">
          Editorial Review Queue
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Human-in-the-loop gate for articles requiring editorial approval before public dispatch.
        </p>
      </div>

      <div className="space-y-4">
        {pending.map((art) => (
          <div
            key={art.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
          >
            <div className="space-y-2 flex-1">
              <div className="flex items-center gap-2 text-xs">
                <span className="bg-amber-500/20 text-amber-400 font-bold px-2 py-0.5 rounded text-[10px] uppercase">
                  Pending Review
                </span>
                <span className="text-slate-500">
                  Focus: <strong className="text-indigo-400 font-mono">"{art.primaryFocusKeyword || 'None'}"</strong>
                </span>
                {art.aiSeoScore && (
                  <span className="text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded text-[11px]">
                    SEO: {art.aiSeoScore}/100
                  </span>
                )}
              </div>

              <h3 className="text-base font-bold text-white">
                {art.title}
              </h3>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {art.leadSummary || art.excerpt}
              </p>
            </div>

            <div className="flex items-center gap-2 self-end md:self-auto flex-shrink-0">
              <button
                onClick={() => onEditArticle(art.id)}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg border border-slate-700"
              >
                Inspect & Edit
              </button>

              <button
                onClick={() => onRejectDraft(art.id)}
                className="px-3 py-2 bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 text-xs font-semibold rounded-lg border border-slate-700"
              >
                Reject
              </button>

              <button
                onClick={() => onApprovePublish(art.id)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm"
              >
                Approve & Publish
              </button>
            </div>
          </div>
        ))}

        {pending.length === 0 && (
          <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-slate-500 text-xs">
            No drafts currently awaiting editorial review.
          </div>
        )}
      </div>
    </div>
  );
};
