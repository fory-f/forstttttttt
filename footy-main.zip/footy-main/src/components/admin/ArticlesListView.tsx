import React, { useState } from 'react';
import { Article, Category } from '../../types';
import {
  Plus,
  Search,
  Filter,
  Trash2,
  Edit,
  ExternalLink,
  CheckCircle,
  Clock,
  AlertTriangle,
  History
} from 'lucide-react';

interface ArticlesListViewProps {
  articles: Article[];
  categories: Category[];
  onNewArticle: () => void;
  onEditArticle: (id: string) => void;
  onDeleteArticle: (id: string) => Promise<void>;
  onNavigatePublic: (path: string) => void;
}

export const ArticlesListView: React.FC<ArticlesListViewProps> = ({
  articles,
  categories,
  onNewArticle,
  onEditArticle,
  onDeleteArticle,
  onNavigatePublic
}) => {
  const [activeStatus, setActiveStatus] = useState<string>('all');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const filtered = articles.filter(a => {
    if (activeStatus !== 'all' && a.status !== activeStatus) return false;
    if (selectedCat !== 'all' && a.categoryId !== selectedCat) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        a.title.toLowerCase().includes(q) ||
        a.primaryFocusKeyword.toLowerCase().includes(q) ||
        a.slug.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleDelete = async (id: string) => {
    setIsDeleting(true);
    try {
      await onDeleteArticle(id);
      setDeleteConfirmId(null);
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Articles Catalog
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage, edit, schedule, and delete all editorial dispatches and drafts.
          </p>
        </div>

        <button
          onClick={onNewArticle}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Article</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
        {/* Status Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto">
          {['all', 'published', 'draft', 'scheduled', 'archived'].map(st => {
            const count = st === 'all' ? articles.length : articles.filter(a => a.status === st).length;
            const active = activeStatus === st;
            return (
              <button
                key={st}
                onClick={() => setActiveStatus(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {st} ({count})
              </button>
            );
          })}
        </div>

        {/* Filters Row */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, keyword, or slug..."
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCat}
              onChange={(e) => setSelectedCat(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 py-2 px-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Categories</option>
              {categories.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Articles Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Article Title</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5">Focus Keyword</th>
                <th className="px-4 py-3.5">AI SEO</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filtered.map(article => {
                const cat = categories.find(c => c.id === article.categoryId);
                return (
                  <tr key={article.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="px-5 py-4 max-w-sm">
                      <div className="font-bold text-slate-100 text-sm line-clamp-1">
                        {article.title}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        /article/{article.slug}
                      </div>
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className="bg-slate-800 text-slate-300 px-2 py-1 rounded text-[11px] font-medium border border-slate-700">
                        {cat?.name || 'Uncategorized'}
                      </span>
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap text-slate-400">
                      {article.primaryFocusKeyword ? (
                        <span className="text-indigo-400 font-medium font-mono text-[11px]">
                          "{article.primaryFocusKeyword}"
                        </span>
                      ) : (
                        <span className="text-slate-600">None</span>
                      )}
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap">
                      {article.aiSeoScore ? (
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                            article.aiSeoScore >= 90
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : article.aiSeoScore >= 75
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {article.aiSeoScore}/100
                        </span>
                      ) : (
                        <span className="text-slate-600">Unscored</span>
                      )}
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          article.status === 'published'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : article.status === 'scheduled'
                            ? 'bg-blue-500/20 text-blue-400'
                            : article.status === 'archived'
                            ? 'bg-slate-700 text-slate-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        {article.status}
                      </span>
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap text-[11px] text-slate-500">
                      {new Date(article.updatedAt || article.createdAt).toLocaleDateString()}
                    </td>

                    <td className="px-4 py-4 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-1">
                        {article.status === 'published' && (
                          <button
                            onClick={() => onNavigatePublic(`/article/${article.slug}`)}
                            className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="View Public Article"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => onEditArticle(article.id)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                          title="Open Editor"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(article.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                          title="Delete Article"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                    No articles match current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-500" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Permanently Delete Article?
                </h3>
                <p className="text-xs text-slate-400">
                  This mutation deletes the record and all associated revisions from the database.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono">
              ID: {deleteConfirmId}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirmId)}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? 'Deleting...' : 'Confirm Permanent Deletion'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
