import React from 'react';
import { SiteSettings } from '../../types';
import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  Cpu,
  Rss,
  Inbox,
  CheckSquare,
  Sparkles,
  Brain,
  Hash,
  Tags,
  Image,
  Settings,
  Activity,
  LogOut,
  ExternalLink,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

interface AdminLayoutProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onLogout: () => void;
  onNavigatePublic: (path: string) => void;
  settings: SiteSettings;
  queueCount: number;
  reviewCount: number;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onLogout,
  onNavigatePublic,
  settings,
  queueCount,
  reviewCount,
  children
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'articles', label: 'Articles Catalog', icon: FileText },
    { id: 'editor', label: 'Article Editor', icon: PlusCircle },
    { id: 'ai-workflow', label: '14-Stage AI Workflow', icon: Cpu },
    { id: 'rss', label: 'RSS Feeds', icon: Rss },
    { id: 'queue', label: 'Content Queue', icon: Inbox, badge: queueCount > 0 ? queueCount : undefined },
    { id: 'review', label: 'Review Queue', icon: CheckSquare, badge: reviewCount > 0 ? reviewCount : undefined },
    { id: 'magic', label: 'MAGIC AI Agent', icon: Sparkles, highlight: true },
    { id: 'memory', label: 'Project Memory', icon: Brain },
    { id: 'topics', label: 'Topics & Focus', icon: Hash },
    { id: 'taxonomy', label: 'Categories & Tags', icon: Tags },
    { id: 'media', label: 'Media Library', icon: Image },
    { id: 'settings', label: 'Settings & Tones', icon: Settings },
    { id: 'logs', label: 'Audit & AI Logs', icon: Activity },
  ];

  const modeBadgeColor =
    settings.publishMode === 'automatic'
      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
      : settings.publishMode === 'semi-automatic'
      ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
      : 'bg-indigo-500/20 text-indigo-400 border-indigo-500/40';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="h-16 border-b border-slate-800 bg-slate-900/90 backdrop-blur px-4 sm:px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div
            onClick={() => onSelectTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-base shadow-sm group-hover:bg-indigo-500 transition-colors">
              EP
            </div>
            <div>
              <span className="font-extrabold text-slate-100 text-base leading-none block">
                {settings.siteName} CMS
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400 block mt-0.5">
                Editorial Control Room
              </span>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 pl-4 border-l border-slate-800">
            <span className="text-xs text-slate-400">Publish Mode:</span>
            <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${modeBadgeColor}`}>
              {settings.publishMode}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onSelectTab('magic')}
            className="flex items-center gap-1.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-sm transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">MAGIC Copilot</span>
          </button>

          <button
            onClick={() => onNavigatePublic('/')}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            title="Open Public Site"
          >
            <span>Public Blog</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </button>

          <button
            onClick={onLogout}
            className="flex items-center gap-1 text-slate-400 hover:text-rose-400 text-xs font-medium p-1.5 rounded-lg hover:bg-slate-800 transition-colors ml-1"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900 border-r border-slate-800 flex-shrink-0 flex flex-col justify-between hidden md:flex">
          <div className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-8rem)]">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider px-3 py-2">
              Editorial Operations
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const active = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    active
                      ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                      : item.highlight
                      ? 'text-indigo-300 hover:bg-slate-800/80 hover:text-white'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${active ? 'text-white' : item.highlight ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* User profile footer in sidebar */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/60">
            <div className="flex items-center gap-2.5 px-2 py-1.5">
              <img
                src={settings.authorProfile.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80'}
                alt={settings.authorProfile.name}
                className="w-8 h-8 rounded-full object-cover border border-slate-700"
              />
              <div className="truncate">
                <span className="text-xs font-bold text-slate-200 block truncate">
                  {settings.authorProfile.name}
                </span>
                <span className="text-[10px] text-emerald-400 block font-medium">
                  Active Admin Session
                </span>
              </div>
            </div>
          </div>
        </aside>

        {/* Mobile Navigation Tabs */}
        <div className="md:hidden flex overflow-x-auto bg-slate-900 border-b border-slate-800 p-2 gap-1 flex-shrink-0">
          {navItems.slice(0, 7).map((item) => {
            const active = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap ${
                  active ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Main Content Area */}
        <main className="flex-1 bg-slate-950 p-4 sm:p-6 lg:p-8 overflow-y-auto max-h-[calc(100vh-4rem)]">
          {children}
        </main>
      </div>
    </div>
  );
};
