import React, { useState } from 'react';
import { RSSSource, Category, RSSItem } from '../../types';
import { api } from '../../services/api';
import {
  Rss,
  Plus,
  RefreshCw,
  Trash2,
  CheckCircle,
  AlertCircle,
  Clock,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';

interface RSSSourcesViewProps {
  sources: RSSSource[];
  categories: Category[];
  onRefreshSources: () => void;
  onNavigateQueue: () => void;
}

export const RSSSourcesView: React.FC<RSSSourcesViewProps> = ({
  sources,
  categories,
  onRefreshSources,
  onNavigateQueue
}) => {
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [url, setUrl] = useState<string>('');
  const [websiteName, setWebsiteName] = useState<string>('');
  const [defaultCatId, setDefaultCatId] = useState<string>(categories[0]?.id || 'cat-1');
  const [priority, setPriority] = useState<RSSSource['priority']>('medium');
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isFetchingAll, setIsFetchingAll] = useState<boolean>(false);
  const [fetchingId, setFetchingId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Test RSS URL
  const handleTestFeed = async () => {
    if (!url.trim()) return;
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await api.testRSSFeed(url.trim());
      setTestResult(res);
      if (res.valid && !name) {
        setName(res.title || 'RSS Feed');
        setWebsiteName(res.title || 'Publication');
      }
    } catch (err: any) {
      setTestResult({ valid: false, error: err.message });
    } finally {
      setIsTesting(false);
    }
  };

  // Add Source
  const handleAddSource = async () => {
    if (!url.trim() || !name.trim()) {
      alert('Please provide a name and valid RSS feed URL.');
      return;
    }

    setIsSaving(true);
    try {
      await api.saveRSSSource({
        name,
        url: url.trim(),
        websiteName: websiteName || name,
        enabled: true,
        defaultCategoryId: defaultCatId,
        defaultTags: ['news', 'rss'],
        priority,
        fetchFrequencyMinutes: 60
      });
      setShowAddModal(false);
      setName('');
      setUrl('');
      setWebsiteName('');
      setTestResult(null);
      onRefreshSources();
    } catch (err: any) {
      alert(`Failed to save RSS source: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Fetch single source
  const handleFetchOne = async (id: string) => {
    setFetchingId(id);
    try {
      const res = await api.fetchRSSSource(id);
      alert(`Fetched ${res.newItemsCount} new items from ${res.sourceName}.`);
      onRefreshSources();
    } catch (err: any) {
      alert(`Fetch failed: ${err.message}`);
    } finally {
      setFetchingId(null);
    }
  };

  // Fetch all active sources
  const handleFetchAll = async () => {
    setIsFetchingAll(true);
    try {
      const res = await api.fetchAllRSSSources();
      const totalNew = res.reduce((acc, r) => acc + (r.newItemsCount || 0), 0);
      alert(`Batch fetch complete! Ingested ${totalNew} new RSS items.`);
      onRefreshSources();
    } catch (err: any) {
      alert(`Batch fetch failed: ${err.message}`);
    } finally {
      setIsFetchingAll(false);
    }
  };

  // Delete source
  const handleDelete = async (id: string) => {
    try {
      await api.deleteRSSSource(id);
      setDeleteConfirmId(null);
      onRefreshSources();
    } catch (err: any) {
      alert(`Failed to delete RSS source: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            RSS Content Feeds & Signals
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Automate content discovery by subscribing to authoritative industry RSS & Atom feeds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleFetchAll}
            disabled={isFetchingAll}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold px-3.5 py-2 rounded-lg border border-slate-700 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFetchingAll ? 'animate-spin' : ''}`} />
            <span>{isFetchingAll ? 'Fetching All...' : 'Fetch All Feeds'}</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Feed Source</span>
          </button>
        </div>
      </div>

      {/* Sources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sources.map((src) => {
          const cat = categories.find(c => c.id === src.defaultCategoryId);
          return (
            <div
              key={src.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xs flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      {src.websiteName}
                    </span>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
                    {src.priority}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white leading-snug">
                  {src.name}
                </h3>

                <div className="text-xs text-slate-400 truncate font-mono bg-slate-950 p-2 rounded border border-slate-850">
                  {src.url}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <span>Default Desk: <strong className="text-slate-200">{cat?.name || 'General'}</strong></span>
                  <span>Items Ingested: <strong className="text-indigo-400">{src.itemCount}</strong></span>
                </div>

                {src.lastFetchedAt && (
                  <div className="text-[11px] text-slate-500">
                    Last polled: {new Date(src.lastFetchedAt).toLocaleString()}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => handleFetchOne(src.id)}
                  disabled={fetchingId === src.id}
                  className="flex items-center gap-1 text-xs font-semibold text-indigo-400 hover:text-indigo-300"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${fetchingId === src.id ? 'animate-spin' : ''}`} />
                  <span>{fetchingId === src.id ? 'Polling...' : 'Fetch Now'}</span>
                </button>

                <button
                  onClick={() => setDeleteConfirmId(src.id)}
                  className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                  title="Delete Source"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {sources.length === 0 && (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
          <Rss className="w-10 h-10 text-slate-600 mx-auto" />
          <p className="text-slate-300 font-semibold text-sm">No RSS sources configured yet.</p>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            Add top tech publications, research feeds, or press dispatches to begin automated discovery.
          </p>
        </div>
      )}

      {/* Add Source Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Rss className="w-5 h-5 text-amber-400" />
              <span>Connect New RSS / Atom Feed</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Feed URL (RSS 2.0 or Atom)</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://techcrunch.com/feed/ or https://hnrss.org/frontpage"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleTestFeed}
                    disabled={isTesting}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 rounded-lg border border-slate-700 font-semibold"
                  >
                    {isTesting ? 'Validating...' : 'Test Feed'}
                  </button>
                </div>
              </div>

              {testResult && (
                <div className={`p-3 rounded-lg border text-xs ${testResult.valid ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300' : 'bg-rose-950/40 border-rose-800 text-rose-300'}`}>
                  {testResult.valid ? (
                    <div>
                      <span className="font-bold block">Valid feed: {testResult.title}</span>
                      <span>Found {testResult.itemCount} items available for ingestion.</span>
                    </div>
                  ) : (
                    <div>
                      <span className="font-bold block">Feed validation error</span>
                      <span>{testResult.error || 'Failed to parse RSS XML.'}</span>
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className="text-slate-400 block mb-1">Feed Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Hacker News Top Dispatches"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Publication Name</label>
                <input
                  type="text"
                  value={websiteName}
                  onChange={(e) => setWebsiteName(e.target.value)}
                  placeholder="e.g. Hacker News"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Default Desk</label>
                  <select
                    value={defaultCatId}
                    onChange={(e) => setDefaultCatId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300"
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddSource}
                disabled={isSaving}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-sm"
              >
                {isSaving ? 'Saving...' : 'Add Feed'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Source Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2 text-rose-400">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              <span>Delete RSS Feed Source?</span>
            </h3>
            <p className="text-xs text-slate-400">
              This stops automated ingestion from this source. Existing ingested items will be preserved.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface ContentQueueViewProps {
  items: RSSItem[];
  onProcessItem: (item: RSSItem) => void;
  onRefreshQueue: () => void;
}

export const ContentQueueView: React.FC<ContentQueueViewProps> = ({
  items,
  onProcessItem,
  onRefreshQueue
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const filtered = items.filter(i => {
    if (filterStatus !== 'all' && i.status !== filterStatus) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        i.originalTitle.toLowerCase().includes(q) ||
        i.sourceName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleUpdateStatus = async (id: string, status: RSSItem['status']) => {
    try {
      await api.updateRSSItem(id, { status });
      onRefreshQueue();
    } catch (err: any) {
      alert(`Update failed: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteRSSItem(id);
      onRefreshQueue();
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            RSS Content Discovery Queue
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Review incoming news stories and transform them into original investigative articles with Gemini.
          </p>
        </div>

        <button
          onClick={onRefreshQueue}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Filters & Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto">
          {['all', 'NEW', 'SELECTED', 'PROCESSED', 'SKIPPED'].map((st) => {
            const count = st === 'all' ? items.length : items.filter(i => i.status === st).length;
            const active = filterStatus === st;
            return (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  active ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {st} ({count})
              </button>
            );
          })}
        </div>

        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter queue..."
          className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 w-full sm:w-64"
        />
      </div>

      {/* Queue Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-400">{item.sourceName}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                  item.status === 'NEW' ? 'bg-indigo-500/20 text-indigo-400' :
                  item.status === 'PROCESSED' ? 'bg-emerald-500/20 text-emerald-400' :
                  item.status === 'SKIPPED' ? 'bg-slate-800 text-slate-500' : 'bg-slate-800 text-slate-400'
                }`}>
                  {item.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-100 leading-snug">
                {item.originalTitle}
              </h3>

              <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                {item.description || 'No raw excerpt provided.'}
              </p>

              <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500">
                <a
                  href={item.originalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 hover:text-slate-300"
                >
                  <span>Primary source</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span>Published: {new Date(item.publicationDate).toLocaleDateString()}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {item.status !== 'SKIPPED' && (
                  <button
                    onClick={() => handleUpdateStatus(item.id, 'SKIPPED')}
                    className="text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-800 rounded"
                  >
                    Skip
                  </button>
                )}
                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-1 text-slate-500 hover:text-rose-400"
                  title="Remove from queue"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={() => onProcessItem(item)}
                className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3.5 py-1.5 rounded-lg shadow-xs"
              >
                <Rss className="w-3 h-3 text-indigo-300" />
                <span>Process with AI</span>
              </button>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="col-span-2 text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-slate-500 text-xs">
            No items in queue match filter.
          </div>
        )}
      </div>
    </div>
  );
};
