import React, { useState, useEffect } from 'react';
import { AgentActivityLog, AIUsageLog } from '../../types';
import { api } from '../../services/api';
import { Activity, ShieldAlert, Cpu, CheckCircle, AlertTriangle, ExternalLink, RefreshCw } from 'lucide-react';

interface LogsViewProps {
  onEditArticle: (id: string) => void;
}

export const LogsView: React.FC<LogsViewProps> = ({ onEditArticle }) => {
  const [activeTab, setActiveTab] = useState<'seo' | 'agent' | 'usage'>('seo');
  const [seoAudit, setSeoAudit] = useState<any>(null);
  const [agentLogs, setAgentLogs] = useState<AgentActivityLog[]>([]);
  const [aiUsageLogs, setAiUsageLogs] = useState<AIUsageLog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [audit, aLogs, uLogs] = await Promise.all([
        api.getSeoAuditCatalog(),
        api.getAgentLogs(),
        api.getAiUsageLogs()
      ]);
      setSeoAudit(audit);
      setAgentLogs(aLogs);
      setAiUsageLogs(uLogs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Activity className="w-6 h-6 text-indigo-400" />
            <span>Audit, SEO Health & AI Usage Logs</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time catalog crawlability diagnostics, agent action audit trail, and Gemini token logs.
          </p>
        </div>

        <button
          onClick={loadData}
          disabled={isLoading}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Diagnostics</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 text-xs font-semibold">
        {[
          { id: 'seo', label: 'Catalog SEO Audit' },
          { id: 'agent', label: 'Agent Action Audit Trail' },
          { id: 'usage', label: 'AI Usage & Operations Log' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === t.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: Catalog SEO Audit */}
      {activeTab === 'seo' && seoAudit && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <span className="text-xs text-slate-400 block mb-1">Average Catalog SEO Score</span>
              <span className="text-3xl font-extrabold text-emerald-400 block">
                {seoAudit.averageScore}<span className="text-sm text-slate-500 font-normal">/100</span>
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">Across all published articles</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <span className="text-xs text-slate-400 block mb-1">Missing Meta Descriptions</span>
              <span className={`text-3xl font-extrabold block ${seoAudit.missingMetaCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                {seoAudit.missingMetaCount}
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">Search engine snippet health</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <span className="text-xs text-slate-400 block mb-1">Low AI SEO Scores (&lt;80)</span>
              <span className={`text-3xl font-extrabold block ${seoAudit.lowSeoScoresCount > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                {seoAudit.lowSeoScoresCount}
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">Articles requiring refinement</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <span className="text-xs text-slate-400 block mb-1">Missing Hero Images</span>
              <span className="text-3xl font-extrabold text-slate-300 block">
                {seoAudit.missingFeaturedImageCount}
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">OpenGraph card completeness</span>
            </div>
          </div>

          {/* Critical Issues List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <span>Diagnosed Editorial & Indexing Issues ({seoAudit.criticalIssues.length})</span>
            </h3>

            <div className="divide-y divide-slate-800">
              {seoAudit.criticalIssues.map((issue: any, idx: number) => (
                <div key={idx} className="py-3.5 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h4 className="font-bold text-slate-200 text-xs sm:text-sm">{issue.title}</h4>
                    <p className="text-xs text-amber-300/90">{issue.issue}</p>
                  </div>
                  <button
                    onClick={() => onEditArticle(issue.articleId)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-lg text-xs font-semibold whitespace-nowrap"
                  >
                    Fix in Editor &rarr;
                  </button>
                </div>
              ))}

              {seoAudit.criticalIssues.length === 0 && (
                <div className="py-8 text-center text-xs text-emerald-400 flex items-center justify-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>100% of published articles meet high technical and editorial SEO standards!</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Agent Action Audit Trail */}
      {activeTab === 'agent' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Timestamp</th>
                  <th className="px-4 py-3.5">Agent / Operator</th>
                  <th className="px-4 py-3.5">Action</th>
                  <th className="px-5 py-3.5">Details</th>
                  <th className="px-4 py-3.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {agentLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="px-5 py-3 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-bold text-white">
                      {log.agent}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-indigo-400 text-[11px]">
                      {log.action}
                    </td>
                    <td className="px-5 py-3 text-slate-300 max-w-md">
                      {log.details}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: AI Usage Logs */}
      {activeTab === 'usage' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/70 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Timestamp</th>
                  <th className="px-4 py-3.5">Operation</th>
                  <th className="px-4 py-3.5">Article Title</th>
                  <th className="px-4 py-3.5">Model</th>
                  <th className="px-4 py-3.5">Tokens</th>
                  <th className="px-4 py-3.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {aiUsageLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="px-5 py-3 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-semibold text-white">
                      {log.operation}
                    </td>
                    <td className="px-4 py-3 text-slate-300 max-w-xs truncate">
                      {log.articleTitle || '-'}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-indigo-400 text-[11px]">
                      {log.model}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-400">
                      {log.tokenCount ? `${log.tokenCount} tokens` : '-'}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
