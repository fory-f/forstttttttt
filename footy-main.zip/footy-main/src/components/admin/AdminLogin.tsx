import React, { useState } from 'react';
import { Lock, ShieldCheck, ArrowLeft } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (password: string) => Promise<void>;
  onCancel: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onCancel }) => {
  const [password, setPassword] = useState<string>('editorial2026');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;
    setIsLoading(true);
    setError('');
    try {
      await onLogin(password);
    } catch (err: any) {
      setError(err.message || 'Invalid password credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-8 space-y-6 shadow-2xl">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mx-auto shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            EditorialPulse CMS Access
          </h1>
          <p className="text-xs text-slate-400">
            Sign in to access the AI generation studio, RSS automation queue, and editorial desk controls.
          </p>
        </div>

        {error && (
          <div className="bg-rose-950/50 border border-rose-800 text-rose-300 text-xs p-3 rounded-xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="text-slate-300 font-semibold block mb-1.5">
              Admin Master Passkey
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter master passkey..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-mono"
              autoFocus
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Default demo passkey: <code className="text-indigo-400">editorial2026</code>
            </span>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isLoading ? 'Verifying...' : 'Authenticate into CMS'}</span>
          </button>
        </form>

        <div className="pt-2 text-center">
          <button
            onClick={onCancel}
            className="text-xs text-slate-500 hover:text-slate-300 inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-3 h-3" />
            <span>Return to Public Publication</span>
          </button>
        </div>
      </div>
    </div>
  );
};
