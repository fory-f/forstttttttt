import React, { useState } from 'react';
import { Article, Category, SiteSettings } from '../../types';
import { ArticleCard } from './ArticleCard';
import { Sparkles, ArrowRight, Rss, Layers, CheckCircle2 } from 'lucide-react';

interface PublicHomeProps {
  articles: Article[];
  categories: Category[];
  settings: SiteSettings;
  onNavigate: (path: string) => void;
}

export const PublicHome: React.FC<PublicHomeProps> = ({
  articles,
  categories,
  settings,
  onNavigate
}) => {
  const [selectedCatId, setSelectedCatId] = useState<string | 'all'>('all');

  const published = articles.filter(a => a.status === 'published');
  const featuredArticle = published[0];
  const secondaryArticles = published.slice(1);

  const filteredArticles = selectedCatId === 'all'
    ? secondaryArticles
    : secondaryArticles.filter(a => a.categoryId === selectedCatId);

  const author = settings.authorProfile;

  return (
    <div className="space-y-16 pb-12">
      {/* Editorial Mission Hero Banner */}
      <section className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute -right-20 -top-20 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold px-3 py-1 rounded-full mb-6">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI-Assisted Editorial Excellence &bull; Google Gemini Integrated</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight text-white mb-6">
            {settings.siteName}
          </h1>

          <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed mb-8">
            {settings.tagline}. We deliver rigorously investigated analyses covering semantic SEO, crawlable web architectures, generative AI models, and modern publishing systems.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#latest-dispatches"
              className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-3 rounded-xl font-semibold text-sm shadow-md transition-all"
            >
              <span>Explore Dispatches</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <a
              href="/rss.xml"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 px-5 py-3 rounded-xl font-semibold text-sm transition-all"
            >
              <Rss className="w-4 h-4" />
              <span>Subscribe to RSS 2.0</span>
            </a>
          </div>
        </div>
      </section>

      {/* Featured Lead Story */}
      {featuredArticle && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              Lead Editorial Investigation
            </h2>
            <span className="text-xs text-slate-500 font-medium">Top Priority Dispatch</span>
          </div>

          <ArticleCard
            article={featuredArticle}
            category={categories.find(c => c.id === featuredArticle.categoryId)}
            onNavigate={onNavigate}
            featured={true}
          />
        </section>
      )}

      {/* Category Desk Selector */}
      <section id="latest-dispatches" className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              Latest Editorial Catalog
            </h2>
            <p className="text-sm text-slate-500">
              Verified analyses, architectural breakdowns, and editorial guides.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setSelectedCatId('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCatId === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Topics ({published.length})
            </button>
            {categories.map(cat => {
              const count = published.filter(a => a.categoryId === cat.id).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCatId(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    selectedCatId === cat.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat.name} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Articles Grid */}
        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.map(article => (
              <ArticleCard
                key={article.id}
                article={article}
                category={categories.find(c => c.id === article.categoryId)}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
            <Layers className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-slate-600 font-medium">No articles published in this category yet.</p>
            <p className="text-xs text-slate-400 mt-1">Check back soon or select another editorial category.</p>
          </div>
        )}
      </section>

      {/* Editor-in-Chief E-E-A-T Spotlight */}
      <section className="bg-gradient-to-br from-slate-50 to-indigo-50/40 border border-indigo-100 rounded-3xl p-8 sm:p-10">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-8">
          <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl overflow-hidden shadow-lg border-2 border-white flex-shrink-0">
            <img
              src={author.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80'}
              alt={author.name}
              width={144}
              height={144}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-3 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 uppercase tracking-wider bg-indigo-100/80 px-2.5 py-1 rounded-md">
              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>Verified Editorial Authority &bull; E-E-A-T Standard</span>
            </div>

            <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Meet {author.name}
            </h3>

            <p className="text-sm text-slate-700 leading-relaxed">
              {author.shortBio}
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 text-xs text-slate-600">
              <span className="font-semibold text-slate-900">Expertise:</span>
              {author.expertise.map((exp, idx) => (
                <span key={idx} className="bg-white border border-slate-200 px-2.5 py-0.5 rounded-md font-medium text-slate-700">
                  {exp}
                </span>
              ))}
            </div>

            <div className="pt-2">
              <a
                href={`/author/${author.slug}`}
                onClick={(e) => { e.preventDefault(); onNavigate(`/author/${author.slug}`); }}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 underline inline-flex items-center gap-1"
              >
                <span>Read full professional bio and published dispatches</span>
                <ArrowRight className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
