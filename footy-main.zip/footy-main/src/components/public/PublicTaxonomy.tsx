import React from 'react';
import { Article, Category, Tag, AuthorProfile } from '../../types';
import { ArticleCard } from './ArticleCard';
import { ChevronRight, Folder, Tag as TagIcon, UserCheck, Search } from 'lucide-react';

interface CategoryViewProps {
  category: Category;
  articles: Article[];
  categories: Category[];
  onNavigate: (path: string) => void;
}

export const PublicCategory: React.FC<CategoryViewProps> = ({
  category,
  articles,
  categories,
  onNavigate
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      <nav aria-label="Breadcrumb" className="text-xs text-slate-500 flex items-center gap-1.5">
        <a href="/" onClick={(e) => { e.preventDefault(); onNavigate('/'); }} className="hover:text-indigo-600">
          Home
        </a>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        <span className="text-slate-900 font-semibold">{category.name}</span>
      </nav>

      <header className="bg-slate-50 border border-slate-200 rounded-3xl p-8 sm:p-12 relative overflow-hidden">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 uppercase tracking-wider bg-indigo-100/80 px-3 py-1 rounded-full">
            <Folder className="w-3.5 h-3.5 text-indigo-600" />
            <span>Topical Desk</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
            {category.name}
          </h1>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {category.description}
          </p>
        </div>
      </header>

      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <h2 className="text-xl font-bold text-slate-900">
            Articles in {category.name} ({articles.length})
          </h2>
        </div>

        {articles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                category={category}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-50 rounded-2xl">
            <p className="text-slate-600">No published dispatches under this desk yet.</p>
          </div>
        )}
      </section>
    </div>
  );
};

interface TagViewProps {
  tag: string;
  articles: Article[];
  categories: Category[];
  onNavigate: (path: string) => void;
}

export const PublicTag: React.FC<TagViewProps> = ({
  tag,
  articles,
  categories,
  onNavigate
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      <nav aria-label="Breadcrumb" className="text-xs text-slate-500 flex items-center gap-1.5">
        <a href="/" onClick={(e) => { e.preventDefault(); onNavigate('/'); }} className="hover:text-indigo-600">
          Home
        </a>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        <span className="text-slate-900 font-semibold">#{tag}</span>
      </nav>

      <header className="bg-slate-50 border border-slate-200 rounded-3xl p-8 sm:p-10">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 uppercase tracking-wider bg-indigo-100/80 px-3 py-1 rounded-full mb-3">
          <TagIcon className="w-3.5 h-3.5 text-indigo-600" />
          <span>Semantic Tag Entity</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Articles tagged #{tag}
        </h1>
        <p className="text-sm text-slate-600 mt-2">
          Curated index of all published editorial investigations mentioning {tag}.
        </p>
      </header>

      <section className="space-y-6">
        {articles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                category={categories.find(c => c.id === art.categoryId)}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-50 rounded-2xl">
            <p className="text-slate-600">No published articles match this entity tag.</p>
          </div>
        )}
      </section>
    </div>
  );
};

interface AuthorViewProps {
  author: AuthorProfile;
  articles: Article[];
  categories: Category[];
  onNavigate: (path: string) => void;
}

export const PublicAuthor: React.FC<AuthorViewProps> = ({
  author,
  articles,
  categories,
  onNavigate
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      <nav aria-label="Breadcrumb" className="text-xs text-slate-500 flex items-center gap-1.5">
        <a href="/" onClick={(e) => { e.preventDefault(); onNavigate('/'); }} className="hover:text-indigo-600">
          Home
        </a>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        <span className="text-slate-900 font-semibold">{author.name}</span>
      </nav>

      <header className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
          <img
            src={author.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80'}
            alt={author.name}
            width={120}
            height={120}
            className="w-28 h-28 rounded-2xl object-cover border-2 border-slate-700 shadow-xl"
          />
          <div className="space-y-4 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Verified Author &bull; E-E-A-T Authenticated</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              {author.name}
            </h1>
            <p className="text-sm font-medium text-indigo-400">
              {author.credentials} &bull; {author.organization}
            </p>
            <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
              {author.fullBio}
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-2 text-xs">
              <span className="font-semibold text-white">Areas of Focus:</span>
              {author.expertise.map((exp, i) => (
                <span key={i} className="bg-slate-800 text-slate-200 px-2.5 py-1 rounded-md font-medium border border-slate-700">
                  {exp}
                </span>
              ))}
            </div>
          </div>
        </div>
      </header>

      <section className="space-y-6">
        <h2 className="text-2xl font-bold text-slate-900">
          Published Articles by {author.name} ({articles.length})
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((art) => (
            <ArticleCard
              key={art.id}
              article={art}
              category={categories.find(c => c.id === art.categoryId)}
              onNavigate={onNavigate}
            />
          ))}
        </div>
      </section>
    </div>
  );
};

interface SearchViewProps {
  articles: Article[];
  categories: Category[];
  onNavigate: (path: string) => void;
  initialQuery?: string;
}

export const PublicSearch: React.FC<SearchViewProps> = ({
  articles,
  categories,
  onNavigate,
  initialQuery = ''
}) => {
  const [query, setQuery] = React.useState(initialQuery);

  const q = query.trim().toLowerCase();
  const results = q
    ? articles.filter(a =>
        a.status === 'published' &&
        (a.title.toLowerCase().includes(q) ||
          a.content.toLowerCase().includes(q) ||
          a.primaryFocusKeyword.toLowerCase().includes(q) ||
          a.tags.some(t => t.toLowerCase().includes(q)))
      )
    : [];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <div className="text-center space-y-3">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Search Editorial Archive
        </h1>
        <p className="text-sm text-slate-600">
          Query our full catalog of investigative analyses, semantic SEO benchmarks, and tech dispatches.
        </p>

        <div className="relative max-w-xl mx-auto pt-4">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-7" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search keywords, topics, or article titles..."
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 text-sm shadow-xs"
            autoFocus
          />
        </div>
      </div>

      <div className="space-y-4 pt-4">
        {q ? (
          <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-200 pb-2">
            <span>Found {results.length} results matching "{query}"</span>
          </div>
        ) : (
          <p className="text-center text-xs text-slate-400 py-8">
            Type a query above to search articles across all editorial categories.
          </p>
        )}

        {results.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {results.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                category={categories.find(c => c.id === art.categoryId)}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
