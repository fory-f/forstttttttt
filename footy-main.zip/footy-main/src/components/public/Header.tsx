import React from 'react';
import { SiteSettings, Category } from '../../types';
import { Sparkles, Search, Rss, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  settings: SiteSettings;
  categories: Category[];
  currentPath: string;
  onNavigate: (path: string) => void;
  isAdminAuthenticated: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  categories,
  currentPath,
  onNavigate,
  isAdminAuthenticated
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      {/* Top microbar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Live Editorial Publication
            </span>
            <span className="hidden sm:inline text-slate-500">|</span>
            <span className="hidden sm:inline text-slate-400">Independent Technology & AI Journalism</span>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <a
              href="/rss.xml"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white flex items-center gap-1 text-amber-400 font-medium transition-colors"
            >
              <Rss className="w-3.5 h-3.5" />
              <span>RSS Feed</span>
            </a>
            <a
              href="/sitemap.xml"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white text-slate-400 transition-colors hidden md:inline"
            >
              Sitemap
            </a>
            <button
              onClick={() => onNavigate('/admin')}
              className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-0.5 rounded text-xs font-medium transition-colors"
            >
              <ShieldCheck className="w-3 h-3 text-indigo-400" />
              <span>{isAdminAuthenticated ? 'Admin CMS' : 'Editor Login'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <a
            href="/"
            onClick={(e) => { e.preventDefault(); onNavigate('/'); }}
            className="flex items-center gap-2.5 text-slate-900 group"
          >
            <div className="w-10 h-10 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xl shadow-md group-hover:bg-indigo-700 transition-colors">
              EP
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-slate-900 block leading-tight">
                {settings.siteName}
              </span>
              <span className="text-[11px] uppercase tracking-wider font-semibold text-indigo-600 block">
                Editorial & Intelligence
              </span>
            </div>
          </a>
        </div>

        {/* Categories Nav */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
          <a
            href="/"
            onClick={(e) => { e.preventDefault(); onNavigate('/'); }}
            className={`transition-colors hover:text-indigo-600 ${currentPath === '/' ? 'text-indigo-600 font-semibold' : ''}`}
          >
            All Dispatches
          </a>
          {categories.slice(0, 4).map((cat) => {
            const path = `/category/${cat.slug}`;
            const active = currentPath === path;
            return (
              <a
                key={cat.id}
                href={path}
                onClick={(e) => { e.preventDefault(); onNavigate(path); }}
                className={`transition-colors hover:text-indigo-600 ${active ? 'text-indigo-600 font-semibold' : ''}`}
              >
                {cat.name}
              </a>
            );
          })}
        </nav>

        {/* Search & Action button */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('/search')}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-600 px-3.5 py-2 rounded-full text-xs font-medium transition-colors"
            title="Search editorial articles"
          >
            <Search className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Search archive...</span>
          </button>

          <button
            onClick={() => onNavigate('/admin/magic')}
            className="hidden sm:flex items-center gap-1.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white px-3.5 py-2 rounded-lg text-xs font-semibold shadow-sm transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>MAGIC Agent</span>
          </button>
        </div>
      </div>
    </header>
  );
};
