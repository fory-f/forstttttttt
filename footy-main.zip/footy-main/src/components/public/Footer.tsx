import React from 'react';
import { SiteSettings, Category } from '../../types';
import { Rss, FileText, Lock, Globe } from 'lucide-react';

interface FooterProps {
  settings: SiteSettings;
  categories: Category[];
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, categories, onNavigate }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-sm border-t border-slate-800 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-slate-800">
          {/* Col 1: About & Mission */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5 text-white mb-3">
              <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center font-bold text-base">
                EP
              </div>
              <span className="font-bold text-lg text-white">{settings.siteName}</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed mb-4">
              {settings.siteDescription}
            </p>
            <div className="flex items-center gap-3 text-xs text-slate-500">
              <Globe className="w-3.5 h-3.5" />
              <span>Global Technology & SEO Authority</span>
            </div>
          </div>

          {/* Col 2: Editorial Categories */}
          <div>
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider mb-4">
              Topical Desks
            </h4>
            <ul className="space-y-2 text-xs">
              {categories.map((cat) => (
                <li key={cat.id}>
                  <a
                    href={`/category/${cat.slug}`}
                    onClick={(e) => { e.preventDefault(); onNavigate(`/category/${cat.slug}`); }}
                    className="hover:text-indigo-400 transition-colors"
                  >
                    {cat.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Technical & SEO Infrastructure */}
          <div>
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider mb-4">
              Search & Machine Feeds
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="/rss.xml"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-amber-400 transition-colors text-amber-300/90"
                >
                  <Rss className="w-3.5 h-3.5" />
                  <span>Public RSS 2.0 Feed (/rss.xml)</span>
                </a>
              </li>
              <li>
                <a
                  href="/sitemap.xml"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-indigo-400 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>XML Sitemap (/sitemap.xml)</span>
                </a>
              </li>
              <li>
                <a
                  href="/robots.txt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-indigo-400 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Robots Directives (/robots.txt)</span>
                </a>
              </li>
              <li>
                <span className="text-slate-500 block pt-1">
                  Schema: JSON-LD Article, BreadcrumbList, WebSite, Organization
                </span>
              </li>
            </ul>
          </div>

          {/* Col 4: Editorial Governance */}
          <div>
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider mb-4">
              Governance & Admin
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              All editorial content adheres to human-in-the-loop verification, verified factual RSS extraction, and strict anti-plagiarism guidelines.
            </p>
            <button
              onClick={() => onNavigate('/admin')}
              className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-indigo-300 hover:text-white px-3 py-1.5 rounded text-xs font-medium border border-slate-700 transition-colors"
            >
              <Lock className="w-3 h-3 text-indigo-400" />
              <span>Admin Editorial CMS</span>
            </button>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} {settings.siteName}. Published with Google Gemini & Semantic SEO Architecture.
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-600">Sub-second LCP &bull; 100% Crawlable HTML</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
