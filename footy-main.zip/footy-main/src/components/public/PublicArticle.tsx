import React from 'react';
import { Article, Category, SiteSettings } from '../../types';
import { ArticleCard } from './ArticleCard';
import {
  Calendar,
  Clock,
  User,
  Tag as TagIcon,
  ChevronRight,
  Share2,
  Bookmark,
  CheckCircle2,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

interface PublicArticleProps {
  article: Article;
  category?: Category;
  relatedArticles: Article[];
  settings: SiteSettings;
  onNavigate: (path: string) => void;
}

export const PublicArticle: React.FC<PublicArticleProps> = ({
  article,
  category,
  relatedArticles,
  settings,
  onNavigate
}) => {
  const author = settings.authorProfile;
  const pubDate = article.publishedAt
    ? new Date(article.publishedAt).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      })
    : 'Recent';

  const updatedDate = article.updatedAt && article.updatedAt !== article.publishedAt
    ? new Date(article.updatedAt).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      })
    : null;

  const wordCount = article.content.replace(/<[^>]+>/g, ' ').split(/\s+/).filter(Boolean).length;
  const readMinutes = Math.max(1, Math.round(wordCount / 200));

  const shareUrl = typeof window !== 'undefined' ? window.location.href : `https://editorialpulse.com/article/${article.slug}`;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.leadSummary || article.excerpt,
        url: shareUrl
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareUrl);
      alert('Article link copied to clipboard!');
    }
  };

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-10">
      {/* Semantic Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="text-xs text-slate-500 flex items-center flex-wrap gap-1.5">
        <a
          href="/"
          onClick={(e) => { e.preventDefault(); onNavigate('/'); }}
          className="hover:text-indigo-600 transition-colors"
        >
          Home
        </a>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        {category ? (
          <>
            <a
              href={`/category/${category.slug}`}
              onClick={(e) => { e.preventDefault(); onNavigate(`/category/${category.slug}`); }}
              className="hover:text-indigo-600 transition-colors font-medium text-slate-700"
            >
              {category.name}
            </a>
            <ChevronRight className="w-3 h-3 text-slate-400" />
          </>
        ) : null}
        <span className="text-slate-400 truncate max-w-[200px] sm:max-w-md">
          {article.title}
        </span>
      </nav>

      {/* Article Header */}
      <header className="space-y-6">
        {category && (
          <div>
            <a
              href={`/category/${category.slug}`}
              onClick={(e) => { e.preventDefault(); onNavigate(`/category/${category.slug}`); }}
              className="inline-block bg-indigo-50 border border-indigo-200/80 text-indigo-700 hover:bg-indigo-100 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full transition-colors"
            >
              {category.name}
            </a>
          </div>
        )}

        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.15]">
          {article.title}
        </h1>

        {article.leadSummary && (
          <p className="text-lg sm:text-xl text-slate-600 leading-relaxed font-normal border-l-4 border-indigo-600 pl-4 py-0.5 bg-slate-50/50 rounded-r-lg">
            {article.leadSummary}
          </p>
        )}

        {/* Metadata & Author Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 py-4 border-y border-slate-200/80">
          <div className="flex items-center gap-3">
            <img
              src={author.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80'}
              alt={author.name}
              width={44}
              height={44}
              className="w-11 h-11 rounded-full object-cover border border-slate-200 shadow-xs"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <a
                  href={`/author/${author.slug}`}
                  onClick={(e) => { e.preventDefault(); onNavigate(`/author/${author.slug}`); }}
                  className="text-sm font-bold text-slate-900 hover:text-indigo-600 transition-colors"
                >
                  {article.authorName}
                </a>
                <span title="Verified Author (E-E-A-T)">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {author.credentials}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              <div>
                <time dateTime={article.publishedAt}>{pubDate}</time>
                {updatedDate && (
                  <span className="block text-[10px] text-slate-400">
                    Updated: {updatedDate}
                  </span>
                )}
              </div>
            </div>

            <span>&bull;</span>

            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>{readMinutes} min read</span>
            </div>

            <button
              onClick={handleShare}
              className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ml-2"
              title="Share article"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>
          </div>
        </div>
      </header>

      {/* Featured Hero Image */}
      <figure className="space-y-2">
        <div className="rounded-2xl overflow-hidden shadow-md bg-slate-100 aspect-[16/9]">
          <img
            src={article.featuredImage || 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&h=675&fit=crop&q=80'}
            alt={article.featuredImageAlt || article.title}
            width={1200}
            height={675}
            className="w-full h-full object-cover"
            fetchPriority="high"
          />
        </div>
        {article.featuredImageAlt && (
          <figcaption className="text-xs text-center text-slate-500 italic">
            {article.featuredImageAlt}
          </figcaption>
        )}
      </figure>

      {/* Main Semantic Article Content */}
      <section
        className="prose prose-slate prose-lg max-w-none prose-headings:font-bold prose-headings:tracking-tight prose-h2:text-2xl sm:prose-h2:text-3xl prose-h2:mt-10 prose-h2:mb-4 prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3 prose-p:text-slate-700 prose-p:leading-relaxed prose-li:text-slate-700 prose-blockquote:border-l-indigo-600 prose-blockquote:text-slate-800 prose-blockquote:italic prose-a:text-indigo-600 prose-a:font-semibold prose-a:underline hover:prose-a:text-indigo-800"
        dangerouslySetInnerHTML={{ __html: article.content }}
      />

      {/* Source Attribution if from RSS */}
      {article.sourceUrl && (
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
          <div className="font-semibold text-slate-800">Original Reporting & Verification Attribution:</div>
          <p>
            This editorial investigation synthesizes verified reporting from primary news source{' '}
            <span className="font-medium text-slate-900">{article.sourceTitle || 'RSS dispatch'}</span>.
          </p>
          <a
            href={article.sourceUrl}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="inline-flex items-center gap-1 text-indigo-600 hover:underline font-medium pt-1"
          >
            <span>Inspect primary source document</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}

      {/* Taxonomy & Tags Cloud */}
      {article.tags && article.tags.length > 0 && (
        <div className="pt-6 border-t border-slate-200">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
            <TagIcon className="w-3.5 h-3.5 text-indigo-600" />
            <span>Indexed Topics & Entities:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {article.tags.map((tag, idx) => {
              const tagSlug = tag.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-');
              return (
                <a
                  key={idx}
                  href={`/tag/${tagSlug}`}
                  onClick={(e) => { e.preventDefault(); onNavigate(`/tag/${tagSlug}`); }}
                  className="bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 text-xs px-3 py-1.5 rounded-lg border border-slate-200/80 transition-colors font-medium"
                >
                  #{tag}
                </a>
              );
            })}
          </div>
        </div>
      )}

      {/* Author Profile Box (E-E-A-T) */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <img
            src={author.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80'}
            alt={author.name}
            width={80}
            height={80}
            className="w-20 h-20 rounded-2xl object-cover border-2 border-white shadow-md flex-shrink-0"
          />
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Editorial Reviewer & Author
              </span>
              <span className="text-slate-300">&bull;</span>
              <span className="text-xs text-slate-500">Editor-in-Chief</span>
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">
              {author.name}
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              {author.fullBio}
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs font-semibold text-indigo-600">
              <a href={author.website} target="_blank" rel="noopener noreferrer" className="hover:underline">
                Personal Website
              </a>
              <a href={author.socialTwitter} target="_blank" rel="noopener noreferrer" className="hover:underline">
                Twitter / X
              </a>
              <a href={author.socialLinkedin} target="_blank" rel="noopener noreferrer" className="hover:underline">
                LinkedIn Profile
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="pt-10 border-t border-slate-200 space-y-6">
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            Related Dispatches & Deep-Dives
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {relatedArticles.slice(0, 2).map((rel) => (
              <ArticleCard
                key={rel.id}
                article={rel}
                category={category}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        </section>
      )}
    </article>
  );
};
