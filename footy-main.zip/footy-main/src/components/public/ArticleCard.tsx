import React from 'react';
import { Article, Category } from '../../types';
import { Calendar, Clock, ArrowRight } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  category?: Category;
  onNavigate: (path: string) => void;
  featured?: boolean;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  article,
  category,
  onNavigate,
  featured = false
}) => {
  const url = `/article/${article.slug}`;
  const pubDate = article.publishedAt
    ? new Date(article.publishedAt).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      })
    : 'Recently';

  // Estimate read time
  const wordCount = article.content.replace(/<[^>]+>/g, ' ').split(/\s+/).filter(Boolean).length;
  const readMinutes = Math.max(1, Math.round(wordCount / 200));

  if (featured) {
    return (
      <article className="group relative bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Image */}
          <div className="lg:col-span-7 relative overflow-hidden bg-slate-100 min-h-[300px] lg:min-h-[420px]">
            <a
              href={url}
              onClick={(e) => {
                e.preventDefault();
                onNavigate(url);
              }}
              className="block w-full h-full"
            >
              <img
                src={article.featuredImage || 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&h=630&fit=crop&q=80'}
                alt={article.featuredImageAlt || article.title}
                width={1200}
                height={630}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                fetchPriority="high"
              />
            </a>
            <div className="absolute top-4 left-4">
              <span className="bg-indigo-600 text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider shadow">
                {category?.name || 'Featured Editorial'}
              </span>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <time dateTime={article.publishedAt}>{pubDate}</time>
                </span>
                <span>&bull;</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{readMinutes} min read</span>
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight mb-4 group-hover:text-indigo-600 transition-colors">
                <a
                  href={url}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(url);
                  }}
                  className="hover:underline"
                >
                  {article.title}
                </a>
              </h2>

              <p className="text-slate-600 text-sm sm:text-base leading-relaxed line-clamp-4 mb-6">
                {article.leadSummary || article.excerpt}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden font-semibold text-xs flex items-center justify-center text-slate-700">
                  {article.authorName.charAt(0)}
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-900 block leading-none">
                    {article.authorName}
                  </span>
                  <span className="text-[11px] text-slate-500 block">Editor-in-Chief</span>
                </div>
              </div>

              <a
                href={url}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate(url);
                }}
                className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                <span>Read dispatch</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="group bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-xs hover:shadow-md hover:border-slate-300 transition-all duration-200 flex flex-col justify-between">
      <div>
        <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
          <a
            href={url}
            onClick={(e) => {
              e.preventDefault();
              onNavigate(url);
            }}
            className="block w-full h-full"
          >
            <img
              src={article.featuredImage || 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=500&fit=crop&q=80'}
              alt={article.featuredImageAlt || article.title}
              width={600}
              height={375}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ease-out"
            />
          </a>
          <div className="absolute top-3 left-3">
            <span className="bg-slate-900/80 backdrop-blur text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-md shadow-xs">
              {category?.name || 'Article'}
            </span>
          </div>
        </div>

        <div className="p-5">
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-2.5">
            <time dateTime={article.publishedAt}>{pubDate}</time>
            <span>&bull;</span>
            <span>{readMinutes} min read</span>
          </div>

          <h3 className="text-lg font-bold text-slate-900 leading-snug tracking-tight mb-2.5 group-hover:text-indigo-600 transition-colors line-clamp-2">
            <a
              href={url}
              onClick={(e) => {
                e.preventDefault();
                onNavigate(url);
              }}
              className="hover:underline"
            >
              {article.title}
            </a>
          </h3>

          <p className="text-slate-600 text-xs sm:text-sm leading-relaxed line-clamp-3">
            {article.excerpt || article.leadSummary}
          </p>
        </div>
      </div>

      <div className="px-5 pb-5 pt-3 border-t border-slate-100 flex items-center justify-between">
        <span className="text-xs text-slate-500">By {article.authorName}</span>
        <a
          href={url}
          onClick={(e) => {
            e.preventDefault();
            onNavigate(url);
          }}
          className="text-xs font-semibold text-indigo-600 group-hover:text-indigo-800 flex items-center gap-1"
        >
          <span>Read</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
        </a>
      </div>
    </article>
  );
};
