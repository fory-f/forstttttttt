import React, { useState, useEffect } from 'react';
import { api } from './services/api';
import {
  Article,
  Category,
  Tag,
  RSSSource,
  RSSItem,
  Topic,
  EditorialTone,
  SiteSettings
} from './types';

// Public Components
import { Header } from './components/public/Header';
import { Footer } from './components/public/Footer';
import { PublicHome } from './components/public/PublicHome';
import { PublicArticle } from './components/public/PublicArticle';
import { PublicCategory, PublicTag, PublicAuthor, PublicSearch } from './components/public/PublicTaxonomy';

// Admin Components
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminLogin } from './components/admin/AdminLogin';
import { DashboardView } from './components/admin/DashboardView';
import { ArticlesListView } from './components/admin/ArticlesListView';
import { ArticleEditorView } from './components/admin/ArticleEditorView';
import { AIWorkflowView } from './components/admin/AIWorkflowView';
import { RSSSourcesView, ContentQueueView } from './components/admin/RSSSourcesView';
import { MagicAgentView } from './components/admin/MagicAgentView';
import { MemoryView, ReviewQueueView } from './components/admin/MemoryView';
import { TopicsView, TaxonomyView } from './components/admin/TaxonomyAndTopics';
import { MediaLibraryView } from './components/admin/MediaLibraryView';
import { SettingsView } from './components/admin/SettingsView';
import { LogsView } from './components/admin/LogsView';

const DEFAULT_SITE_SETTINGS: SiteSettings = {
  siteName: 'EditorialPulse',
  siteUrl: typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
  tagline: 'The Independent Voice for Intelligent Content & Tech Insights',
  siteDescription: 'In-depth reporting, editorial analysis, and technological intelligence covering AI, web engineering, SEO, and the future of digital publishing.',
  logoUrl: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=120&h=120&fit=crop&q=80',
  faviconUrl: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=32&h=32&fit=crop&q=80',
  defaultLanguage: 'en',
  googleAnalyticsId: '',
  googleSearchConsoleTag: '',
  publishMode: 'manual',
  activeAiModel: 'gemini-3.8-flash',
  aiTemperature: 0.7,
  authorProfile: {
    name: 'Alexander Vance',
    slug: 'alexander-vance',
    shortBio: 'Senior Editorial Architect & Technology Journalist with over 12 years analyzing search algorithms, content systems, and generative technology.',
    fullBio: 'Alexander Vance is the Editor-in-Chief of EditorialPulse. Prior to founding EditorialPulse, he led editorial content teams at major publishing networks and advised European media enterprises on semantic SEO, automated publishing ethics, and digital trust.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80',
    website: 'https://editorialpulse.com',
    socialTwitter: 'https://x.com/alexandervance',
    socialLinkedin: 'https://linkedin.com/in/alexandervance',
    socialGithub: 'https://github.com/alexandervance',
    expertise: ['Semantic SEO', 'Generative Media', 'Content Automation', 'Web Architecture', 'Information Retrieval'],
    credentials: 'M.Sc. in Computer Science & Media Informatics, Stanford Alumni Fellow',
    organization: 'EditorialPulse Publishing Group'
  },
  projectContext: {
    websiteName: 'EditorialPulse',
    websiteDescription: 'Authority publication on AI technologies, semantic search, high-performance publishing, and modern web engineering.',
    niche: 'Editorial Tech, AI & Search Intelligence',
    targetAudience: 'Content directors, publishers, tech founders, SEO engineers, and digital journalists.',
    countries: ['United States', 'United Kingdom', 'European Union', 'Global'],
    languages: ['English'],
    mainKeywords: ['editorial automation', 'semantic SEO', 'Gemini AI', 'content architecture', 'search intent'],
    brandVoice: 'Authoritative, analytical, balanced, precise, and human-first. We avoid hyperbole, breathless tech hype, and robotic fluff.',
    editorialRules: ['Fact check claims', 'Disclose sources', 'Provide actionable analysis'],
    contentRules: ['Original reporting', 'In-depth perspectives'],
    seoRules: ['Natural keyword placement', 'Semantic search depth'],
    internalLinkingRules: ['Relevant anchor text'],
    avoidTerms: ['revolutionary', 'game-changing', 'paradigm shift'],
    preferredTerminology: ['intelligent systems', 'generative workflows']
  }
};

export default function App() {
  // Navigation Path
  const [currentPath, setCurrentPath] = useState<string>(
    typeof window !== 'undefined' ? window.location.pathname : '/'
  );

  // Admin Tab selection
  const [adminTab, setAdminTab] = useState<string>('dashboard');
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);
  const [workflowRssItem, setWorkflowRssItem] = useState<RSSItem | null>(null);

  // Authentication State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState<boolean>(true);

  // Application Data States
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [rssSources, setRssSources] = useState<RSSSource[]>([]);
  const [rssItems, setRssItems] = useState<RSSItem[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [editorialTones, setEditorialTones] = useState<EditorialTone[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);
  const [isLoadingInitial, setIsLoadingInitial] = useState<boolean>(true);

  // Listen for browser back/forward
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Safe loader for admin-only datasets (RSS sources, queue items, topics, editorial tones)
  const loadAdminData = async () => {
    try {
      const [srcs, qItems, tpcs, tones] = await Promise.all([
        api.getRSSSources().catch(() => []),
        api.getRSSItems().catch(() => []),
        api.getTopics().catch(() => []),
        api.getEditorialTones().catch(() => [])
      ]);
      setRssSources(srcs || []);
      setRssItems(qItems || []);
      setTopics(tpcs || []);
      setEditorialTones(tones || []);
    } catch (err) {
      console.warn('Could not load admin data:', err);
    }
  };

  // Initial Public Load
  const loadAllData = async () => {
    try {
      const [
        authStatus,
        arts,
        cats,
        tgs,
        sttngs
      ] = await Promise.all([
        api.checkAuth().catch(() => ({ authenticated: false })),
        api.getArticles().catch(() => []),
        api.getCategories().catch(() => []),
        api.getTags().catch(() => []),
        api.getSettings().catch(() => null)
      ]);

      const isAuthed = Boolean(authStatus?.authenticated);
      setIsAdminAuthenticated(isAuthed);
      setArticles(arts || []);
      setCategories(cats || []);
      setTags(tgs || []);
      if (sttngs) {
        setSettings(sttngs);
      }

      if (isAuthed) {
        await loadAdminData();
      }
    } catch (err) {
      console.error('Initial data loading error:', err);
    } finally {
      setIsCheckingAuth(false);
      setIsLoadingInitial(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Refresh methods for child components
  const refreshArticles = async () => {
    const arts = await api.getArticles().catch(() => []);
    setArticles(arts);
  };

  const refreshRSS = async () => {
    const [srcs, items] = await Promise.all([
      api.getRSSSources().catch(() => []),
      api.getRSSItems().catch(() => [])
    ]);
    setRssSources(srcs);
    setRssItems(items);
  };

  const refreshTaxonomy = async () => {
    const [cats, tgs] = await Promise.all([
      api.getCategories().catch(() => []),
      api.getTags().catch(() => [])
    ]);
    setCategories(cats);
    setTags(tgs);
  };

  const refreshTopics = async () => {
    const tpcs = await api.getTopics().catch(() => []);
    setTopics(tpcs);
  };

  const refreshSettings = async () => {
    const s = await api.getSettings().catch(() => null);
    if (s) setSettings(s);
  };

  // Handlers for Admin Actions
  const handleLogin = async (password: string) => {
    const res = await api.login({ password });
    if (res.success) {
      setIsAdminAuthenticated(true);
      await loadAdminData();
    }
  };

  const handleLogout = async () => {
    await api.logout().catch(() => {});
    setIsAdminAuthenticated(false);
    setRssSources([]);
    setRssItems([]);
    setTopics([]);
    setEditorialTones([]);
    navigate('/');
  };

  const handleEditArticle = (articleId: string) => {
    setEditingArticleId(articleId);
    setAdminTab('editor');
    if (!currentPath.startsWith('/admin')) {
      navigate('/admin');
    }
  };

  const handleNewArticle = () => {
    setEditingArticleId(null);
    setAdminTab('editor');
  };

  const handleProcessRssItem = (item: RSSItem) => {
    setWorkflowRssItem(item);
    setAdminTab('ai-workflow');
    if (!currentPath.startsWith('/admin')) {
      navigate('/admin');
    }
  };

  const handleDeleteArticle = async (id: string) => {
    await api.deleteArticle(id);
    await refreshArticles();
  };

  const handleApprovePublish = async (id: string) => {
    const target = articles.find(a => a.id === id);
    if (target) {
      await api.saveArticle({
        ...target,
        status: 'published',
        publishedAt: new Date().toISOString()
      });
      await refreshArticles();
      alert(`Article "${target.title}" published!`);
    }
  };

  const handleRejectDraft = async (id: string) => {
    await api.saveArticle({ id, status: 'archived' } as any);
    await refreshArticles();
  };

  if (isLoadingInitial || !settings) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300 space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center font-bold text-white text-xl animate-pulse">
          EP
        </div>
        <p className="text-sm font-medium tracking-wide">Loading EditorialPulse System...</p>
      </div>
    );
  }

  // Check if current route is under /admin
  const isAdminRoute = currentPath.startsWith('/admin');

  if (isAdminRoute) {
    if (!isAdminAuthenticated) {
      return (
        <AdminLogin
          onLogin={handleLogin}
          onCancel={() => navigate('/')}
        />
      );
    }

    const pendingQueueCount = rssItems.filter(i => i.status === 'NEW' || i.status === 'SELECTED').length;
    const pendingReviewCount = articles.filter(a => a.status === 'draft').length;

    return (
      <AdminLayout
        currentTab={adminTab}
        onSelectTab={(tab) => {
          setAdminTab(tab);
          if (tab === 'editor') setEditingArticleId(null);
        }}
        onLogout={handleLogout}
        onNavigatePublic={navigate}
        settings={settings}
        queueCount={pendingQueueCount}
        reviewCount={pendingReviewCount}
      >
        {adminTab === 'dashboard' && (
          <DashboardView
            articles={articles}
            rssItems={rssItems}
            settings={settings}
            onSelectTab={setAdminTab}
            onEditArticle={handleEditArticle}
            onProcessRssItem={handleProcessRssItem}
            onDeleteArticle={handleDeleteArticle}
          />
        )}

        {adminTab === 'articles' && (
          <ArticlesListView
            articles={articles}
            categories={categories}
            onNewArticle={handleNewArticle}
            onEditArticle={handleEditArticle}
            onDeleteArticle={handleDeleteArticle}
            onNavigatePublic={navigate}
          />
        )}

        {adminTab === 'editor' && (
          <ArticleEditorView
            articleId={editingArticleId}
            categories={categories}
            tags={tags}
            onSaveSuccess={(saved) => {
              refreshArticles();
              setEditingArticleId(saved.id);
            }}
            onNavigateCatalog={() => setAdminTab('articles')}
            onNavigatePublic={navigate}
          />
        )}

        {adminTab === 'ai-workflow' && (
          <AIWorkflowView
            initialRssItem={workflowRssItem}
            categories={categories}
            topics={topics}
            editorialTones={editorialTones}
            onFinish={async (saved) => {
              await refreshArticles();
              await refreshRSS();
              setWorkflowRssItem(null);
              setEditingArticleId(saved.id);
              setAdminTab('editor');
            }}
            onCancel={() => {
              setWorkflowRssItem(null);
              setAdminTab('dashboard');
            }}
          />
        )}

        {adminTab === 'rss' && (
          <RSSSourcesView
            sources={rssSources}
            categories={categories}
            onRefreshSources={refreshRSS}
            onNavigateQueue={() => setAdminTab('queue')}
          />
        )}

        {adminTab === 'queue' && (
          <ContentQueueView
            items={rssItems}
            onProcessItem={handleProcessRssItem}
            onRefreshQueue={refreshRSS}
          />
        )}

        {adminTab === 'review' && (
          <ReviewQueueView
            articles={articles}
            onApprovePublish={handleApprovePublish}
            onEditArticle={handleEditArticle}
            onRejectDraft={handleRejectDraft}
          />
        )}

        {adminTab === 'magic' && (
          <MagicAgentView
            settings={settings}
            onRefreshAll={loadAllData}
            onOpenArticleEditor={(id) => id ? handleEditArticle(id) : handleNewArticle()}
            onOpenWorkflow={() => setAdminTab('ai-workflow')}
          />
        )}

        {adminTab === 'memory' && <MemoryView />}

        {adminTab === 'topics' && (
          <TopicsView
            topics={topics}
            onRefresh={refreshTopics}
          />
        )}

        {adminTab === 'taxonomy' && (
          <TaxonomyView
            categories={categories}
            tags={tags}
            onRefresh={refreshTaxonomy}
          />
        )}

        {adminTab === 'media' && <MediaLibraryView />}

        {adminTab === 'settings' && (
          <SettingsView
            settings={settings}
            onRefreshSettings={refreshSettings}
          />
        )}

        {adminTab === 'logs' && (
          <LogsView onEditArticle={handleEditArticle} />
        )}
      </AdminLayout>
    );
  }

  // PUBLIC WEBSITE ROUTING
  // 1. Article Page: /article/:slug
  if (currentPath.startsWith('/article/')) {
    const slug = currentPath.replace('/article/', '').split('/')[0];
    const article = articles.find(a => a.slug === slug && a.status === 'published');

    if (article) {
      const category = categories.find(c => c.id === article.categoryId);
      const related = articles.filter(a => a.id !== article.id && a.status === 'published' && a.categoryId === article.categoryId);
      return (
        <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
          <Header
            settings={settings}
            categories={categories}
            currentPath={currentPath}
            onNavigate={navigate}
            isAdminAuthenticated={isAdminAuthenticated}
          />
          <main className="flex-1">
            <PublicArticle
              article={article}
              category={category}
              relatedArticles={related}
              settings={settings}
              onNavigate={navigate}
            />
          </main>
          <Footer
            settings={settings}
            categories={categories}
            onNavigate={navigate}
          />
        </div>
      );
    }
  }

  // 2. Category Archive: /category/:slug
  if (currentPath.startsWith('/category/')) {
    const slug = currentPath.replace('/category/', '').split('/')[0];
    const category = categories.find(c => c.slug === slug);

    if (category) {
      const catArticles = articles.filter(a => a.categoryId === category.id && a.status === 'published');
      return (
        <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
          <Header
            settings={settings}
            categories={categories}
            currentPath={currentPath}
            onNavigate={navigate}
            isAdminAuthenticated={isAdminAuthenticated}
          />
          <main className="flex-1">
            <PublicCategory
              category={category}
              articles={catArticles}
              categories={categories}
              onNavigate={navigate}
            />
          </main>
          <Footer
            settings={settings}
            categories={categories}
            onNavigate={navigate}
          />
        </div>
      );
    }
  }

  // 3. Tag Archive: /tag/:slug
  if (currentPath.startsWith('/tag/')) {
    const slug = currentPath.replace('/tag/', '').split('/')[0];
    const tagArticles = articles.filter(a =>
      a.status === 'published' &&
      a.tags.some(t => t.toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-') === slug)
    );

    return (
      <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
        <Header
          settings={settings}
          categories={categories}
          currentPath={currentPath}
          onNavigate={navigate}
          isAdminAuthenticated={isAdminAuthenticated}
        />
        <main className="flex-1">
          <PublicTag
            tag={slug}
            articles={tagArticles}
            categories={categories}
            onNavigate={navigate}
          />
        </main>
        <Footer
          settings={settings}
          categories={categories}
          onNavigate={navigate}
        />
      </div>
    );
  }

  // 4. Author Profile: /author/:slug
  if (currentPath.startsWith('/author/')) {
    const authorArticles = articles.filter(a => a.status === 'published');
    return (
      <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
        <Header
          settings={settings}
          categories={categories}
          currentPath={currentPath}
          onNavigate={navigate}
          isAdminAuthenticated={isAdminAuthenticated}
        />
        <main className="flex-1">
          <PublicAuthor
            author={settings.authorProfile}
            articles={authorArticles}
            categories={categories}
            onNavigate={navigate}
          />
        </main>
        <Footer
          settings={settings}
          categories={categories}
          onNavigate={navigate}
        />
      </div>
    );
  }

  // 5. Search Page: /search
  if (currentPath === '/search') {
    return (
      <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
        <Header
          settings={settings}
          categories={categories}
          currentPath={currentPath}
          onNavigate={navigate}
          isAdminAuthenticated={isAdminAuthenticated}
        />
        <main className="flex-1">
          <PublicSearch
            articles={articles}
            categories={categories}
            onNavigate={navigate}
          />
        </main>
        <Footer
          settings={settings}
          categories={categories}
          onNavigate={navigate}
        />
      </div>
    );
  }

  // 6. Default: Public Home Page (/)
  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
      <Header
        settings={settings}
        categories={categories}
        currentPath={currentPath}
        onNavigate={navigate}
        isAdminAuthenticated={isAdminAuthenticated}
      />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
        <PublicHome
          articles={articles}
          categories={categories}
          settings={settings}
          onNavigate={navigate}
        />
      </main>
      <Footer
        settings={settings}
        categories={categories}
        onNavigate={navigate}
      />
    </div>
  );
}
