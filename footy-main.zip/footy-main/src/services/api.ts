import {
  Article,
  Category,
  Tag,
  RSSSource,
  RSSItem,
  Topic,
  EditorialTone,
  AIInstruction,
  PromptTemplate,
  MediaItem,
  MemoryItem,
  AutomationRule,
  AIPermission,
  SiteSettings,
  TitleCandidate,
  InternalLinkSuggestion,
  AgentActivityLog,
  AIUsageLog,
  ArticleRevision
} from '../types';

const TOKEN_KEY = 'ep_auth_token';

async function req<T>(url: string, options?: RequestInit): Promise<T> {
  const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null;
  const authHeaders: Record<string, string> = token ? { 'Authorization': `Bearer ${token}` } : {};

  const res = await fetch(url, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders,
      ...(options?.headers || {})
    }
  });

  if (!res.ok) {
    let errMsg = `Request failed: ${res.status} ${res.statusText}`;
    try {
      const json = await res.json();
      if (json.error) errMsg = json.error;
    } catch {}
    throw new Error(errMsg);
  }

  return res.json();
}

export const api = {
  // Auth
  login: async (credentials: { email?: string; password: string }) => {
    const data = await req<{ success: boolean; token?: string; user: any }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
    if (data.success && typeof window !== 'undefined') {
      localStorage.setItem(TOKEN_KEY, data.token || 'authenticated_admin_session');
    }
    return data;
  },
  logout: async () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(TOKEN_KEY);
    }
    return req<{ success: boolean }>('/api/auth/logout', { method: 'POST' });
  },
  checkAuth: () => req<{ authenticated: boolean; user?: any }>('/api/auth/me'),

  // Articles
  getArticles: (params?: { status?: string; categoryId?: string; tag?: string; search?: string }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set('status', params.status);
    if (params?.categoryId) query.set('categoryId', params.categoryId);
    if (params?.tag) query.set('tag', params.tag);
    if (params?.search) query.set('search', params.search);
    return req<Article[]>(`/api/articles?${query.toString()}`);
  },
  getArticle: (id: string) => req<Article>(`/api/articles/${id}`),
  getArticleBySlug: (slug: string) => req<Article>(`/api/articles/slug/${slug}`),
  saveArticle: (article: Partial<Article> & { title: string }) =>
    req<Article>('/api/articles', { method: 'POST', body: JSON.stringify(article) }),
  deleteArticle: (id: string) => req<{ success: boolean }>(`/api/articles/${id}`, { method: 'DELETE' }),
  getRevisions: (articleId: string) => req<ArticleRevision[]>(`/api/articles/${articleId}/revisions`),
  restoreRevision: (articleId: string, revId: string) =>
    req<Article>(`/api/articles/${articleId}/restore/${revId}`, { method: 'POST' }),

  // Categories & Tags
  getCategories: () => req<Category[]>('/api/categories'),
  saveCategory: (category: Partial<Category> & { name: string }) =>
    req<Category>('/api/categories', { method: 'POST', body: JSON.stringify(category) }),
  deleteCategory: (id: string) => req<{ success: boolean }>(`/api/categories/${id}`, { method: 'DELETE' }),

  getTags: () => req<Tag[]>('/api/tags'),
  saveTag: (name: string) => req<Tag>('/api/tags', { method: 'POST', body: JSON.stringify({ name }) }),
  bulkAddTags: (bulk: string) => req<Tag[]>('/api/tags', { method: 'POST', body: JSON.stringify({ bulk }) }),
  deleteTag: (id: string) => req<{ success: boolean }>(`/api/tags/${id}`, { method: 'DELETE' }),

  // RSS
  getRSSSources: () => req<RSSSource[]>('/api/rss/sources'),
  saveRSSSource: (source: Partial<RSSSource> & { name: string; url: string }) =>
    req<RSSSource>('/api/rss/sources', { method: 'POST', body: JSON.stringify(source) }),
  deleteRSSSource: (id: string) => req<{ success: boolean }>(`/api/rss/sources/${id}`, { method: 'DELETE' }),
  testRSSFeed: (url: string) => req<{ valid: boolean; title?: string; description?: string; itemCount?: number; error?: string }>('/api/rss/sources/test', { method: 'POST', body: JSON.stringify({ url }) }),
  fetchRSSSource: (id: string) => req<any>(`/api/rss/sources/${id}/fetch`, { method: 'POST' }),
  fetchAllRSSSources: () => req<any[]>('/api/rss/fetch-all', { method: 'POST' }),

  getRSSItems: (params?: { status?: string; sourceId?: string }) => {
    const q = new URLSearchParams();
    if (params?.status) q.set('status', params.status);
    if (params?.sourceId) q.set('sourceId', params.sourceId);
    return req<RSSItem[]>(`/api/rss/items?${q.toString()}`);
  },
  updateRSSItem: (id: string, updates: Partial<RSSItem>) =>
    req<RSSItem>(`/api/rss/items/${id}`, { method: 'PATCH', body: JSON.stringify(updates) }),
  deleteRSSItem: (id: string) => req<{ success: boolean }>(`/api/rss/items/${id}`, { method: 'DELETE' }),

  // AI Workflows
  generateTitles: (params: { topic: string; focusKeyword: string; sourceTitle?: string; sourceContent?: string; tonePrompt?: string; categoryName?: string }) =>
    req<TitleCandidate[]>('/api/ai/titles', { method: 'POST', body: JSON.stringify(params) }),
  generateArticle: (params: {
    title: string;
    focusKeyword: string;
    secondaryKeywords: string[];
    topic: string;
    categoryName: string;
    categoryId?: string;
    sourceContent?: string;
    tonePrompt?: string;
    targetAudience?: string;
    desiredLength?: string;
    customInstructions?: string;
  }) => req<{
    title: string;
    content: string;
    leadSummary: string;
    excerpt: string;
    seoTitle: string;
    metaDescription: string;
    slug: string;
    tags: string[];
    featuredImageAlt: string;
    aiSeoScore: number;
    aiSeoAnalysis: any;
  }>('/api/ai/article', { method: 'POST', body: JSON.stringify(params) }),
  runSeoCheck: (params: { title: string; content: string; focusKeyword: string; secondaryKeywords?: string[]; metaDescription?: string; slug?: string }) =>
    req<any>('/api/ai/seo-check', { method: 'POST', body: JSON.stringify(params) }),
  humanizeContent: (params: { text: string; focusKeyword?: string; customDirective?: string }) =>
    req<{ original: string; humanized: string; diffNotes: string[] }>('/api/ai/humanize', { method: 'POST', body: JSON.stringify(params) }),
  refineSection: (params: { sectionText: string; action: string; focusKeyword?: string; tonePrompt?: string; customPrompt?: string }) =>
    req<{ refined: string }>('/api/ai/refine-section', { method: 'POST', body: JSON.stringify(params) }),
  suggestInternalLinks: (params: { currentArticleId?: string; currentContent: string }) =>
    req<InternalLinkSuggestion[]>('/api/ai/internal-links', { method: 'POST', body: JSON.stringify(params) }),
  runMagicAgent: (params: { userPrompt: string }) =>
    req<{ reply: string; plannedAction?: any }>('/api/ai/magic', { method: 'POST', body: JSON.stringify(params) }),

  // Topics & Tones
  getTopics: () => req<Topic[]>('/api/topics'),
  saveTopic: (topic: Partial<Topic> & { name: string }) => req<Topic>('/api/topics', { method: 'POST', body: JSON.stringify(topic) }),
  deleteTopic: (id: string) => req<{ success: boolean }>(`/api/topics/${id}`, { method: 'DELETE' }),

  getEditorialTones: () => req<EditorialTone[]>('/api/editorial-tones'),
  saveEditorialTone: (tone: Partial<EditorialTone> & { name: string; prompt: string }) =>
    req<EditorialTone>('/api/editorial-tones', { method: 'POST', body: JSON.stringify(tone) }),
  deleteEditorialTone: (id: string) => req<{ success: boolean }>(`/api/editorial-tones/${id}`, { method: 'DELETE' }),

  // Instructions & Templates
  getAIInstructions: () => req<AIInstruction[]>('/api/ai-instructions'),
  saveAIInstruction: (inst: Partial<AIInstruction> & { title: string; instruction: string }) =>
    req<AIInstruction>('/api/ai-instructions', { method: 'POST', body: JSON.stringify(inst) }),
  deleteAIInstruction: (id: string) => req<{ success: boolean }>(`/api/ai-instructions/${id}`, { method: 'DELETE' }),

  getPromptTemplates: () => req<PromptTemplate[]>('/api/prompt-templates'),
  savePromptTemplate: (template: Partial<PromptTemplate> & { name: string; template: string; type: any }) =>
    req<PromptTemplate>('/api/prompt-templates', { method: 'POST', body: JSON.stringify(template) }),
  deletePromptTemplate: (id: string) => req<{ success: boolean }>(`/api/prompt-templates/${id}`, { method: 'DELETE' }),

  // Media
  getMedia: () => req<MediaItem[]>('/api/media'),
  saveMedia: (item: any) => req<MediaItem>('/api/media', { method: 'POST', body: JSON.stringify(item) }),
  updateMedia: (id: string, updates: Partial<MediaItem>) => req<MediaItem>(`/api/media/${id}`, { method: 'PATCH', body: JSON.stringify(updates) }),
  deleteMedia: (id: string) => req<{ success: boolean }>(`/api/media/${id}`, { method: 'DELETE' }),

  // Memory
  getMemory: (search?: string) => req<MemoryItem[]>(`/api/memory${search ? `?search=${encodeURIComponent(search)}` : ''}`),
  saveMemory: (item: Partial<MemoryItem> & { title: string; content: string }) =>
    req<MemoryItem>('/api/memory', { method: 'POST', body: JSON.stringify(item) }),
  deleteMemory: (id: string) => req<{ success: boolean }>(`/api/memory/${id}`, { method: 'DELETE' }),
  clearMemory: () => req<{ success: boolean }>('/api/memory/clear', { method: 'POST' }),

  // Automation & Permissions
  getAutomationRules: () => req<AutomationRule[]>('/api/automation-rules'),
  saveAutomationRule: (rule: Partial<AutomationRule> & { name: string }) =>
    req<AutomationRule>('/api/automation-rules', { method: 'POST', body: JSON.stringify(rule) }),
  deleteAutomationRule: (id: string) => req<{ success: boolean }>(`/api/automation-rules/${id}`, { method: 'DELETE' }),

  getPermissions: () => req<AIPermission[]>('/api/permissions'),
  updatePermission: (key: string, allowed: boolean) =>
    req<AIPermission>('/api/permissions', { method: 'POST', body: JSON.stringify({ key, allowed }) }),

  // Logs
  getAgentLogs: () => req<AgentActivityLog[]>('/api/logs/agent'),
  getAiUsageLogs: () => req<AIUsageLog[]>('/api/logs/ai-usage'),

  // Settings & Catalog SEO Audit
  getSettings: () => req<SiteSettings>('/api/settings'),
  saveSettings: (settings: Partial<SiteSettings>) =>
    req<SiteSettings>('/api/settings', { method: 'POST', body: JSON.stringify(settings) }),
  getSeoAuditCatalog: () => req<{
    totalPublished: number;
    totalDrafts: number;
    averageScore: number;
    missingMetaCount: number;
    lowSeoScoresCount: number;
    missingFeaturedImageCount: number;
    criticalIssues: Array<{ articleId: string; title: string; issue: string }>;
  }>('/api/seo/audit-catalog')
};
