export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'editor';
  passwordHash?: string;
  createdAt?: string;
}

export interface AuthorProfile {
  name: string;
  slug: string;
  shortBio: string;
  fullBio: string;
  avatar: string;
  website: string;
  socialTwitter: string;
  socialLinkedin: string;
  socialGithub: string;
  expertise: string[];
  credentials: string;
  organization: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  seoTitle: string;
  seoDescription: string;
  parentCategoryId?: string;
  isIndexable?: boolean;
  imageUrl?: string;
  articleCount?: number;
  createdAt: string;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  description?: string;
  articleCount?: number;
  createdAt: string;
}

export interface ArticleRevision {
  id: string;
  articleId: string;
  timestamp: string;
  author: string;
  action: string;
  title: string;
  content: string;
  seoScore?: number;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  leadSummary: string;
  content: string;
  featuredImage: string;
  featuredImageAlt: string;
  categoryId: string;
  tags: string[];
  primaryFocusKeyword: string;
  secondaryKeywords: string[];
  seoTitle: string;
  metaDescription: string;
  canonicalUrl: string;
  authorName: string;
  authorSlug: string;
  status: 'draft' | 'scheduled' | 'published' | 'archived';
  scheduledAt?: string;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
  workflowStage: number;
  aiSeoScore?: number;
  aiSeoAnalysis?: {
    score: number;
    strengths: string[];
    warnings: string[];
    recommendations: string[];
    breakdown: {
      keywordInTitle: boolean;
      keywordInH1: boolean;
      keywordInIntro: boolean;
      keywordInMeta: boolean;
      keywordDensity: string;
      headingStructure: boolean;
      readabilityScore: number;
      internalLinksCount: number;
      wordCount: number;
    };
  };
  sourceRssId?: string;
  sourceUrl?: string;
  sourceTitle?: string;
  isAutoPublished?: boolean;
}

export interface RSSSource {
  id: string;
  name: string;
  url: string;
  websiteName: string;
  enabled: boolean;
  defaultCategoryId: string;
  defaultTags: string[];
  priority: 'low' | 'medium' | 'high';
  fetchFrequencyMinutes: number;
  lastFetchedAt?: string;
  lastError?: string;
  itemCount: number;
  createdAt: string;
}

export interface RSSItem {
  id: string;
  sourceId: string;
  sourceName: string;
  originalTitle: string;
  originalUrl: string;
  originalAuthor?: string;
  publicationDate: string;
  description: string;
  content?: string;
  originalImage?: string;
  importedAt: string;
  status: 'NEW' | 'IMPORTED' | 'SELECTED' | 'PROCESSING' | 'PROCESSED' | 'PUBLISHED' | 'SKIPPED' | 'ERROR';
  selectedTopic?: string;
  selectedCategory?: string;
  focusKeyword?: string;
  articleId?: string;
  errorDetails?: string;
}

export interface Topic {
  id: string;
  name: string;
  description: string;
  keywords: string[];
  secondaryKeywords?: string[];
  searchIntent?: 'Informational' | 'Commercial' | 'Transactional' | 'Navigational';
  targetAudience?: string;
  associatedCategoryIds?: string[];
  priority: 'low' | 'medium' | 'high';
  enabled: boolean;
  instructions: string;
  autoPublishEnabled?: boolean;
  minSeoScore?: number;
}

export interface EditorialTone {
  id: string;
  name: string;
  description: string;
  prompt: string;
  isDefault: boolean;
  enabled: boolean;
}

export interface AIInstruction {
  id: string;
  level: 'global' | 'category' | 'topic' | 'source' | 'article';
  targetId?: string;
  targetName?: string;
  title: string;
  instruction: string;
  enabled: boolean;
  createdAt: string;
}

export interface PromptTemplate {
  id: string;
  name: string;
  type: 'title' | 'article' | 'humanize' | 'seo' | 'meta' | 'tags' | 'section';
  template: string;
  description: string;
  enabled: boolean;
}

export interface MediaItem {
  id: string;
  url: string;
  title: string;
  altText: string;
  caption: string;
  filename: string;
  mimeType: string;
  fileSize: number;
  width?: number;
  height?: number;
  uploadedAt: string;
}

export interface MemoryItem {
  id: string;
  title: string;
  type: 'text' | 'document' | 'guideline' | 'research' | 'brand';
  content: string;
  tags: string[];
  lastUpdated: string;
}

export interface ProjectContext {
  websiteName: string;
  websiteDescription: string;
  niche: string;
  targetAudience: string;
  countries: string[];
  languages: string[];
  mainKeywords: string[];
  brandVoice: string;
  editorialRules: string[];
  contentRules: string[];
  seoRules: string[];
  internalLinkingRules: string[];
  avoidTerms: string[];
  preferredTerminology: string[];
}

export interface AutomationRule {
  id: string;
  name: string;
  enabled: boolean;
  mode: 'manual' | 'semi-automatic' | 'automatic';
  minAiSeoScore: number;
  requireFeaturedImage: boolean;
  requireMetaDescription: boolean;
  requireFocusKeywordInTitle: boolean;
  requireTagsCount: number;
  allowedKeywords?: string[];
  allowedCategories?: string[];
}

export interface AIPermission {
  id: string;
  key: string;
  name: string;
  description: string;
  allowed: boolean;
  dangerous: boolean;
}

export interface AgentActivityLog {
  id: string;
  timestamp: string;
  agent: string;
  action: string;
  targetType: string;
  targetId?: string;
  details: string;
  status: 'SUCCESS' | 'WAITING_APPROVAL' | 'CANCELLED' | 'ERROR';
}

export interface AIUsageLog {
  id: string;
  timestamp: string;
  operation: string;
  articleId?: string;
  articleTitle?: string;
  provider: string;
  model: string;
  tokenCount?: number;
  status: 'SUCCESS' | 'FAILED';
  error?: string;
}

export interface SiteSettings {
  siteName: string;
  siteUrl: string;
  tagline: string;
  siteDescription: string;
  logoUrl: string;
  faviconUrl: string;
  defaultLanguage: string;
  googleAnalyticsId: string;
  googleSearchConsoleTag: string;
  publishMode: 'manual' | 'semi-automatic' | 'automatic';
  activeAiModel: string;
  aiTemperature: number;
  authorProfile: AuthorProfile;
  projectContext: ProjectContext;
}

export interface TitleCandidate {
  title: string;
  aiSeoScore: number;
  keywordRelevance: 'High' | 'Medium' | 'Low';
  keywordPlacement: 'Front-loaded' | 'Middle' | 'End' | 'Missing';
  searchIntent: 'Informational' | 'Commercial' | 'Transactional' | 'Navigational';
  ctrPotential: 'High' | 'Medium' | 'Moderate';
  readability: string;
  charCount: number;
  wordCount: number;
  clickbaitWarning: boolean;
  explanation: string;
}

export interface InternalLinkSuggestion {
  anchorText: string;
  targetSlug: string;
  targetTitle: string;
  targetUrl: string;
  reason: string;
}

export type AIProviderName = 'gemini' | 'openai' | 'anthropic' | 'deepseek' | 'custom';

export interface AIProviderConfig {
  id: string;
  provider: AIProviderName;
  name: string;
  apiKey: string;
  model: string;
  endpoint?: string;
  temperature: number;
  maxTokens: number;
  timeoutMs: number;
  enabled: boolean;
  isDefault: boolean;
  isFallback: boolean;
  lastTestedAt?: string;
  lastTestStatus?: 'connected' | 'failed';
  lastTestLatencyMs?: number;
  lastTestError?: string;
}

export interface AITaskRouting {
  writingProviderId: string;
  researchProviderId: string;
  humanizeProviderId: string;
  seoProviderId: string;
  imageProviderId: string;
  magicProviderId: string;
}

export interface ResearchSourceItem {
  id: string;
  url: string;
  title: string;
  metaDescription?: string;
  author?: string;
  publishedDate?: string;
  canonicalUrl?: string;
  mainContent: string;
  headings: string[];
  keyClaims: string[];
  statistics: string[];
  quotes: string[];
  suggestedTopics: string[];
  extractedAt: string;
  status: 'ready' | 'error';
  errorDetails?: string;
}

export interface WorkflowDraftState {
  currentStage: number;
  sourceTitle: string;
  sourceUrl: string;
  sourceContent: string;
  sourceItemId?: string;
  selectedTopic: string;
  selectedCategoryId: string;
  focusKeyword: string;
  secondaryKeywords: string[];
  selectedToneId: string;
  titleCandidates: TitleCandidate[];
  selectedTitle: string;
  generatedArticle: any;
  articleContent: string;
  leadSummary: string;
  excerpt: string;
  metaDescription: string;
  tags: string[];
  featuredImage: string;
  featuredImageAlt: string;
  seoScore: number;
  humanizeNotes: string[];
  internalLinkSuggestions: InternalLinkSuggestion[];
  lastSavedAt: string;
}

export interface MagicToolInvocation {
  id: string;
  toolName: string;
  params: Record<string, any>;
  status: 'running' | 'completed' | 'failed' | 'waiting_approval';
  result?: any;
  error?: string;
  diffSummary?: string;
  dangerous?: boolean;
}
