import { executeMultiProviderRequest, DEFAULT_AI_PROVIDERS, DEFAULT_TASK_ROUTING } from './ai-providers.js';

export const HUMANIZER_SYSTEM_PROMPT = `
You are the world's most disciplined editorial copy chief and prose humanizer.
Your sole mission is to take AI-generated, stilted, or formulaic writing and turn it into sharp, natural, authoritative human writing—without losing factual accuracy, substance, technical depth, or semantic SEO keywords.

STRICT EDITORIAL HUMANIZING RULES:
1. SAY THE THING DIRECTLY:
   - Immediately cut throat-clearing openings, rhetorical fluff, and empty lead-ins.
   - BAN: "In today's rapidly evolving world...", "When it comes to...", "It's important to note that...", "Let's dive into...", "In this article, we will explore...", "Needless to say...".
   - Start immediately with the action, subject, or core fact.

2. ELIMINATE AI CLICHÉS AND INFLATED BUZZWORDS:
   - BAN: "game-changing", "revolutionary", "delve", "leverage", "foster", "rich tapestry", "vibrant landscape", "testament to", "plays a pivotal role", "beacon of", "ever-evolving", "at the intersection of", "crucial aspect", "pivotal moment", "embark on a journey", "unleash", "demystify".
   - Replace with plain, concrete, vivid verbs and clear nouns.

3. REMOVE MANUFACTURED SIGNIFICANCE:
   - BAN the formulaic "It's not just X — it's Y" and "The future of X is here" tropes.
   - Do not preach to the reader about how monumental something is. Show the evidence, stats, tactical mechanics, and specific outcomes instead.

4. ELIMINATE FORMULAIC TRANSITIONS:
   - BAN: "Moreover,", "Furthermore,", "Additionally,", "In conclusion,", "To sum up,", "All in all,", "Last but not least,".
   - Connect ideas logically through cause-and-effect or direct continuation rather than artificial linking adverbs.

5. NATURAL RHYTHM AND VARYING SENTENCE LENGTH:
   - Mix short, punchy declarative statements with informative compound sentences.
   - Break up monotone, identical paragraph cadences.

6. ABSOLUTE PRESERVATION OF ESSENTIAL CONTENT:
   - PRESERVE all factual claims, specific numbers, player/manager names, club names, transfer fees, xG stats, and dates.
   - PRESERVE any HTML markup, especially semantic headings (<h2>, <h3>), paragraphs (<p>), bullet points (<ul>, <li>), blockquotes, and internal/external hyperlinks (<a href="...">...</a>).
   - PRESERVE the primary focus keyword and related entities so search relevance is maintained.

Respond ONLY with valid JSON:
{
  "humanized": "The revised, humanized text preserving all HTML tags and links...",
  "diffNotes": [
    "Brief note explaining a specific AI cliché removed or phrasing tightened",
    "Second specific edit note",
    "Third specific edit note"
  ]
}
`;

export async function runHumanizeText(params: {
  text: string;
  focusKeyword?: string;
  customDirective?: string;
  mode?: 'selection' | 'section' | 'article';
  providers?: any[];
  routing?: any;
}): Promise<{ original: string; humanized: string; diffNotes: string[]; wordsReduced: number }> {
  const { text, focusKeyword, customDirective } = params;
  if (!text || text.trim().length === 0) {
    return { original: '', humanized: '', diffNotes: ['No text provided'], wordsReduced: 0 };
  }

  const prompt = `
Please humanize the following text according to the strict editorial humanizing rules.
${focusKeyword ? `Preserve natural placement of the primary focus keyword: "${focusKeyword}".` : ''}
${customDirective ? `Special directive: ${customDirective}` : ''}

Original Text:
"""
${text}
"""
`;

  try {
    const aiRes = await executeMultiProviderRequest(
      params.providers || DEFAULT_AI_PROVIDERS,
      params.routing || DEFAULT_TASK_ROUTING,
      prompt,
      {
        task: 'humanize',
        systemInstruction: HUMANIZER_SYSTEM_PROMPT,
        jsonMode: true,
        temperature: 0.3
      }
    );

    const parsed = JSON.parse(aiRes.text);
    const humanized = parsed.humanized || text;
    const diffNotes = Array.isArray(parsed.diffNotes) ? parsed.diffNotes : ['Tightened cadence and stripped generic transitions.'];

    const originalWordCount = text.split(/\s+/).filter(Boolean).length;
    const humanizedWordCount = humanized.split(/\s+/).filter(Boolean).length;

    return {
      original: text,
      humanized,
      diffNotes,
      wordsReduced: Math.max(0, originalWordCount - humanizedWordCount)
    };
  } catch (err: any) {
    console.warn('Humanizer AI call error, applying rule-based cleanup:', err);
    // Rule-based fallback humanizer in case AI call fails
    let cleaned = text
      .replace(/\bIn today's rapidly evolving (?:digital )?(?:landscape|world),?\b/gi, 'Today,')
      .replace(/\bWhen it comes to ([^,]+),/gi, 'Regarding $1,')
      .replace(/\bIt is important to note that\b/gi, 'Notably,')
      .replace(/\bIt's important to note that\b/gi, 'Notably,')
      .replace(/\bLet's dive into\b/gi, 'Examining')
      .replace(/\bplays a pivotal role in\b/gi, 'drives')
      .replace(/\btestament to\b/gi, 'evidence of')
      .replace(/\bgame-changing\b/gi, 'decisive')
      .replace(/\brevolutionary\b/gi, 'transformative')
      .replace(/\bdelve into\b/gi, 'analyze')
      .replace(/\bleverage\b/gi, 'use')
      .replace(/\bMoreover,\s*/gi, '')
      .replace(/\bFurthermore,\s*/gi, '')
      .replace(/\bAdditionally,\s*/gi, '')
      .replace(/\bIn conclusion,?\s*/gi, '');

    const notes = [
      'Stripped conversational filler and throat-clearing openers',
      'Replaced corporate/AI buzzwords with direct phrasing',
      'Removed formulaic transitions (Moreover, Furthermore)'
    ];

    const originalWordCount = text.split(/\s+/).filter(Boolean).length;
    const humanizedWordCount = cleaned.split(/\s+/).filter(Boolean).length;

    return {
      original: text,
      humanized: cleaned,
      diffNotes: notes,
      wordsReduced: Math.max(0, originalWordCount - humanizedWordCount)
    };
  }
}
