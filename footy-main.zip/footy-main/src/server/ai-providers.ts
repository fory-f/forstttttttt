import { GoogleGenAI } from '@google/genai';
import { AIProviderConfig, AIProviderName, AITaskRouting } from '../types.js';

export interface AIResponse {
  text: string;
  provider: AIProviderName;
  model: string;
  latencyMs: number;
}

export interface GenerationOptions {
  task?: 'writing' | 'research' | 'humanize' | 'seo' | 'magic';
  temperature?: number;
  maxTokens?: number;
  systemInstruction?: string;
  jsonMode?: boolean;
}

// Default provider configuration blueprints
export const DEFAULT_AI_PROVIDERS: AIProviderConfig[] = [
  {
    id: 'prov-gemini',
    provider: 'gemini',
    name: 'Google Gemini',
    apiKey: process.env.GEMINI_API_KEY || '',
    model: 'gemini-3.8-flash',
    endpoint: '',
    temperature: 0.7,
    maxTokens: 4096,
    timeoutMs: 30000,
    enabled: true,
    isDefault: true,
    isFallback: false
  },
  {
    id: 'prov-openai',
    provider: 'openai',
    name: 'OpenAI (GPT-4o)',
    apiKey: process.env.OPENAI_API_KEY || '',
    model: 'gpt-4o-mini',
    endpoint: 'https://api.openai.com/v1/chat/completions',
    temperature: 0.7,
    maxTokens: 4096,
    timeoutMs: 30000,
    enabled: false,
    isDefault: false,
    isFallback: true
  },
  {
    id: 'prov-anthropic',
    provider: 'anthropic',
    name: 'Anthropic Claude',
    apiKey: process.env.ANTHROPIC_API_KEY || '',
    model: 'claude-3-5-sonnet-20241022',
    endpoint: 'https://api.anthropic.com/v1/messages',
    temperature: 0.7,
    maxTokens: 4096,
    timeoutMs: 35000,
    enabled: false,
    isDefault: false,
    isFallback: false
  },
  {
    id: 'prov-deepseek',
    provider: 'deepseek',
    name: 'DeepSeek AI',
    apiKey: process.env.DEEPSEEK_API_KEY || '',
    model: 'deepseek-chat',
    endpoint: 'https://api.deepseek.com/chat/completions',
    temperature: 0.7,
    maxTokens: 4096,
    timeoutMs: 35000,
    enabled: false,
    isDefault: false,
    isFallback: false
  }
];

export const DEFAULT_TASK_ROUTING: AITaskRouting = {
  writingProviderId: 'prov-gemini',
  researchProviderId: 'prov-gemini',
  humanizeProviderId: 'prov-gemini',
  seoProviderId: 'prov-gemini',
  imageProviderId: 'prov-gemini',
  magicProviderId: 'prov-gemini'
};

/**
 * Tests an AI provider connection by issuing a lightweight probe request
 * and measuring the real round-trip latency.
 */
export async function testProviderConnection(
  config: AIProviderConfig
): Promise<{ success: boolean; latencyMs: number; model: string; error?: string }> {
  const startTime = Date.now();
  const effectiveKey = config.apiKey || (config.provider === 'gemini' ? process.env.GEMINI_API_KEY : '');

  if (!effectiveKey && config.provider !== 'gemini') {
    return {
      success: false,
      latencyMs: 0,
      model: config.model,
      error: `No API key configured for ${config.name}. Please enter your API key to test connection.`
    };
  }

  try {
    if (config.provider === 'gemini') {
      const geminiKey = effectiveKey || process.env.GEMINI_API_KEY;
      if (!geminiKey) {
        return {
          success: false,
          latencyMs: 0,
          model: config.model,
          error: 'No Gemini API key available in environment or configuration.'
        };
      }
      const ai = new GoogleGenAI({ apiKey: geminiKey });
      const testModel = config.model || 'gemini-3.8-flash';
      const response = await ai.models.generateContent({
        model: testModel,
        contents: 'Respond with the single word: OK'
      });
      const latencyMs = Date.now() - startTime;
      if (response && response.text) {
        return { success: true, latencyMs, model: testModel };
      }
      return { success: false, latencyMs, model: testModel, error: 'Empty response returned by Gemini model.' };
    }

    if (config.provider === 'openai') {
      const endpoint = config.endpoint || 'https://api.openai.com/v1/chat/completions';
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), config.timeoutMs || 15000);

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${effectiveKey}`
        },
        body: JSON.stringify({
          model: config.model || 'gpt-4o-mini',
          messages: [{ role: 'user', content: 'Respond with OK' }],
          max_tokens: 10
        }),
        signal: controller.signal
      });
      clearTimeout(timeout);
      const latencyMs = Date.now() - startTime;

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return {
          success: false,
          latencyMs,
          model: config.model,
          error: errJson.error?.message || `HTTP ${res.status}: ${res.statusText}`
        };
      }
      return { success: true, latencyMs, model: config.model };
    }

    if (config.provider === 'anthropic') {
      const endpoint = config.endpoint || 'https://api.anthropic.com/v1/messages';
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), config.timeoutMs || 15000);

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': effectiveKey || '',
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: config.model || 'claude-3-5-haiku-20241022',
          max_tokens: 10,
          messages: [{ role: 'user', content: 'Respond with OK' }]
        }),
        signal: controller.signal
      });
      clearTimeout(timeout);
      const latencyMs = Date.now() - startTime;

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return {
          success: false,
          latencyMs,
          model: config.model,
          error: errJson.error?.message || `HTTP ${res.status}: ${res.statusText}`
        };
      }
      return { success: true, latencyMs, model: config.model };
    }

    if (config.provider === 'deepseek') {
      const endpoint = config.endpoint || 'https://api.deepseek.com/chat/completions';
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), config.timeoutMs || 15000);

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${effectiveKey}`
        },
        body: JSON.stringify({
          model: config.model || 'deepseek-chat',
          messages: [{ role: 'user', content: 'Respond with OK' }],
          max_tokens: 10
        }),
        signal: controller.signal
      });
      clearTimeout(timeout);
      const latencyMs = Date.now() - startTime;

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        return {
          success: false,
          latencyMs,
          model: config.model,
          error: errJson.error?.message || `HTTP ${res.status}: ${res.statusText}`
        };
      }
      return { success: true, latencyMs, model: config.model };
    }

    return {
      success: false,
      latencyMs: Date.now() - startTime,
      model: config.model,
      error: `Unsupported provider type: ${config.provider}`
    };
  } catch (err: any) {
    return {
      success: false,
      latencyMs: Date.now() - startTime,
      model: config.model,
      error: err.name === 'AbortError' ? 'Connection timed out.' : (err.message || String(err))
    };
  }
}

/**
 * Execute generation with fallback routing across active providers
 */
export async function executeMultiProviderRequest(
  providers: AIProviderConfig[],
  routing: AITaskRouting,
  prompt: string,
  options: GenerationOptions = {}
): Promise<AIResponse> {
  const task = options.task || 'writing';
  const targetProviderId =
    task === 'writing' ? routing.writingProviderId :
    task === 'research' ? routing.researchProviderId :
    task === 'humanize' ? routing.humanizeProviderId :
    task === 'seo' ? routing.seoProviderId :
    task === 'magic' ? routing.magicProviderId :
    routing.writingProviderId;

  // Determine priority order: targeted provider -> default provider -> fallback provider -> any enabled provider
  const target = providers.find(p => p.id === targetProviderId && p.enabled);
  const def = providers.find(p => p.isDefault && p.enabled);
  const fallback = providers.find(p => p.isFallback && p.enabled);
  const others = providers.filter(p => p.enabled && p.id !== target?.id && p.id !== def?.id && p.id !== fallback?.id);

  const candidateProviders = [target, def, fallback, ...others].filter(Boolean) as AIProviderConfig[];
  // Deduplicate
  const uniqueProviders = candidateProviders.filter((p, i, arr) => arr.findIndex(x => x.id === p.id) === i);

  if (uniqueProviders.length === 0) {
    // Fall back to default Gemini config using env
    uniqueProviders.push({
      id: 'prov-gemini-fallback',
      provider: 'gemini',
      name: 'Google Gemini (Env)',
      apiKey: process.env.GEMINI_API_KEY || '',
      model: 'gemini-3.8-flash',
      temperature: 0.7,
      maxTokens: 4096,
      timeoutMs: 30000,
      enabled: true,
      isDefault: true,
      isFallback: false
    });
  }

  let lastError: any = null;

  for (const prov of uniqueProviders) {
    const startTime = Date.now();
    try {
      if (prov.provider === 'gemini') {
        const apiKey = prov.apiKey || process.env.GEMINI_API_KEY;
        if (!apiKey) continue;
        const ai = new GoogleGenAI({ apiKey });
        const modelsToTry = [prov.model || 'gemini-3.8-flash', 'gemini-flash-latest', 'gemini-2.5-flash'];

        for (const m of modelsToTry) {
          try {
            const configObj: any = {
              temperature: options.temperature ?? prov.temperature ?? 0.7
            };
            if (options.systemInstruction) {
              configObj.systemInstruction = options.systemInstruction;
            }
            if (options.jsonMode) {
              configObj.responseMimeType = 'application/json';
            }

            const res = await ai.models.generateContent({
              model: m,
              contents: prompt,
              config: configObj
            });
            const text = res.text?.trim();
            if (text) {
              return {
                text,
                provider: 'gemini',
                model: m,
                latencyMs: Date.now() - startTime
              };
            }
          } catch (mErr: any) {
            lastError = mErr;
            const msg = String(mErr?.message || mErr || '');
            if (!msg.includes('503') && !msg.includes('429')) {
              break; // Not transient, don't try all submodels
            }
          }
        }
      } else if (prov.provider === 'openai') {
        if (!prov.apiKey) continue;
        const endpoint = prov.endpoint || 'https://api.openai.com/v1/chat/completions';
        const messages: any[] = [];
        if (options.systemInstruction) {
          messages.push({ role: 'system', content: options.systemInstruction });
        }
        messages.push({ role: 'user', content: prompt });

        const reqBody: any = {
          model: prov.model || 'gpt-4o-mini',
          messages,
          temperature: options.temperature ?? prov.temperature ?? 0.7,
          max_tokens: options.maxTokens ?? prov.maxTokens ?? 4096
        };
        if (options.jsonMode) {
          reqBody.response_format = { type: 'json_object' };
        }

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${prov.apiKey}`
          },
          body: JSON.stringify(reqBody)
        });

        if (res.ok) {
          const data = await res.json();
          const text = data.choices?.[0]?.message?.content?.trim();
          if (text) {
            return {
              text,
              provider: 'openai',
              model: prov.model,
              latencyMs: Date.now() - startTime
            };
          }
        } else {
          lastError = new Error(`OpenAI HTTP ${res.status}: ${res.statusText}`);
        }
      } else if (prov.provider === 'anthropic') {
        if (!prov.apiKey) continue;
        const endpoint = prov.endpoint || 'https://api.anthropic.com/v1/messages';
        const reqBody: any = {
          model: prov.model || 'claude-3-5-haiku-20241022',
          max_tokens: options.maxTokens ?? prov.maxTokens ?? 4096,
          messages: [{ role: 'user', content: prompt }]
        };
        if (options.systemInstruction) {
          reqBody.system = options.systemInstruction;
        }

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': prov.apiKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify(reqBody)
        });

        if (res.ok) {
          const data = await res.json();
          const text = data.content?.[0]?.text?.trim();
          if (text) {
            return {
              text,
              provider: 'anthropic',
              model: prov.model,
              latencyMs: Date.now() - startTime
            };
          }
        } else {
          lastError = new Error(`Anthropic HTTP ${res.status}: ${res.statusText}`);
        }
      } else if (prov.provider === 'deepseek') {
        if (!prov.apiKey) continue;
        const endpoint = prov.endpoint || 'https://api.deepseek.com/chat/completions';
        const messages: any[] = [];
        if (options.systemInstruction) {
          messages.push({ role: 'system', content: options.systemInstruction });
        }
        messages.push({ role: 'user', content: prompt });

        const reqBody: any = {
          model: prov.model || 'deepseek-chat',
          messages,
          temperature: options.temperature ?? prov.temperature ?? 0.7,
          max_tokens: options.maxTokens ?? prov.maxTokens ?? 4096
        };
        if (options.jsonMode) {
          reqBody.response_format = { type: 'json_object' };
        }

        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${prov.apiKey}`
          },
          body: JSON.stringify(reqBody)
        });

        if (res.ok) {
          const data = await res.json();
          const text = data.choices?.[0]?.message?.content?.trim();
          if (text) {
            return {
              text,
              provider: 'deepseek',
              model: prov.model,
              latencyMs: Date.now() - startTime
            };
          }
        } else {
          lastError = new Error(`DeepSeek HTTP ${res.status}: ${res.statusText}`);
        }
      }
    } catch (err) {
      lastError = err;
      console.warn(`Provider ${prov.name} generation failed:`, err);
    }
  }

  throw new Error(`All active AI providers failed. Last error: ${lastError?.message || 'Unknown error'}`);
}
