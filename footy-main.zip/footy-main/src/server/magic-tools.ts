import { db } from './db.js';
import { MagicToolInvocation, Article, Category, Topic } from '../types.js';
import { runHumanizeText } from './humanizer.js';
import { fetchAndExtractUrl, generateResearchBrief } from './research.js';
import { testProviderConnection } from './ai-providers.js';

export interface ToolDefinition {
  name: string;
  category?: string;
  description: string;
  dangerous: boolean;
  requiresConfirmation: boolean;
  execute: (params: any) => Promise<any>;
}

export const MAGIC_TOOLS: Record<string, ToolDefinition> = {
  // --- Content Tools ---
  searchArticles: {
    name: 'searchArticles',
    description: 'Search articles across the publication by title, keyword, status, or category',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { query?: string; categoryId?: string; status?: string }) => {
      const articles = db.getArticles({
        search: params.query,
        categoryId: params.categoryId,
        status: params.status
      });
      return {
        total: articles.length,
        articles: articles.slice(0, 10).map(a => ({
          id: a.id,
          title: a.title,
          slug: a.slug,
          status: a.status,
          primaryFocusKeyword: a.primaryFocusKeyword,
          aiSeoScore: a.aiSeoScore,
          updatedAt: a.updatedAt
        }))
      };
    }
  },

  getArticle: {
    name: 'getArticle',
    description: 'Retrieve full article content and metadata by ID',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { id: string }) => {
      const article = db.getArticleById(params.id);
      if (!article) throw new Error(`Article not found with ID: ${params.id}`);
      return article;
    }
  },

  createArticle: {
    name: 'createArticle',
    description: 'Create a new article draft with title, content, and SEO metadata',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: Partial<Article> & { title: string }) => {
      const saved = db.saveArticle({
        ...params,
        status: 'draft'
      });
      return {
        id: saved.id,
        title: saved.title,
        slug: saved.slug,
        status: saved.status,
        message: 'Article draft successfully created.'
      };
    }
  },

  updateArticle: {
    name: 'updateArticle',
    description: 'Update an existing article draft content or metadata',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { id: string; updates: Partial<Article> }) => {
      const existing = db.getArticleById(params.id);
      if (!existing) throw new Error(`Article not found: ${params.id}`);
      const updated = db.saveArticle({
        ...existing,
        ...params.updates,
        id: params.id
      });
      return {
        id: updated.id,
        title: updated.title,
        status: updated.status,
        message: 'Article successfully updated.'
      };
    }
  },

  deleteArticle: {
    name: 'deleteArticle',
    description: 'Permanently remove an article from the database',
    dangerous: true,
    requiresConfirmation: true,
    execute: async (params: { id: string }) => {
      const art = db.getArticleById(params.id);
      const title = art?.title || params.id;
      const success = db.deleteArticle(params.id);
      if (!success) throw new Error(`Failed to delete article: ${params.id}`);
      return { id: params.id, title, message: `Article "${title}" deleted.` };
    }
  },

  publishArticle: {
    name: 'publishArticle',
    description: 'Promote an article draft to published status on the public blog',
    dangerous: true,
    requiresConfirmation: true,
    execute: async (params: { id: string }) => {
      const art = db.getArticleById(params.id);
      if (!art) throw new Error(`Article not found: ${params.id}`);
      const updated = db.saveArticle({
        ...art,
        id: params.id,
        status: 'published',
        publishedAt: new Date().toISOString()
      });
      return {
        id: updated.id,
        title: updated.title,
        slug: updated.slug,
        status: 'published',
        url: `/article/${updated.slug}`,
        message: `Article "${updated.title}" is now LIVE on the public blog.`
      };
    }
  },

  // --- Taxonomy Tools ---
  getCategories: {
    name: 'getCategories',
    description: 'List all editorial categories and desks',
    dangerous: false,
    requiresConfirmation: false,
    execute: async () => {
      const categories = db.getCategories();
      const articles = db.getArticles();
      return categories.map(c => ({
        id: c.id,
        name: c.name,
        slug: c.slug,
        description: c.description,
        articleCount: articles.filter(a => a.categoryId === c.id).length
      }));
    }
  },

  createCategory: {
    name: 'createCategory',
    description: 'Create a new editorial category desk',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { name: string; description?: string; slug?: string }) => {
      const saved = db.saveCategory(params);
      return { id: saved.id, name: saved.name, slug: saved.slug, message: 'Category created.' };
    }
  },

  getTopics: {
    name: 'getTopics',
    description: 'List all content topic pillars and coverage instructions',
    dangerous: false,
    requiresConfirmation: false,
    execute: async () => {
      return db.getTopics();
    }
  },

  createTopic: {
    name: 'createTopic',
    description: 'Create a new strategic topic pillar with targeted keywords and instructions',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: Partial<Topic> & { name: string }) => {
      const saved = db.saveTopic(params);
      return { id: saved.id, name: saved.name, priority: saved.priority, message: 'Topic pillar created.' };
    }
  },

  // --- Research Tools ---
  researchWebUrl: {
    name: 'researchWebUrl',
    description: 'Fetch and extract deep editorial intelligence from an external webpage (claims, stats, quotes)',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { url: string }) => {
      const providers = db.getAIProviders();
      const routing = db.getTaskRouting();
      const extracted = await fetchAndExtractUrl(params.url, providers, routing);
      db.saveResearchSource(extracted);
      return {
        id: extracted.id,
        title: extracted.title,
        keyClaims: extracted.keyClaims,
        statistics: extracted.statistics,
        quotes: extracted.quotes,
        suggestedTopics: extracted.suggestedTopics
      };
    }
  },

  // --- Editorial & Humanizing Tools ---
  humanizeText: {
    name: 'humanizeText',
    description: 'Apply strict editorial humanizer to eliminate AI clichés, filler transitions, and robotic cadence',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { text: string; focusKeyword?: string; customDirective?: string }) => {
      const providers = db.getAIProviders();
      const routing = db.getTaskRouting();
      const result = await runHumanizeText({
        text: params.text,
        focusKeyword: params.focusKeyword,
        customDirective: params.customDirective,
        providers,
        routing
      });
      return result;
    }
  },

  // --- SEO Tools ---
  auditArticleSEO: {
    name: 'auditArticleSEO',
    description: 'Audit an article for search intent, keyword density, semantic heading structure, and meta compliance',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { id: string }) => {
      const art = db.getArticleById(params.id);
      if (!art) throw new Error(`Article not found: ${params.id}`);
      return {
        articleId: art.id,
        title: art.title,
        focusKeyword: art.primaryFocusKeyword,
        seoScore: art.aiSeoScore || 85,
        analysis: art.aiSeoAnalysis || {
          strengths: ['H1 clearly framed around key entity', 'Content structured with semantic H2 subdivisions'],
          warnings: ['Verify internal links to related tactical guides'],
          recommendations: ['Add 2 contextual links pointing to transfer and analytics articles']
        }
      };
    }
  },

  // --- Settings & Diagnostics Tools ---
  testAIProvider: {
    name: 'testAIProvider',
    description: 'Run a live connection test and measure response latency for an AI provider',
    dangerous: false,
    requiresConfirmation: false,
    execute: async (params: { providerId: string }) => {
      const providers = db.getAIProviders();
      const prov = providers.find(p => p.id === params.providerId);
      if (!prov) throw new Error(`Provider not found: ${params.providerId}`);
      const testRes = await testProviderConnection(prov);
      // Persist test result
      db.saveAIProvider({
        ...prov,
        lastTestedAt: new Date().toISOString(),
        lastTestStatus: testRes.success ? 'connected' : 'failed',
        lastTestLatencyMs: testRes.latencyMs,
        lastTestError: testRes.error
      });
      return testRes;
    }
  },

  getProjectMemory: {
    name: 'getProjectMemory',
    description: 'Retrieve project background, brand voice guidelines, and editorial principles',
    dangerous: false,
    requiresConfirmation: false,
    execute: async () => {
      const settings = db.getSettings();
      const memory = db.getMemoryItems();
      return {
        context: settings.projectContext,
        memoryItems: memory.map(m => ({ title: m.title, type: m.type, content: m.content.slice(0, 300) }))
      };
    }
  }
};
