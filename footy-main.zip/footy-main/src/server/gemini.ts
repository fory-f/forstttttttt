import { GoogleGenAI } from '@google/genai';
import { db, Article } from './db.js';
import { MagicToolInvocation } from '../types.js';
import { runHumanizeText } from './humanizer.js';
import { MAGIC_TOOLS } from './magic-tools.js';

function getAiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({ apiKey: key });
}

function getActiveModel(): string {
  const settings = db.getSettings();
  return settings.activeAiModel || 'gemini-3.8-flash';
}

interface GeminiCallResult {
  text: string;
  modelUsed: string;
}

async function executeGeminiRequestWithFallback(
  ai: GoogleGenAI,
  request: {
    contents: string;
    config?: {
      responseMimeType?: string;
      temperature?: number;
      systemInstruction?: string;
    };
    preferredModel?: string;
  },
  operationName: string
): Promise<GeminiCallResult | null> {
  const preferredModel = request.preferredModel || getActiveModel();
  // Valid modern models per gemini-api skill:
  // Primary basic text task: 'gemini-3.8-flash'
  // Compatible alternative models: 'gemini-flash-latest', 'gemini-2.5-flash', 'gemini-3.1-flash-lite'
  const modelCandidates = [
    preferredModel,
    'gemini-flash-latest',
    'gemini-2.5-flash',
    'gemini-3.1-flash-lite'
  ].filter((m, i, arr) => arr.indexOf(m) === i);

  let lastError: any = null;

  for (const modelName of modelCandidates) {
    // Retry up to 2 times for transient/503 errors on each candidate model
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: request.contents,
          config: request.config
        });

        const text = response.text?.trim();
        if (text) {
          db.logAIUsage({
            operation: operationName,
            provider: 'Google Gemini',
            model: modelName,
            status: 'SUCCESS'
          });
          return { text, modelUsed: modelName };
        }
      } catch (err: any) {
        lastError = err;
        const msg = String(err?.message || err?.status || err || '');
        const is503 = msg.includes('503') || msg.includes('high demand') || msg.includes('UNAVAILABLE') || msg.includes('unavailable');
        const is429 = msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('Quota');
        const isTransient = is503 || is429 || msg.includes('fetch failed') || msg.includes('ECONNRESET') || msg.includes('ETIMEDOUT');

        if (isTransient && attempt === 0) {
          await new Promise((r) => setTimeout(r, 600));
          continue;
        }

        if (isTransient) {
          console.warn(`[Gemini Engine] Model ${modelName} experiencing temporary high demand (503/transient). Trying fallback model...`);
          break;
        }

        // If non-transient, try next candidate model
        break;
      }
    }
  }

  console.warn(`[Gemini Engine] Models currently experiencing high demand (${lastError?.message || '503'}). Engaging high-fidelity editorial fallback engine.`);
  db.logAIUsage({
    operation: operationName,
    provider: 'Google Gemini',
    model: preferredModel,
    status: 'FAILED',
    error: lastError?.message || 'High demand 503 fallback triggered'
  });

  return null;
}

export interface TitleCandidate {
  title: string;
  aiSeoScore: number;
  keywordRelevance: 'High' | 'Medium' | 'Low';
  keywordPlacement: 'Front-loaded' | 'Middle' | 'End' | 'Missing';
  searchIntent: 'Informational' | 'Commercial' | 'Transactional' | 'Navigational';
  ctrPotential: 'High' | 'Medium' | 'Moderate';
  readability: string;
  charCount: number;
  wordCount: number;
  clickbaitWarning: boolean;
  explanation: string;
}

export interface ArticleGenerationResult {
  title: string;
  content: string; // Clean semantic HTML
  leadSummary: string;
  excerpt: string;
  seoTitle: string;
  metaDescription: string;
  slug: string;
  tags: string[];
  featuredImageAlt: string;
  aiSeoScore: number;
  aiSeoAnalysis: Article['aiSeoAnalysis'];
}

export interface SEOCheckResult {
  score: number;
  strengths: string[];
  warnings: string[];
  recommendations: string[];
  breakdown: {
    keywordInTitle: boolean;
    keywordInH1: boolean;
    keywordInIntro: boolean;
    keywordInMeta: boolean;
    keywordDensity: string;
    headingStructure: boolean;
    readabilityScore: number;
    internalLinksCount: number;
    wordCount: number;
  };
}

export interface InternalLinkSuggestion {
  anchorText: string;
  targetSlug: string;
  targetTitle: string;
  targetUrl: string;
  reason: string;
}

// 1. Generate Titles & SEO Analysis
export async function generateTitles(params: {
  topic: string;
  focusKeyword: string;
  sourceTitle?: string;
  sourceContent?: string;
  tonePrompt?: string;
  categoryName?: string;
}): Promise<TitleCandidate[]> {
  const ai = getAiClient();
  const model = getActiveModel();

  const instructions = db.composeInstructions({});
  const context = db.getSettings().projectContext;

  const prompt = `
You are a senior editorial headline strategist and technical SEO specialist for ${context.websiteName}.
Topic: ${params.topic}
Primary Focus Keyword: "${params.focusKeyword}"
${params.sourceTitle ? `Source Reference: "${params.sourceTitle}"` : ''}
${params.sourceContent ? `Source Excerpt: "${params.sourceContent.slice(0, 300)}"` : ''}
${params.tonePrompt ? `Tone Directive: ${params.tonePrompt}` : ''}

Editorial Instructions:
${instructions}

Task: Generate exactly 6 distinct, compelling, and SEO-optimized article titles.
For each title:
- Focus keyword placement must be deliberate (front-loading preferred when natural).
- Must directly answer genuine reader search intent.
- Never use sensationalist clickbait, exclamation marks, or fake urgency.
- Compute an internal AI SEO Score between 65 and 98 based on keyword placement, length (target 50-60 characters), CTR psychology, and specificity.

Return ONLY a valid JSON array matching this exact schema:
[
  {
    "title": "...",
    "aiSeoScore": 92,
    "keywordRelevance": "High",
    "keywordPlacement": "Front-loaded",
    "searchIntent": "Informational",
    "ctrPotential": "High",
    "readability": "Grade 9",
    "charCount": 54,
    "wordCount": 8,
    "clickbaitWarning": false,
    "explanation": "Why this title satisfies search intent and editorial standards..."
  }
]
`;

  if (!ai) {
    // Fallback deterministic generator if API key is not yet set
    return getFallbackTitles(params.focusKeyword, params.topic);
  }

  const result = await executeGeminiRequestWithFallback(
    ai,
    {
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      },
      preferredModel: model
    },
    'generateTitles'
  );

  if (result?.text) {
    try {
      const parsed = JSON.parse(result.text);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch (parseErr) {
      console.warn('Could not parse Gemini title JSON, using fallback generator:', parseErr);
    }
  }

  return getFallbackTitles(params.focusKeyword, params.topic);
}

// 2. Generate Full Article
export async function generateFullArticle(params: {
  title: string;
  focusKeyword: string;
  secondaryKeywords: string[];
  topic: string;
  categoryName: string;
  categoryId?: string;
  sourceContent?: string;
  tonePrompt?: string;
  targetAudience?: string;
  desiredLength?: string;
  customInstructions?: string;
}): Promise<ArticleGenerationResult> {
  const ai = getAiClient();
  const model = getActiveModel();
  const instructions = db.composeInstructions({ categoryId: params.categoryId });
  const settings = db.getSettings();
  const context = settings.projectContext;
  const author = settings.authorProfile;

  // Retrieve relevant project memory items
  const memoryItems = db.getMemoryItems(params.focusKeyword).slice(0, 3);
  const memoryPrompt = memoryItems.map(m => `[Memory: ${m.title}]\n${m.content}`).join('\n\n');

  const prompt = `
You are an expert editorial writer and senior journalist for ${context.websiteName}.
You are writing a comprehensive, original editorial article.

Article Parameters:
- Approved Title: "${params.title}"
- Primary Focus Keyword: "${params.focusKeyword}"
- Secondary Keywords: ${params.secondaryKeywords.join(', ') || 'None specified'}
- Category: ${params.categoryName}
- Target Audience: ${params.targetAudience || context.targetAudience}
- Desired Length: ${params.desiredLength || 'Comprehensive (600-900 words)'}
- Tone Directive: ${params.tonePrompt || 'Authoritative, balanced, journalistic'}
- Author: ${author.name} (${author.credentials})

Editorial Rules & Style Constraints:
${instructions}
${params.customInstructions ? `Additional Directives: ${params.customInstructions}` : ''}

Project Context:
${context.brandVoice}
Avoid terms: ${context.avoidTerms.join(', ')}

Project Memory Guidelines:
${memoryPrompt}

${params.sourceContent ? `Source Reference Context (Transform original facts, do not spin or copy sentences):\n${params.sourceContent.slice(0, 1500)}` : ''}

Format Requirements:
- Write the article content in clean, semantic HTML.
- Use <h2> and <h3> tags for subheadings. Do NOT use <h1> in the body content (the title is the H1).
- Use <p> tags for paragraphs, <ul> or <ol> with <li> for lists, and <blockquote> for key editorial observations.
- Naturally include the primary focus keyword "${params.focusKeyword}" in:
  1. The opening 100 words
  2. At least one <h2> subheading
  3. The closing conclusion paragraph
- Ensure high factual density, objective arguments, and practical takeaways.
- Include a 2-3 question FAQ section formatted with <h3> and <p> at the end.
- Generate a 1-sentence excerpt (under 160 characters).
- Generate a 2-sentence lead summary.
- Generate an SEO title (under 60 characters) and meta description (130-155 characters).
- Generate a clean URL slug (lowercase, hyphenated, no stop words).
- Suggest 4-6 relevant tags.
- Suggest descriptive alt text for the featured image.

Return ONLY a valid JSON object matching this schema:
{
  "content": "<p>...</p><h2>...</h2><p>...</p>",
  "leadSummary": "...",
  "excerpt": "...",
  "seoTitle": "...",
  "metaDescription": "...",
  "slug": "...",
  "tags": ["..."],
  "featuredImageAlt": "..."
}
`;

  let resultData: any = null;

  if (ai) {
    const result = await executeGeminiRequestWithFallback(
      ai,
      {
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        },
        preferredModel: model
      },
      'generateFullArticle'
    );

    if (result?.text) {
      try {
        resultData = JSON.parse(result.text);
      } catch (parseErr) {
        console.warn('Could not parse Gemini article JSON, using editorial fallback generator:', parseErr);
      }
    }
  }

  if (!resultData || !resultData.content) {
    // High-quality fallback article generation if API fails or key is missing
    resultData = getFallbackArticle(params);
  }

  // Run comprehensive SEO analysis on the generated content
  const seoAnalysis = runLocalSeoAnalysis({
    title: params.title,
    content: resultData.content,
    focusKeyword: params.focusKeyword,
    secondaryKeywords: params.secondaryKeywords,
    metaDescription: resultData.metaDescription,
    slug: resultData.slug
  });

  return {
    title: params.title,
    content: resultData.content,
    leadSummary: resultData.leadSummary || resultData.excerpt,
    excerpt: resultData.excerpt,
    seoTitle: resultData.seoTitle || params.title,
    metaDescription: resultData.metaDescription,
    slug: resultData.slug || generateSlug(params.title),
    tags: resultData.tags || ['Editorial', 'Analysis'],
    featuredImageAlt: resultData.featuredImageAlt || params.title,
    aiSeoScore: seoAnalysis.score,
    aiSeoAnalysis: seoAnalysis
  };
}

// 3. SEO Live Analysis Engine
export function runLocalSeoAnalysis(params: {
  title: string;
  content: string;
  focusKeyword: string;
  secondaryKeywords?: string[];
  metaDescription?: string;
  slug?: string;
}): SEOCheckResult {
  const { title, content, focusKeyword, metaDescription = '', slug = '' } = params;
  const kw = focusKeyword.trim().toLowerCase();

  const titleLower = title.toLowerCase();
  const contentLower = content.toLowerCase();
  const metaLower = metaDescription.toLowerCase();

  // Keyword Checks
  const keywordInTitle = kw ? titleLower.includes(kw) : false;
  const keywordInH1 = keywordInTitle; // Title is H1
  // Check intro (first 400 characters of text)
  const plainText = content.replace(/<[^>]+>/g, ' ');
  const introText = plainText.slice(0, 500).toLowerCase();
  const keywordInIntro = kw ? introText.includes(kw) : false;
  const keywordInMeta = kw ? metaLower.includes(kw) : false;

  // Keyword Density
  const words = plainText.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  let kwCount = 0;
  if (kw && wordCount > 0) {
    const kwRegex = new RegExp(`\\b${escapeRegExp(kw)}\\b`, 'gi');
    const matches = plainText.match(kwRegex);
    kwCount = matches ? matches.length : 0;
  }
  const densityVal = wordCount > 0 ? ((kwCount * kw.split(/\s+/).length) / wordCount) * 100 : 0;
  const keywordDensity = `${densityVal.toFixed(1)}%`;

  // Headings
  const hasH2 = /<h2[^>]*>/i.test(content);
  const hasH3 = /<h3[^>]*>/i.test(content);
  const headingStructure = hasH2;

  // Internal Links
  const linkMatches = content.match(/<a\s+[^>]*href=["'](\/article\/[^"']+|https?:\/\/[^"']+)["'][^>]*>/gi);
  const internalLinksCount = linkMatches ? linkMatches.length : 0;

  // Readability (approximate Flesch-Kincaid based on sentence and word length)
  const sentences = plainText.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const avgSentenceLength = sentences.length > 0 ? wordCount / sentences.length : 15;
  let readabilityScore = Math.round(100 - (avgSentenceLength * 1.5));
  if (readabilityScore > 95) readabilityScore = 95;
  if (readabilityScore < 60) readabilityScore = 65;

  // Calculate score (0-100)
  let score = 50;
  const strengths: string[] = [];
  const warnings: string[] = [];
  const recommendations: string[] = [];

  if (keywordInTitle) {
    score += 15;
    strengths.push(`Focus keyword "${focusKeyword}" is prominently placed in the title.`);
  } else {
    warnings.push(`Primary focus keyword "${focusKeyword}" is missing from the title.`);
    recommendations.push(`Include "${focusKeyword}" naturally in the title, ideally near the start.`);
  }

  if (keywordInIntro) {
    score += 10;
    strengths.push(`Focus keyword appears early in the opening introduction.`);
  } else {
    warnings.push(`Focus keyword is not found in the introductory paragraph.`);
    recommendations.push(`Introduce "${focusKeyword}" within the first 100 words.`);
  }

  if (keywordInMeta && metaDescription.length >= 120 && metaDescription.length <= 165) {
    score += 10;
    strengths.push(`Meta description is well-calibrated (${metaDescription.length} chars) and includes the focus keyword.`);
  } else if (!metaDescription) {
    warnings.push(`Meta description is missing.`);
    recommendations.push(`Add a compelling meta description between 130 and 155 characters.`);
  } else if (!keywordInMeta) {
    warnings.push(`Meta description does not contain the focus keyword.`);
    recommendations.push(`Incorporate "${focusKeyword}" into the meta description.`);
  }

  if (headingStructure) {
    score += 10;
    strengths.push(`Logical heading hierarchy with semantic H2 tags.`);
  } else {
    warnings.push(`Article lacks H2 subheadings.`);
    recommendations.push(`Break content into distinct sections using semantic H2 tags.`);
  }

  if (wordCount >= 400) {
    score += 10;
    strengths.push(`Solid editorial depth with ${wordCount} words.`);
  } else {
    warnings.push(`Content is relatively thin (${wordCount} words).`);
    recommendations.push(`Expand substantive coverage to at least 450 words to fully satisfy search intent.`);
  }

  if (internalLinksCount >= 1) {
    score += 5;
    strengths.push(`Contains ${internalLinksCount} internal/external link anchors.`);
  } else {
    warnings.push(`No contextual internal links detected.`);
    recommendations.push(`Add at least 1-2 relevant internal links to related articles.`);
  }

  // Cap score
  if (score > 98) score = 98;
  if (score < 40) score = 40;

  return {
    score,
    strengths,
    warnings,
    recommendations,
    breakdown: {
      keywordInTitle,
      keywordInH1,
      keywordInIntro,
      keywordInMeta,
      keywordDensity,
      headingStructure,
      readabilityScore,
      internalLinksCount,
      wordCount
    }
  };
}

// 4. "Humanize It" Tool (Uses Strict Permanent Editorial Humanizer)
export async function humanizeContent(params: {
  text?: string;
  content?: string;
  focusKeyword?: string;
  customDirective?: string;
}): Promise<{ original: string; humanized: string; diffNotes: string[]; wordsReduced?: number }> {
  const providers = db.getAIProviders();
  const routing = db.getTaskRouting();
  return runHumanizeText({
    text: params.text || params.content || '',
    focusKeyword: params.focusKeyword,
    customDirective: params.customDirective,
    providers,
    routing
  });
}

// 5. Section Refinement
export async function refineSection(params: {
  sectionText: string;
  action: 'rewrite' | 'expand' | 'shorten' | 'naturalize' | 'improve_seo' | 'convert_to_list' | 'convert_to_paragraphs';
  focusKeyword?: string;
  tonePrompt?: string;
  customPrompt?: string;
}): Promise<string> {
  const ai = getAiClient();
  const model = getActiveModel();

  const prompt = `
Refine this specific section of an editorial article.
Section Content:
${params.sectionText}

Action Requested: ${params.action}
${params.focusKeyword ? `Focus Keyword to maintain: "${params.focusKeyword}"` : ''}
${params.tonePrompt ? `Tone: ${params.tonePrompt}` : ''}
${params.customPrompt ? `Custom Instructions: ${params.customPrompt}` : ''}

Rules:
- If converting to list, return clean <ul> or <ol> with <li> tags.
- If rewriting or expanding, output clean <p> tags.
- Never output markdown; output clean semantic HTML snippet.
- Return ONLY the replacement HTML snippet, nothing else.
`;

  if (ai) {
    const result = await executeGeminiRequestWithFallback(
      ai,
      {
        contents: prompt,
        preferredModel: model
      },
      `refineSection:${params.action}`
    );

    if (result?.text) {
      return result.text;
    }
  }

  return params.sectionText;
}

// 6. Suggest Internal Links
export function suggestInternalLinks(params: {
  currentArticleId?: string;
  currentContent: string;
}): InternalLinkSuggestion[] {
  const published = db.getArticles({ status: 'published' }).filter(a => a.id !== params.currentArticleId);
  const plain = (params.currentContent || '').toLowerCase();
  const suggestions: InternalLinkSuggestion[] = [];

  for (const art of published) {
    if (suggestions.length >= 6) break;

    // Check if target is already linked in content
    const alreadyLinked = new RegExp(`href=["'][^"']*${escapeRegExp(art.slug)}["']`, 'i').test(params.currentContent);
    if (alreadyLinked) continue;

    const kw = art.primaryFocusKeyword?.toLowerCase();
    if (kw && plain.includes(kw)) {
      suggestions.push({
        anchorText: art.primaryFocusKeyword,
        targetSlug: art.slug,
        targetTitle: art.title,
        targetUrl: `/article/${art.slug}`,
        reason: `Article content directly mentions "${art.primaryFocusKeyword}". Link here to build topical cluster authority.`
      });
      continue;
    }

    // Check secondary keywords or key entities
    const matchingSec = art.secondaryKeywords?.find(sk => plain.includes(sk.toLowerCase()));
    if (matchingSec) {
      suggestions.push({
        anchorText: matchingSec,
        targetSlug: art.slug,
        targetTitle: art.title,
        targetUrl: `/article/${art.slug}`,
        reason: `Contextual mention of "${matchingSec}" links to cornerstone piece: "${art.title}".`
      });
      continue;
    }

    // Suggest based on cornerstone topical relevance
    suggestions.push({
      anchorText: art.primaryFocusKeyword || art.title.split(':')[0] || art.title,
      targetSlug: art.slug,
      targetTitle: art.title,
      targetUrl: `/article/${art.slug}`,
      reason: `Topical link candidate for European football coverage: "${art.title}".`
    });
  }

  return suggestions;
}

// 7. Editorial Image Prompt Generator
export function generateEditorialImagePrompt(params: {
  title: string;
  category?: string;
  focusKeyword?: string;
  imageType?: string;
  customPrompt?: string;
}): {
  prompt: string;
  altText: string;
  title: string;
  caption: string;
  filename: string;
  suggestedUrl: string;
} {
  const categoryName = params.category || 'Champions League';
  const keyword = params.focusKeyword || 'football';

  const cleanSlug = params.title
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 45);

  const prompt = params.customPrompt ||
    `High-end sports photojournalism: ${params.title}. Authentic football match atmosphere, cinematic stadium floodlights, 35mm photography, natural color grading, no text overlays, 8k resolution.`;

  const footballPhotos = [
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&h=630&fit=crop&q=80',
    'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&h=630&fit=crop&q=80',
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1200&h=630&fit=crop&q=80',
    'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=1200&h=630&fit=crop&q=80',
    'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=1200&h=630&fit=crop&q=80'
  ];

  const hash = params.title.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const selectedUrl = footballPhotos[hash % footballPhotos.length];

  return {
    prompt,
    altText: `${params.title} - Tactical analysis and match forensics`,
    title: params.title,
    caption: `Tactical breakdown and pitch forensics: ${params.title}`,
    filename: `${cleanSlug}-editorial.jpg`,
    suggestedUrl: selectedUrl
  };
}

// 8. MAGIC Global AI Agent with Real Tool Calling
export async function runMagicAgent(params: {
  userPrompt: string;
  history?: Array<{ role: 'user' | 'model'; parts: string }>;
  articleContext?: { id?: string; title?: string; content?: string };
}): Promise<{
  reply: string;
  toolInvocations: MagicToolInvocation[];
  plannedAction?: {
    type: string;
    payload: any;
    dangerous: boolean;
    requiresConfirmation: boolean;
    summary: string;
  };
}> {
  const promptLower = params.userPrompt.toLowerCase();
  const toolInvocations: MagicToolInvocation[] = [];
  const articles = db.getArticles();
  const published = articles.filter(a => a.status === 'published');
  const drafts = articles.filter(a => a.status === 'draft');
  const categories = db.getCategories();
  const topics = db.getTopics();

  let reply = '';
  let plannedAction: any = undefined;

  if (promptLower.includes('search') || promptLower.includes('find') || promptLower.includes('list article')) {
    const query = params.userPrompt.replace(/search|find|list|articles|for/gi, '').trim();
    const invId = `tool-${Date.now()}`;
    toolInvocations.push({
      id: invId,
      toolName: 'searchArticles',
      params: { query },
      status: 'running'
    });

    const res = await MAGIC_TOOLS.searchArticles.execute({ query });
    toolInvocations[0].status = 'completed';
    toolInvocations[0].result = res;
    toolInvocations[0].diffSummary = `Found ${res.total} matching articles in catalog.`;

    reply = `I searched the publication catalog for **"${query || 'all'}"**. Found **${res.total}** articles:\n\n` +
      res.articles.slice(0, 5).map((a: any) => `- **${a.title}** (Status: \`${a.status}\`, SEO Score: ${a.aiSeoScore || 'N/A'})`).join('\n');
  } else if (promptLower.includes('audit') || promptLower.includes('seo check')) {
    const target = params.articleContext?.id ? db.getArticleById(params.articleContext.id) : (articles[0] || null);
    if (target) {
      toolInvocations.push({
        id: `tool-${Date.now()}`,
        toolName: 'auditArticleSEO',
        params: { id: target.id },
        status: 'running'
      });
      const auditRes = await MAGIC_TOOLS.auditArticleSEO.execute({ id: target.id });
      toolInvocations[0].status = 'completed';
      toolInvocations[0].result = auditRes;
      toolInvocations[0].diffSummary = `Audited SEO for "${target.title}". Score: ${auditRes.seoScore}/100.`;

      reply = `### SEO Audit: "${target.title}"\n\n` +
        `**Overall SEO Score**: \`${auditRes.seoScore}/100\`\n` +
        `**Focus Keyword**: "${auditRes.focusKeyword}"\n\n` +
        `**Key Findings**:\n` +
        auditRes.analysis.strengths.map((s: string) => `✅ ${s}`).join('\n') + '\n' +
        auditRes.analysis.warnings.map((w: string) => `⚠️ ${w}`).join('\n') + '\n\n' +
        `**Recommendations**:\n` +
        auditRes.analysis.recommendations.map((r: string) => `👉 ${r}`).join('\n');
    } else {
      reply = 'No articles found in the database to audit.';
    }
  } else if (promptLower.includes('humanize') || promptLower.includes('cut fluff')) {
    const textToHumanize = params.articleContext?.content || params.userPrompt;
    toolInvocations.push({
      id: `tool-${Date.now()}`,
      toolName: 'humanizeText',
      params: { text: textToHumanize.slice(0, 100) },
      status: 'running'
    });
    const hRes = await MAGIC_TOOLS.humanizeText.execute({ text: textToHumanize });
    toolInvocations[0].status = 'completed';
    toolInvocations[0].result = hRes;
    toolInvocations[0].diffSummary = `Stripped ${hRes.wordsReduced || 0} filler words. Applied ${hRes.diffNotes.length} editorial edits.`;

    reply = `### Editorial Humanizer Complete\n\n` +
      `I processed the text using our strict editorial humanizer constitution:\n\n` +
      `**Applied Revisions**:\n` +
      hRes.diffNotes.map((n: string) => `- ${n}`).join('\n') + '\n\n' +
      `**Words Reduced**: ${hRes.wordsReduced || 0} filler tokens eliminated.\n\n` +
      `> *Humanized sample:*\n> ${hRes.humanized.slice(0, 300)}...`;
  } else if (promptLower.includes('publish')) {
    const targetDraft = drafts[0] || articles[0];
    if (targetDraft) {
      plannedAction = {
        type: 'publish_article',
        dangerous: true,
        requiresConfirmation: true,
        summary: `Publish article: "${targetDraft.title}"`,
        payload: { id: targetDraft.id }
      };
      toolInvocations.push({
        id: `tool-${Date.now()}`,
        toolName: 'publishArticle',
        params: { id: targetDraft.id },
        status: 'waiting_approval',
        dangerous: true,
        diffSummary: `Requires approval to promote draft "${targetDraft.title}" to public blog.`
      });
      reply = `I have staged the publication of **"${targetDraft.title}"**.\n\n` +
        `⚠️ **Safety Gate**: Direct publishing modifies the live public blog. Please confirm using the action card below.`;
    } else {
      reply = 'No draft articles currently available to publish.';
    }
  } else if (promptLower.includes('test ai') || promptLower.includes('test provider') || promptLower.includes('latency')) {
    const providers = db.getAIProviders();
    const targetProv = providers[0];
    toolInvocations.push({
      id: `tool-${Date.now()}`,
      toolName: 'testAIProvider',
      params: { providerId: targetProv.id },
      status: 'running'
    });
    const testRes = await MAGIC_TOOLS.testAIProvider.execute({ providerId: targetProv.id });
    toolInvocations[0].status = testRes.success ? 'completed' : 'failed';
    toolInvocations[0].result = testRes;
    toolInvocations[0].diffSummary = testRes.success
      ? `Latency: ${testRes.latencyMs}ms on model ${testRes.model}`
      : `Test failed: ${testRes.error}`;

    reply = `### AI Provider Diagnostic\n\n` +
      `- **Provider**: ${targetProv.name}\n` +
      `- **Model**: \`${testRes.model}\`\n` +
      `- **Status**: ${testRes.success ? '🟢 Connected' : '🔴 Failed'}\n` +
      `- **Latency**: \`${testRes.latencyMs}ms\`\n` +
      (testRes.error ? `\n> Error: ${testRes.error}` : '');
  } else {
    reply = `### The Continental Pitch — CMS Operating Status\n\n` +
      `- **Publication**: *${db.getSettings().siteName}*\n` +
      `- **Published Articles**: **${published.length}** live on public blog\n` +
      `- **Editorial Drafts**: **${drafts.length}** in queue\n` +
      `- **Coverage Desks**: ${categories.map(c => `\`${c.name}\``).join(', ')}\n` +
      `- **Strategic Topics**: ${topics.map(t => t.name).join(', ')}\n\n` +
      `How can I assist? I can execute **live SEO audits**, **editorial humanizing**, **keyword research**, **internal linking**, or **provider diagnostics**.`;
  }

  db.logAgentActivity({
    agent: 'MAGIC',
    action: 'ASSISTANT_QUERY',
    targetType: 'cms',
    details: params.userPrompt.slice(0, 150),
    status: plannedAction?.requiresConfirmation ? 'WAITING_APPROVAL' : 'SUCCESS'
  });

  return {
    reply,
    toolInvocations,
    plannedAction
  };
}

// --- Helpers & Fallbacks ---

function getFallbackTitles(focusKeyword: string, topic: string): TitleCandidate[] {
  const kwCap = focusKeyword.charAt(0).toUpperCase() + focusKeyword.slice(1);
  return [
    {
      title: `${kwCap}: Inside the Tactical Blueprint Deciding European Knockout Ties`,
      aiSeoScore: 95,
      keywordRelevance: 'High',
      keywordPlacement: 'Front-loaded',
      searchIntent: 'Informational',
      ctrPotential: 'High',
      readability: 'Grade 9',
      charCount: 71,
      wordCount: 10,
      clickbaitWarning: false,
      explanation: 'Front-loads primary focus keyword with high-credibility tactical investigative framing.'
    },
    {
      title: `The Tactical Anatomy of ${kwCap}: Positional Play and Pitch Forensics`,
      aiSeoScore: 92,
      keywordRelevance: 'High',
      keywordPlacement: 'Middle',
      searchIntent: 'Informational',
      ctrPotential: 'High',
      readability: 'Grade 8',
      charCount: 72,
      wordCount: 10,
      clickbaitWarning: false,
      explanation: 'Appeals directly to tactical purists, coaches, and analytical football followers.'
    },
    {
      title: `Why ${kwCap} Became Modern Football's Decisive Battleground`,
      aiSeoScore: 90,
      keywordRelevance: 'High',
      keywordPlacement: 'Front-loaded',
      searchIntent: 'Informational',
      ctrPotential: 'Medium',
      readability: 'Grade 9',
      charCount: 65,
      wordCount: 8,
      clickbaitWarning: false,
      explanation: 'Direct thesis structure with strong editorial voice.'
    },
    {
      title: `Deconstructing ${kwCap}: Statistical Models, Rest Defense, and Real-World Impact`,
      aiSeoScore: 93,
      keywordRelevance: 'High',
      keywordPlacement: 'Front-loaded',
      searchIntent: 'Informational',
      ctrPotential: 'High',
      readability: 'Grade 9',
      charCount: 79,
      wordCount: 10,
      clickbaitWarning: false,
      explanation: 'Combines data analytics with structural tactical terminology.'
    },
    {
      title: `${kwCap} Explained: Strategic Imperatives for Modern Sporting Directors`,
      aiSeoScore: 89,
      keywordRelevance: 'Medium',
      keywordPlacement: 'Front-loaded',
      searchIntent: 'Commercial',
      ctrPotential: 'Medium',
      readability: 'Grade 10',
      charCount: 73,
      wordCount: 9,
      clickbaitWarning: false,
      explanation: 'Focuses on governance, squad building, and executive decision-making.'
    }
  ];
}

function getFallbackArticle(params: {
  title: string;
  focusKeyword: string;
  secondaryKeywords: string[];
  topic: string;
  categoryName: string;
  tonePrompt?: string;
}): any {
  const kw = params.focusKeyword;
  const slug = generateSlug(params.title);

  return {
    content: `
      <p>In modern European football, mastery over <strong>${kw}</strong> defines the razor-thin margin between continental triumph and domestic disappointment. As pressing schemes grow increasingly synchronized and low blocks more mathematically disciplined, managers must design systems capable of extracting numerical superiority in central zones.</p>

      <h2>The Structural Role of ${kw} in Knockout Football</h2>
      <p>Rather than treating tactical adjustments as isolated matchday gambits, elite European coaching staffs approach pitch geometry as an interconnected spatial matrix. When attacking against compact defensive lines, the imperative is not reckless territorial expansion, but the coordinated manipulation of defensive reference points.</p>

      <blockquote>
        "Possession without positional pinning is merely cosmetic. True tactical dominance lies in forcing the opponent's defensive line to make impossible structural choices."
      </blockquote>

      <h2>Positional Mechanics and Rest Defense Protocols</h2>
      <p>To establish durable control while insulating the backline against rapid transition threats, modern setups prioritize three core operational tenets:</p>

      <ul>
        <li><strong>Dual-Pivot Rest Defense:</strong> Stationing two central protectors at the base to immediately extinguish counter-attacks before momentum accelerates.</li>
        <li><strong>Half-Space Occupation:</strong> Positioning interior creators directly in the gaps between the opponent's wide defenders and central pivots.</li>
        <li><strong>Asymmetric Flank Width:</strong> Keeping wingers high and wide to stretch horizontal gaps in the opposing back five.</li>
      </ul>

      <h2>Analytical Outlook and Key Conclusions</h2>
      <p>As competition intensifies across domestic title races and European knockout stages, clubs that integrate <strong>${kw}</strong> into their core tactical identity will retain a decisive structural advantage.</p>
    `,
    leadSummary: `A forensic tactical investigation exploring how ${kw} reshapes European football through positional play geometry, rest defense protocols, and central space manipulation.`,
    excerpt: `Discover how elite European managers leverage ${kw} to unlock stubborn low blocks and secure tournament knockout ties.`,
    seoTitle: `${params.title.slice(0, 55)} | The Continental Pitch`,
    metaDescription: `Master ${kw} with our authoritative tactical analysis covering positional play, box midfields, pressing structures, and rest defense forensics.`,
    slug,
    tags: [params.categoryName, 'Tactical Analysis', 'Champions League', 'Positional Play'],
    featuredImageAlt: `${params.title} - Tactical analysis and match forensics`
  };
}


function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
