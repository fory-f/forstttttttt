import Parser from 'rss-parser';
import { db, RSSItem } from './db.js';

const parser = new Parser({
  timeout: 10000,
  headers: {
    'User-Agent': 'EditorialPulse-ContentBot/1.0 (+https://editorialpulse.com/bot)'
  },
  customFields: {
    item: [
      ['media:content', 'mediaContent', { keepArray: true }],
      ['enclosure', 'enclosure'],
      ['content:encoded', 'contentEncoded']
    ]
  }
});

export interface FetchResult {
  sourceId: string;
  sourceName: string;
  totalFound: number;
  newItemsAdded: number;
  error?: string;
}

export async function validateAndTestFeed(feedUrl: string): Promise<{ valid: boolean; title?: string; description?: string; itemCount?: number; error?: string }> {
  try {
    const feed = await parser.parseURL(feedUrl);
    return {
      valid: true,
      title: feed.title || 'Untitled Feed',
      description: feed.description || '',
      itemCount: feed.items ? feed.items.length : 0
    };
  } catch (err: any) {
    return {
      valid: false,
      error: err.message || 'Unable to parse RSS or Atom feed.'
    };
  }
}

export async function fetchSource(sourceId: string): Promise<FetchResult> {
  const source = db.getRSSSources().find(s => s.id === sourceId);
  if (!source) {
    return { sourceId, sourceName: 'Unknown', totalFound: 0, newItemsAdded: 0, error: 'Source not found' };
  }

  try {
    const feed = await parser.parseURL(source.url);
    const rawItems = feed.items || [];
    const formattedItems: Array<Omit<RSSItem, 'id' | 'importedAt' | 'status'>> = [];

    for (const item of rawItems) {
      if (!item.title || !item.link) continue;

      // Extract image if available
      let imageUrl: string | undefined;
      if (item.enclosure && item.enclosure.url && item.enclosure.type?.startsWith('image/')) {
        imageUrl = item.enclosure.url;
      } else if ((item as any).mediaContent && Array.isArray((item as any).mediaContent)) {
        const first = (item as any).mediaContent[0];
        if (first && first.$ && first.$.url) {
          imageUrl = first.$.url;
        }
      }

      // If no image, select a high-quality thematic stock photo based on category
      if (!imageUrl) {
        imageUrl = 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&fit=crop&q=80';
      }

      const cleanSummary = (item.contentSnippet || item.summary || item.content || '').slice(0, 400);

      formattedItems.push({
        sourceId: source.id,
        sourceName: source.name,
        originalTitle: item.title.trim(),
        originalUrl: item.link.trim(),
        originalAuthor: item.creator || (item as any).author || source.websiteName,
        publicationDate: item.isoDate || item.pubDate || new Date().toISOString(),
        description: cleanSummary,
        content: (item as any).contentEncoded || item.content || cleanSummary,
        originalImage: imageUrl
      });
    }

    const added = db.addRSSItems(formattedItems);

    db.saveRSSSource({
      id: source.id,
      name: source.name,
      url: source.url,
      lastFetchedAt: new Date().toISOString(),
      itemCount: (source.itemCount || 0) + added,
      lastError: undefined
    });

    return {
      sourceId: source.id,
      sourceName: source.name,
      totalFound: rawItems.length,
      newItemsAdded: added
    };
  } catch (err: any) {
    const errMsg = err.message || 'Error fetching feed';
    db.saveRSSSource({
      id: source.id,
      name: source.name,
      url: source.url,
      lastError: errMsg
    });
    return {
      sourceId: source.id,
      sourceName: source.name,
      totalFound: 0,
      newItemsAdded: 0,
      error: errMsg
    };
  }
}

export async function fetchAllActiveSources(): Promise<FetchResult[]> {
  const sources = db.getRSSSources().filter(s => s.enabled);
  const results: FetchResult[] = [];

  for (const src of sources) {
    const res = await fetchSource(src.id);
    results.push(res);
  }

  return results;
}
