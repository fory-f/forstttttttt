import fs from 'fs';
import path from 'path';
import {
  User,
  AuthorProfile,
  Category,
  Tag,
  ArticleRevision,
  Article,
  RSSSource,
  RSSItem,
  Topic,
  EditorialTone,
  AIInstruction,
  PromptTemplate,
  MediaItem,
  MemoryItem,
  ProjectContext,
  AutomationRule,
  AIPermission,
  AgentActivityLog,
  AIUsageLog,
  SiteSettings,
  AIProviderConfig,
  AITaskRouting,
  ResearchSourceItem,
  WorkflowDraftState
} from '../types.js';
import { DEFAULT_AI_PROVIDERS, DEFAULT_TASK_ROUTING } from './ai-providers.js';

export type {
  User,
  AuthorProfile,
  Category,
  Tag,
  ArticleRevision,
  Article,
  RSSSource,
  RSSItem,
  Topic,
  EditorialTone,
  AIInstruction,
  PromptTemplate,
  MediaItem,
  MemoryItem,
  ProjectContext,
  AutomationRule,
  AIPermission,
  AgentActivityLog,
  AIUsageLog,
  SiteSettings,
  AIProviderConfig,
  AITaskRouting,
  ResearchSourceItem,
  WorkflowDraftState
};

// Complete Database Schema
export interface DatabaseSchema {
  users: User[];
  categories: Category[];
  tags: Tag[];
  articles: Article[];
  articleRevisions: ArticleRevision[];
  rssSources: RSSSource[];
  rssItems: RSSItem[];
  topics: Topic[];
  editorialTones: EditorialTone[];
  aiInstructions: AIInstruction[];
  promptTemplates: PromptTemplate[];
  media: MediaItem[];
  memoryItems: MemoryItem[];
  automationRules: AutomationRule[];
  aiPermissions: AIPermission[];
  agentActivityLogs: AgentActivityLog[];
  aiUsageLogs: AIUsageLog[];
  settings: SiteSettings;
  aiProviders: AIProviderConfig[];
  aiTaskRouting: AITaskRouting;
  researchSources: ResearchSourceItem[];
  workflowDraft: WorkflowDraftState | null;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// --- Football & Sports Editorial Default Seed Data ---

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'The Continental Pitch',
  siteUrl: process.env.APP_URL || 'http://localhost:3000',
  tagline: 'European Football Intelligence, Tactical Forensics & Financial Governance',
  siteDescription: 'Rigorously investigated reporting covering UEFA Champions League tactical innovations, Premier League governance, European transfer market forensics, and high-level football data analytics.',
  logoUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&h=120&fit=crop&q=80',
  faviconUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=32&h=32&fit=crop&q=80',
  defaultLanguage: 'en',
  googleAnalyticsId: '',
  googleSearchConsoleTag: '',
  publishMode: 'manual',
  activeAiModel: 'gemini-3.8-flash',
  aiTemperature: 0.7,
  authorProfile: {
    name: 'Marcus Sterling',
    slug: 'marcus-sterling',
    shortBio: 'Senior European Football Correspondent & Tactical Forensics Editor with 12+ years analyzing UEFA tournaments, Premier League governance, and player scouting metrics.',
    fullBio: 'Marcus Sterling is the Senior Tactical Correspondent and Editor-in-Chief of The Continental Pitch. A veteran of UEFA Champions League press boxes and European sports desks, his investigative writing focuses on the intersection of positional play, financial regulation (PSR & FFP), and recruitment data architecture.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&q=80',
    website: 'https://continentalpitch.com',
    socialTwitter: 'https://x.com/marcussterling',
    socialLinkedin: 'https://linkedin.com/in/marcussterling',
    socialGithub: '',
    expertise: ['Champions League Tactics', 'Positional Play', 'Premier League Governance', 'PSR & Financial Fair Play', 'Recruitment Analytics (xG, OBV)'],
    credentials: 'UEFA Pro Tactical Observer, Former Sports Editor at European Football Review',
    organization: 'Continental Pitch Media Group'
  },
  projectContext: {
    websiteName: 'The Continental Pitch',
    websiteDescription: 'Authority publication on European and global football intelligence, Champions League tactics, Premier League financial sustainability, and transfer forensics.',
    niche: 'Football Intelligence, Tactical Analysis & Sports Governance',
    targetAudience: 'Football analysts, sports editors, club executives, tactical purists, and European league followers.',
    countries: ['United Kingdom', 'Germany', 'Spain', 'Italy', 'France', 'Global'],
    languages: ['English'],
    mainKeywords: ['football tactical analysis', 'Champions League tactics', 'Premier League PSR rules', 'midfield overloads in football', 'football data analytics scouting'],
    brandVoice: 'Authoritative, sharp, analytical, measured, and deeply grounded in football reality. We reject sensational transfer gossip and superficial match recaps in favor of forensic tactical breakdowns and financial governance insight.',
    editorialRules: [
      'Prioritize verifiable club accounts, official UEFA regulations, and tactical match tape.',
      'Never fabricate transfer rumours, player quotes, or agent leaks.',
      'Balance statistical models (xG, field tilt, PPDA) with contextual on-pitch realities.',
      'Write natural, compelling prose without artificial keyword stuffing or robotic AI transitions.'
    ],
    contentRules: [
      'Every article must feature a single distinct H1 and clear semantic H2/H3 subdivisions.',
      'Lead summaries must deliver the analytical thesis within the first two sentences.',
      'Include tactical diagrams, positional references, and contextual links to relevant league desks.'
    ],
    seoRules: [
      'Primary focus keyword placed naturally in H1, first 100 words, and meta description.',
      'Descriptive URL slugs free of dates or stop-words.',
      'Authentic JSON-LD Article and BreadcrumbList structured data matching on-page content.'
    ],
    internalLinkingRules: [
      'Contextually cross-reference related tactical breakdowns, club financial audits, and tournament hubs.',
      'Use natural, entity-based anchor text rather than generic phrasing.'
    ],
    avoidTerms: ['game-changer', 'revolutionize', 'dive into', 'in today\'s fast-paced football world', 'delve', 'testament to', 'vibrant tapestry', 'it goes without saying'],
    preferredTerminology: ['rest defense', 'half-space overload', 'box midfield', 'squad cost ratio', 'field tilt', 'progressive actions']
  }
};

const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'cat-1',
    name: 'Champions League',
    slug: 'champions-league',
    description: 'European knockout forensics, tournament dynamics, tactical adjustments, and continental match previews.',
    seoTitle: 'Champions League Tactical Analysis & European Dispatches | The Continental Pitch',
    seoDescription: 'In-depth tactical breakdowns, managerial chess matches, and knockout forensics from the UEFA Champions League.',
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&fit=crop&q=80',
    createdAt: '2026-01-10T10:00:00Z',
    isIndexable: true
  },
  {
    id: 'cat-2',
    name: 'Premier League',
    slug: 'premier-league',
    description: 'Tactical evolution, title race metrics, managerial philosophies, and matchday investigations across English football.',
    seoTitle: 'Premier League Tactical Analysis & Matchday Forensics | The Continental Pitch',
    seoDescription: 'Authoritative analysis of Premier League matches, positional systems, pressing intensity, and managerial strategies.',
    imageUrl: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=800&fit=crop&q=80',
    createdAt: '2026-01-12T10:00:00Z',
    isIndexable: true
  },
  {
    id: 'cat-3',
    name: 'Tactical Analysis',
    slug: 'tactical-analysis',
    description: 'Positional play blueprints, pressing structures, set-piece routines, and spatial manipulation on the pitch.',
    seoTitle: 'Football Tactical Analysis & Positional Play Breakdowns | The Continental Pitch',
    seoDescription: 'Master modern football tactics: inverted full-backs, box midfields, pressing triggers, and low-block solutions.',
    imageUrl: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&fit=crop&q=80',
    createdAt: '2026-01-15T10:00:00Z',
    isIndexable: true
  },
  {
    id: 'cat-4',
    name: 'Transfers & Finance',
    slug: 'transfers-finance',
    description: 'Profitability and Sustainability Rules (PSR), UEFA financial regulations, amortized accounting, and scouting intelligence.',
    seoTitle: 'Football Transfer Finance & PSR Governance Audits | The Continental Pitch',
    seoDescription: 'Investigating football business: squad cost ratios, amortization rules, academy accounting, and transfer market economics.',
    imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&fit=crop&q=80',
    createdAt: '2026-01-18T10:00:00Z',
    isIndexable: true
  },
  {
    id: 'cat-5',
    name: 'Continental Leagues',
    slug: 'continental-leagues',
    description: 'Tactical trends, title races, and club profiles from La Liga, Serie A, the Bundesliga, and Ligue 1.',
    seoTitle: 'Continental Football: La Liga, Serie A & Bundesliga Analysis | The Continental Pitch',
    seoDescription: 'Detailed coverage of European domestic leagues, managerial innovations, and continental football narratives.',
    imageUrl: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=800&fit=crop&q=80',
    createdAt: '2026-01-20T10:00:00Z',
    isIndexable: true
  }
];

const DEFAULT_TAGS: Tag[] = [
  { id: 'tag-1', name: 'Champions League', slug: 'champions-league', createdAt: '2026-01-10T10:00:00Z', description: 'UEFA tournament dispatches' },
  { id: 'tag-2', name: 'Premier League', slug: 'premier-league', createdAt: '2026-01-10T10:00:00Z', description: 'Top-flight English football' },
  { id: 'tag-3', name: 'Tactical Analysis', slug: 'tactical-analysis', createdAt: '2026-01-10T10:00:00Z', description: 'Deep on-pitch tactical breakdowns' },
  { id: 'tag-4', name: 'Financial Fair Play', slug: 'financial-fair-play', createdAt: '2026-01-10T10:00:00Z', description: 'Club finance and regulatory frameworks' },
  { id: 'tag-5', name: 'Pressing Structures', slug: 'pressing-structures', createdAt: '2026-01-10T10:00:00Z', description: 'High-press triggers and counter-pressing' },
  { id: 'tag-6', name: 'xG & Analytics', slug: 'xg-analytics', createdAt: '2026-01-10T10:00:00Z', description: 'Data models and expected metrics' },
  { id: 'tag-7', name: 'Real Madrid', slug: 'real-madrid', createdAt: '2026-01-10T10:00:00Z', description: 'Spanish champions coverage' },
  { id: 'tag-8', name: 'Manchester City', slug: 'manchester-city', createdAt: '2026-01-10T10:00:00Z', description: 'Positional play and title dynamics' },
  { id: 'tag-9', name: 'Arsenal', slug: 'arsenal', createdAt: '2026-01-10T10:00:00Z', description: 'Arteta tactical structures' },
  { id: 'tag-10', name: 'Bayern Munich', slug: 'bayern-munich', createdAt: '2026-01-10T10:00:00Z', description: 'Bundesliga leaders' }
];

const DEFAULT_TOPICS: Topic[] = [
  {
    id: 'top-1',
    name: 'Midfield Overloads & Rest Defense',
    description: 'How modern European contenders use 3-2-4-1 build-ups and central numerical superiority to control knockout ties.',
    keywords: ['midfield overloads in football', 'box midfield', 'rest defense', 'Champions League knockout tactics'],
    secondaryKeywords: ['3-2-4-1 build up', 'half-space occupation', 'counter-press triggers'],
    searchIntent: 'Informational',
    targetAudience: 'Football analysts, matchgoers, and tactical coaches.',
    priority: 'high',
    enabled: true,
    instructions: 'Emphasize positional manipulation, how dual pivot structures pin interior defenders, and concrete match examples.',
    autoPublishEnabled: false,
    minSeoScore: 90
  },
  {
    id: 'top-2',
    name: 'Premier League PSR & UEFA Squad Cost Rules',
    description: 'Forensic audits of three-year loss limits, player amortization caps, and transfer market restrictions.',
    keywords: ['Premier League PSR rules', 'financial fair play football', 'transfer amortization accounting', 'squad cost ratio'],
    secondaryKeywords: ['pure profit academy transfers', 'UEFA multi-club rules', 'deduction appeals'],
    searchIntent: 'Informational',
    targetAudience: 'Sports lawyers, football journalists, and club finance enthusiasts.',
    priority: 'high',
    enabled: true,
    instructions: 'Ground all analysis in published club financial filings and official league rulebooks.',
    autoPublishEnabled: false,
    minSeoScore: 85
  },
  {
    id: 'top-3',
    name: 'Modern Football Scouting Beyond xG',
    description: 'Evaluating advanced metrics including packing rates, field tilt, OBV (on-ball value), and progressive carries.',
    keywords: ['football data analytics scouting', 'advanced football metrics', 'packing rate football', 'on-ball value models'],
    secondaryKeywords: ['field tilt', 'passes per defensive action', 'recruitment modeling'],
    searchIntent: 'Informational',
    targetAudience: 'Data scouts, sporting directors, and analytics followers.',
    priority: 'medium',
    enabled: true,
    instructions: 'Explain statistical terms in direct, accessible football vocabulary with real scouting case studies.',
    autoPublishEnabled: false,
    minSeoScore: 85
  }
];

const DEFAULT_EDITORIAL_TONES: EditorialTone[] = [
  {
    id: 'tone-1',
    name: 'Authoritative Football Journalism',
    description: 'Sharp, disciplined, investigative prose worthy of The Athletic or Guardian Sport.',
    prompt: 'Write with journalistic clarity, tactical precision, and narrative drive. Avoid generic hype and cliché metaphors. Treat football tactics as a serious chess match influenced by spatial geometry and athletic execution.',
    isDefault: true,
    enabled: true
  },
  {
    id: 'tone-2',
    name: 'Tactical & Data-Driven Forensic',
    description: 'Rigorously analytical prose focused on pitch geometry, pressing data, and positional structures.',
    prompt: 'Adopt the tone of a high-level tactical scout and data analyst. Deconstruct phase transitions, rest defense principles, and spatial dynamics with specific pitch references.',
    isDefault: false,
    enabled: true
  },
  {
    id: 'tone-3',
    name: 'Financial & Investigative Audit',
    description: 'Objective, regulatory analysis of balance sheets, transfer accounting, and governance rules.',
    prompt: 'Maintain an objective, forensic investigative voice. Cite club filings, regulatory frameworks, amortization schedules, and commercial streams clearly.',
    isDefault: false,
    enabled: true
  }
];

const DEFAULT_RSS_SOURCES: RSSSource[] = [
  {
    id: 'rss-1',
    name: 'The Guardian Football',
    url: 'https://www.theguardian.com/football/rss',
    websiteName: 'The Guardian',
    enabled: true,
    defaultCategoryId: 'cat-2',
    defaultTags: ['Premier League', 'Tactical Analysis'],
    priority: 'high',
    fetchFrequencyMinutes: 60,
    lastFetchedAt: '2026-03-24T08:00:00Z',
    itemCount: 40,
    createdAt: '2026-01-10T10:00:00Z'
  },
  {
    id: 'rss-2',
    name: 'BBC Sport Football',
    url: 'https://feeds.bbci.co.uk/sport/football/rss.xml',
    websiteName: 'BBC Sport',
    enabled: true,
    defaultCategoryId: 'cat-1',
    defaultTags: ['Champions League', 'Premier League'],
    priority: 'high',
    fetchFrequencyMinutes: 90,
    lastFetchedAt: '2026-03-24T08:30:00Z',
    itemCount: 35,
    createdAt: '2026-01-12T10:00:00Z'
  },
  {
    id: 'rss-3',
    name: 'Sky Sports Football News',
    url: 'https://www.skysports.com/rss/12040',
    websiteName: 'Sky Sports',
    enabled: true,
    defaultCategoryId: 'cat-4',
    defaultTags: ['Transfers & Finance', 'Premier League'],
    priority: 'medium',
    fetchFrequencyMinutes: 120,
    itemCount: 28,
    createdAt: '2026-01-15T10:00:00Z'
  }
];

const DEFAULT_ARTICLES: Article[] = [
  {
    id: 'art-1',
    title: 'Champions League Tactical Evolution: How Midfield Overloads Are Dismantling Low Blocks',
    slug: 'champions-league-tactical-evolution-midfield-overloads',
    excerpt: 'Knockout football has moved beyond traditional wing play. Examine how European managers deploy fluid box midfields to unlock compact 5-4-1 defensive blocks.',
    leadSummary: 'A forensic tactical audit demonstrating why Champions League quarter-finalists increasingly rely on central 3-2-4-1 build-up geometries and half-space overloads to bypass stubborn continental low blocks.',
    content: `
      <p>European knockout football has entered a period of unprecedented tactical refinement. For decades, the conventional counter to a deep, compact defensive block was predictable: switch play quickly to the touchlines, isolate full-backs, and deliver whipped crosses into a crowded penalty box. Today, against modern low blocks drilled with millimeter precision, that formula consistently fails.</p>

      <h2>The Geometry of the 3-2-4-1 Box Midfield</h2>
      <p>When studying the remaining contenders in this season's Champions League campaign, a striking structural uniformity emerges during settled possession phases. Regardless of their nominal starting sheet—be it a 4-3-3 or a 4-2-3-1—elite managers systematically morph into an asymmetric <strong>3-2-4-1 shape</strong> in possession.</p>

      <p>By stepping an inverted full-back or an athletic centre-back into the central pivot alongside the defensive midfielder, attacking sides establish a 3-2 foundation at the base. This provides two decisive advantages:</p>

      <ul>
        <li><strong>Rest Defense Security:</strong> Two central pivots protect against direct central counters, allowing the front five to press high immediately upon turnover.</li>
        <li><strong>Numerical Superiority in the Second Line:</strong> Four players occupy the half-spaces and central channels between the opposition's midfield and defensive lines.</li>
      </ul>

      <blockquote>
        "Possession without central pinning is decorative. If you cannot place two attacking midfielders directly into the pockets behind their double pivot, their back five will never step out of comfort."
      </blockquote>

      <h2>Manipulating Defensive Reference Points</h2>
      <p>A compact 5-4-1 block relies on clear reference points: wing-backs jump to wide wingers, central defenders stay anchored in the width of the eighteen-yard box, and the midfield bank shifts laterally with the ball. The 3-2-4-1 deliberately scrambles these assignments.</p>

      <p>When the wide forwards pin the opposing wing-backs to the touchline, a massive half-space corridor opens. An interior playmaker dropping five yards into this channel forces an opposing centre-back to make a split-second calculation: track the runner into midfield and sacrifice defensive shape, or hold the line and concede a clean turn between the lines.</p>

      <h2>Conclusion: Knockout Ties Decided in the Half-Spaces</h2>
      <p>As the tournament reaches its decisive stages, the teams advancing to the final will not be those crossing with hope, but those manipulating space with mathematical precision. In the Champions League arena, the box midfield has become football's ultimate structural lockpick.</p>
    `,
    featuredImage: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&h=630&fit=crop&q=80',
    featuredImageAlt: 'Champions League stadium illuminated for knockout stage football match under floodlights',
    categoryId: 'cat-1',
    tags: ['Champions League', 'Tactical Analysis', 'Pressing Structures', 'Manchester City', 'Real Madrid'],
    primaryFocusKeyword: 'midfield overloads in football',
    secondaryKeywords: ['Champions League tactics', 'box midfield', 'rest defense', '3-2-4-1 formation'],
    seoTitle: 'Champions League Tactics: How Midfield Overloads Break Low Blocks',
    metaDescription: 'Detailed tactical breakdown of how Champions League managers use 3-2-4-1 box midfields and half-space overloads to unlock deep European low blocks.',
    canonicalUrl: '',
    authorName: 'Marcus Sterling',
    authorSlug: 'marcus-sterling',
    status: 'published',
    publishedAt: '2026-03-20T10:00:00Z',
    createdAt: '2026-03-19T14:30:00Z',
    updatedAt: '2026-03-20T10:00:00Z',
    workflowStage: 14,
    aiSeoScore: 96,
    aiSeoAnalysis: {
      score: 96,
      strengths: [
        'Primary focus keyword "midfield overloads in football" positioned in Title, H1, and first 100 words.',
        'Logical H2 structure addressing positional geometry and defensive manipulation.',
        'Actionable tactical terminology grounded in professional coaching principles.'
      ],
      warnings: [],
      recommendations: [
        'Add internal link to transfer finance overview for squad building context.'
      ],
      breakdown: {
        keywordInTitle: true,
        keywordInH1: true,
        keywordInIntro: true,
        keywordInMeta: true,
        keywordDensity: '1.5%',
        headingStructure: true,
        readabilityScore: 92,
        internalLinksCount: 3,
        wordCount: 520
      }
    }
  },
  {
    id: 'art-2',
    title: 'The Financial Fair Play Reckoning: How Profitability & Sustainability Rules Reshaped the Transfer Window',
    slug: 'financial-fair-play-psr-premier-league-transfer-window',
    excerpt: 'The era of unrestrained spending has ground to a halt. Understand the mechanics of PSR, amortization caps, and why academy player sales became modern football currency.',
    leadSummary: 'An investigative accounting audit into how Premier League PSR thresholds and UEFA squad cost ratios transformed European player trading from speculative extravagance to balance-sheet survival.',
    content: `
      <p>For more than two decades, the European transfer market operated on an inflationary spiral that defied basic corporate economics. Record transfer fees were celebrated as statements of ambition, while operating losses were routinely subsidized by billionaire owners. In 2026, that era is definitively over.</p>

      <h2>The Three-Year Rolling Window Explained</h2>
      <p>At the center of English football's financial transformation are the Premier League's <strong>Profitability and Sustainability Rules (PSR)</strong>. Under the current regulatory framework, clubs are permitted maximum allowable losses of £105 million over a three-year monitoring period—or just £15 million if owner equity injections do not cover the shortfall.</p>

      <p>Crucially, certain operational expenditures are excluded from PSR calculations:</p>
      <ul>
        <li>Infrastructure investment and stadium modernizations</li>
        <li>Women's football development and youth academy operational budgets</li>
        <li>Community and charitable foundations</li>
      </ul>

      <p>However, core footballing costs—namely first-team wages, agent commissions, and player registration amortization—count in full against the threshold.</p>

      <h2>The Amortization Paradox and the 'Pure Profit' Strategy</h2>
      <p>When a club buys a player for £80 million on a five-year contract, the entire fee is not booked immediately in that fiscal year. Instead, it is <em>amortized</em> at £16 million annually across the length of the deal. In contrast, when a club sells an academy graduate for £35 million, the entire sum is recorded as immediate <strong>pure profit</strong>, because the player carries zero book value on the balance sheet.</p>

      <blockquote>
        "The accounting rules have perversely made homegrown academy stars the most liquid, expendable financial assets at top clubs."
      </blockquote>

      <h2>UEFA's Squad Cost Rule: The New European Benchmark</h2>
      <p>Parallel to domestic regulations, UEFA has phased in its strict <em>Squad Cost Rule</em>, which caps spending on player and coach wages, transfers (amortization), and agent fees at <strong>70% of total club revenue</strong>. Clubs breaching this ceiling face escalating financial penalties, luxury taxes, and squad registration restrictions in the Champions League.</p>

      <h2>The Strategic Outlook</h2>
      <p>As regulatory scrutiny intensifies, modern sporting directors must be as fluent in amortized balance sheets as they are in tactical scouting. The clubs dominating the next decade will be those that master sustainable wage structures, youth recruitment, and data-driven player valuation.</p>
    `,
    featuredImage: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=1200&h=630&fit=crop&q=80',
    featuredImageAlt: 'Football stadium financial ledger and transfer window contracts on executive boardroom desk',
    categoryId: 'cat-4',
    tags: ['Transfers & Finance', 'Financial Fair Play', 'Premier League', 'Champions League'],
    primaryFocusKeyword: 'Premier League PSR rules',
    secondaryKeywords: ['financial fair play football', 'transfer amortization accounting', 'squad cost ratio', 'academy pure profit'],
    seoTitle: 'Premier League PSR Rules: How FFP Reshaped Football Transfers',
    metaDescription: 'Complete investigative audit of Premier League PSR rules, UEFA squad cost ratios, player amortization, and the financial mechanics of modern transfer windows.',
    canonicalUrl: '',
    authorName: 'Marcus Sterling',
    authorSlug: 'marcus-sterling',
    status: 'published',
    publishedAt: '2026-03-22T09:00:00Z',
    createdAt: '2026-03-21T11:00:00Z',
    updatedAt: '2026-03-22T09:00:00Z',
    workflowStage: 14,
    aiSeoScore: 94,
    aiSeoAnalysis: {
      score: 94,
      strengths: [
        'Primary focus keyword "Premier League PSR rules" featured in H1 and opening analysis.',
        'Accurate breakdown of £105m threshold, amortization calculations, and UEFA 70% cap.',
        'Zero corporate fluff; crisp financial journalism.'
      ],
      warnings: [],
      recommendations: [],
      breakdown: {
        keywordInTitle: true,
        keywordInH1: true,
        keywordInIntro: true,
        keywordInMeta: true,
        keywordDensity: '1.4%',
        headingStructure: true,
        readabilityScore: 90,
        internalLinksCount: 2,
        wordCount: 510
      }
    }
  },
  {
    id: 'art-3',
    title: 'Inside the Data Revolution in Modern Football Scouting: Beyond Expected Goals (xG)',
    slug: 'modern-football-scouting-data-analytics-beyond-xg',
    excerpt: 'Expected goals changed how fans view matches, but elite recruitment departments moved on years ago. Discover how OBV, field tilt, and packing metrics drive multi-million pound transfers.',
    leadSummary: 'An insider look into modern European football scouting departments, revealing the advanced spatial models, possession value metrics, and tracking data revolutionizing player valuation.',
    content: `
      <p>A decade ago, the introduction of Expected Goals (xG) created a fault line in football discourse. Traditionalists dismissed it as computer jargon; modernists championed it as objective truth. Today, xG is merely table stakes. In the recruitment war rooms of Europe's top clubs, performance analysts have advanced to far more nuanced predictive models.</p>

      <h2>The Limits of Shot-Centric Models</h2>
      <p>While xG effectively evaluates shot location, angle, and assist quality, it possesses a fundamental limitation: it only records actions that culminate in an attempt on goal. A central midfielder who breaks two defensive lines with a 40-yard diagonal pass receives zero xG credit if the ensuing winger loses the ball before shooting.</p>

      <h2>On-Ball Value (OBV) and Possession Progression</h2>
      <p>To quantify every touch across ninety minutes, premier analytical departments employ <strong>On-Ball Value (OBV)</strong> frameworks. These machine-learning models assign a statistical probability of a goal being scored or conceded before and after every individual action on the pitch:</p>

      <ul>
        <li><strong>Line-Breaking Passes:</strong> Rewarding players who eliminate three or more defenders with vertical penetration.</li>
        <li><strong>Progressive Carries under Pressure:</strong> Measuring how many meters a ball-carrier advances territory while resisting contact.</li>
        <li><strong>Defensive Duel Win Rates in Transition:</strong> Evaluating the preservation of defensive structure during turnover moments.</li>
      </ul>

      <h2>Field Tilt and Territory Domination</h2>
      <p>Another metric transforming match preparation is <em>Field Tilt</em>—the percentage of final-third passes made by a team compared to their opponent. While basic possession statistics can be padded through harmless circulation between centre-backs, Field Tilt reveals true territorial dominance and attacking pressure.</p>

      <h2>Bridging the Analytics and Scouting Divide</h2>
      <p>The most successful sporting structures do not replace traditional scouts with algorithms. Instead, data filters thousands of global players down to a targeted shortlist of thirty, at which point experienced scouts evaluate character, tactical flexibility, and physical biomechanics. In 2026, data doesn't make the signing; data makes sure you scout the right player first.</p>
    `,
    featuredImage: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1200&h=630&fit=crop&q=80',
    featuredImageAlt: 'Tactical scouting tablet showing heatmaps, passing vectors, and player recruitment metrics',
    categoryId: 'cat-3',
    tags: ['Tactical Analysis', 'xG & Analytics', 'Transfers & Finance', 'Premier League'],
    primaryFocusKeyword: 'football data analytics scouting',
    secondaryKeywords: ['advanced football metrics', 'on-ball value OBV', 'field tilt football', 'packing rate'],
    seoTitle: 'Football Data Analytics Scouting: Beyond Expected Goals (xG)',
    metaDescription: 'Explore how elite football recruitment departments use On-Ball Value (OBV), field tilt, and packing rates to scout and evaluate transfer targets beyond xG.',
    canonicalUrl: '',
    authorName: 'Marcus Sterling',
    authorSlug: 'marcus-sterling',
    status: 'published',
    publishedAt: '2026-03-23T08:00:00Z',
    createdAt: '2026-03-22T16:00:00Z',
    updatedAt: '2026-03-23T08:00:00Z',
    workflowStage: 14,
    aiSeoScore: 95,
    aiSeoAnalysis: {
      score: 95,
      strengths: [
        'Primary focus keyword "football data analytics scouting" seamlessly integrated.',
        'Clear distinction between shot-based xG and spatial OBV models.',
        'High readability with strong heading hierarchy and concrete examples.'
      ],
      warnings: [],
      recommendations: [],
      breakdown: {
        keywordInTitle: true,
        keywordInH1: true,
        keywordInIntro: true,
        keywordInMeta: true,
        keywordDensity: '1.3%',
        headingStructure: true,
        readabilityScore: 91,
        internalLinksCount: 3,
        wordCount: 490
      }
    }
  },
  {
    id: 'art-4',
    title: 'The Art of the Inverted Full-Back: How Positional Play Transformed European Domestics',
    slug: 'art-of-inverted-fullback-pitch-geometry',
    excerpt: 'Full-backs used to hug the chalk; today they dictate matches from central midfield. Trace the evolution of Pep Guardiola and Mikel Arteta\'s tactical revolution.',
    leadSummary: 'A comprehensive tactical study examining how the inverted full-back redefined modern pitch geometry, stabilized rest defense against counter-attacks, and created dual-phase playmakers.',
    content: `
      <p>For roughly a century, the full-back's remit was straightforward: protect the defensive channel against opposition wingers, and when possession allowed, overlap down the flank to supply crosses into the penalty area. Today, across the Premier League, La Liga, and the Bundesliga, the most influential full-backs rarely touch the byline.</p>

      <h2>The Dual Purpose: Overloads and Rest Defense</h2>
      <p>The move toward inverted full-backs—pioneered at scale by Pep Guardiola and refined by Mikel Arteta and Roberto De Zerbi—was born not from tactical vanity, but from a pragmatic necessity: solving the counter-attacking threat posed by rapid transition wingers.</p>

      <p>When an attacking full-back charges forty yards forward down the flank, they leave a cavernous void behind them. If possession is turned over, the opposing winger can exploit thirty yards of open green grass. By tucking inside as an auxiliary central midfielder instead, the inverted full-back achieves two simultaneous tactical objectives:</p>

      <ul>
        <li><strong>Immediate Counter-Pressing Base:</strong> Positioned in the central corridor, they are already on hand to snuff out clearance passes before the transition gains momentum.</li>
        <li><strong>Midfield Overload:</strong> Creating a numerical 3v2 or 4v3 in the central third, providing clean passing angles to bypass aggressive first-line pressing.</li>
      </ul>

      <h2>The Asymmetric Flank: Wingers Holding Touchline Width</h2>
      <p>When full-backs move inside, how does the attacking team preserve pitch width? The answer lies in asymmetric winger positioning. Rather than cutting inside on their stronger foot into traffic, wide forwards are instructed to keep their boots on the chalk, pinning the opposing full-back and creating massive intermediate gaps in the half-space.</p>

      <h2>Future Iterations: The Centrally Roaming Defender</h2>
      <p>As opposition coaches adapt by deploying aggressive man-oriented pressing triggers onto inverted full-backs, the tactical battleground continues to shift. Modern defenders are now expected to be press-resistant under duress, capable of receiving on the half-turn with their back to goal.</p>
    `,
    featuredImage: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&h=630&fit=crop&q=80',
    featuredImageAlt: 'Tactical whiteboard with player magnets illustrating inverted full-back movements and pitch geometry',
    categoryId: 'cat-2',
    tags: ['Premier League', 'Tactical Analysis', 'Pressing Structures', 'Arsenal', 'Manchester City'],
    primaryFocusKeyword: 'inverted fullback tactics',
    secondaryKeywords: ['positional play football', 'Pep Guardiola tactics', 'rest defense', 'pitch geometry'],
    seoTitle: 'Inverted Full-Back Tactics: Positional Play in Modern Football',
    metaDescription: 'Tactical study of inverted full-back tactics in modern European football: how Guardiola and Arteta use full-backs in midfield to secure rest defense.',
    canonicalUrl: '',
    authorName: 'Marcus Sterling',
    authorSlug: 'marcus-sterling',
    status: 'published',
    publishedAt: '2026-03-24T07:30:00Z',
    createdAt: '2026-03-23T19:00:00Z',
    updatedAt: '2026-03-24T07:30:00Z',
    workflowStage: 14,
    aiSeoScore: 93,
    aiSeoAnalysis: {
      score: 93,
      strengths: [
        'Primary focus keyword "inverted fullback tactics" featured in H1 and intro.',
        'Clear breakdown of rest defense mechanics and half-space dynamics.',
        'Strong editorial rhythm and natural tactical clarity.'
      ],
      warnings: [],
      recommendations: [],
      breakdown: {
        keywordInTitle: true,
        keywordInH1: true,
        keywordInIntro: true,
        keywordInMeta: true,
        keywordDensity: '1.4%',
        headingStructure: true,
        readabilityScore: 89,
        internalLinksCount: 2,
        wordCount: 460
      }
    }
  }
];

const DEFAULT_MEMORY_ITEMS: MemoryItem[] = [
  {
    id: 'mem-1',
    title: 'The Continental Pitch Editorial Constitution',
    type: 'guideline',
    content: 'We write with analytical rigour, factual precision, and journalistic integrity. We avoid cliché phrases ("game-changer", "delve", "in today\'s fast-paced world"). Every tactical claim must reference on-pitch spatial mechanics (3-2-4-1 build-ups, rest defense, half-space occupation, field tilt). Every financial article must reference published club accounts, PSR loss limits, or UEFA squad cost ratio metrics.',
    tags: ['Constitution', 'Guidelines', 'Style'],
    lastUpdated: '2026-03-20T10:00:00Z'
  },
  {
    id: 'mem-2',
    title: 'UEFA Financial Fair Play & Premier League PSR Rules Reference',
    type: 'research',
    content: 'Premier League PSR allows maximum £105m losses across 3 rolling fiscal years (£35m/year) if backed by owner equity. Deductions occur for breaches above this limit. UEFA squad cost ratio imposes a 70% revenue cap on first-team wages, agent fees, and amortized transfer fees. Academy player sales count as 100% pure profit on the year of disposal.',
    tags: ['FFP', 'PSR', 'Finance', 'UEFA'],
    lastUpdated: '2026-03-22T09:00:00Z'
  }
];

const DEFAULT_AUTOMATION_RULES: AutomationRule[] = [
  {
    id: 'rule-1',
    name: 'Knockout Stage Quality Gate',
    enabled: true,
    mode: 'manual',
    minAiSeoScore: 88,
    requireFeaturedImage: true,
    requireMetaDescription: true,
    requireFocusKeywordInTitle: true,
    requireTagsCount: 2,
    allowedCategories: ['cat-1', 'cat-2', 'cat-3', 'cat-4']
  }
];

const DEFAULT_PERMISSIONS: AIPermission[] = [
  { id: 'perm-1', key: 'create_drafts', name: 'Create Article Drafts', description: 'Allow AI agent to formulate and save draft articles', allowed: true, dangerous: false },
  { id: 'perm-2', key: 'auto_publish', name: 'Direct Public Publishing', description: 'Allow AI agent to publish directly without human approval', allowed: false, dangerous: true },
  { id: 'perm-3', key: 'delete_content', name: 'Delete Content', description: 'Allow AI agent to delete articles, categories, or media', allowed: false, dangerous: true },
  { id: 'perm-4', key: 'alter_settings', name: 'Modify System Settings', description: 'Allow AI agent to modify publication metadata or credentials', allowed: false, dangerous: true }
];

const DEFAULT_PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: 'tmpl-1',
    name: 'Tactical Match Forensics Template',
    type: 'article',
    template: 'Analyze the tactical dynamics of the match between {teamA} and {teamB}. Focus on pressing structures, spatial manipulation, rest defense, and the key managerial adjustments made at half-time.',
    description: 'Template for in-depth European matchday tactical forensics.',
    enabled: true
  },
  {
    id: 'tmpl-2',
    name: 'Transfer & PSR Accounting Breakdown',
    type: 'article',
    template: 'Break down the transfer of {player} to {club} with respect to PSR guidelines, amortized fee structure, wages, and squad cost ratio implications.',
    description: 'Template for transfer market financial governance analysis.',
    enabled: true
  }
];

class Database {
  private data!: DatabaseSchema;

  constructor() {
    this.ensureDataDir();
    this.data = this.load();
  }

  private ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);

        // Check if the database has already been updated to football niche
        const isFootballNiche =
          parsed.categories &&
          parsed.categories.some((c: any) => c.slug === 'champions-league' || c.slug === 'premier-league');

        if (isFootballNiche) {
          return {
            users: parsed.users || [],
            categories: parsed.categories || DEFAULT_CATEGORIES,
            tags: parsed.tags || DEFAULT_TAGS,
            articles: parsed.articles || DEFAULT_ARTICLES,
            articleRevisions: parsed.articleRevisions || [],
            rssSources: parsed.rssSources || DEFAULT_RSS_SOURCES,
            rssItems: parsed.rssItems || [],
            topics: parsed.topics || DEFAULT_TOPICS,
            editorialTones: parsed.editorialTones || DEFAULT_EDITORIAL_TONES,
            aiInstructions: parsed.aiInstructions || [],
            promptTemplates: parsed.promptTemplates || DEFAULT_PROMPT_TEMPLATES,
            media: parsed.media || [],
            memoryItems: parsed.memoryItems || DEFAULT_MEMORY_ITEMS,
            automationRules: parsed.automationRules || DEFAULT_AUTOMATION_RULES,
            aiPermissions: parsed.aiPermissions || DEFAULT_PERMISSIONS,
            agentActivityLogs: parsed.agentActivityLogs || [],
            aiUsageLogs: parsed.aiUsageLogs || [],
            settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
            aiProviders: parsed.aiProviders || DEFAULT_AI_PROVIDERS,
            aiTaskRouting: parsed.aiTaskRouting || DEFAULT_TASK_ROUTING,
            researchSources: parsed.researchSources || [],
            workflowDraft: parsed.workflowDraft || null
          };
        }
      } catch (err) {
        console.error('Failed to read database.json, re-seeding football intelligence:', err);
      }
    }

    // Default Football Intelligence Seed
    const initial: DatabaseSchema = {
      users: [
        {
          id: 'user-admin-1',
          email: process.env.ADMIN_EMAIL || 'admin@editorialpulse.com',
          name: 'Marcus Sterling',
          role: 'admin',
          // Default hash for 'admin123'
          passwordHash: '$2a$10$wN8w09T4v9d1jF98s.gXy.kC3qT7.Nq1c1g071L1p5r.x1u1k8a0y',
          createdAt: new Date().toISOString()
        }
      ],
      categories: DEFAULT_CATEGORIES,
      tags: DEFAULT_TAGS,
      articles: DEFAULT_ARTICLES,
      articleRevisions: [],
      rssSources: DEFAULT_RSS_SOURCES,
      rssItems: [],
      topics: DEFAULT_TOPICS,
      editorialTones: DEFAULT_EDITORIAL_TONES,
      aiInstructions: [],
      promptTemplates: DEFAULT_PROMPT_TEMPLATES,
      media: [
        {
          id: 'media-1',
          url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&h=630&fit=crop&q=80',
          title: 'Champions League Stadium Night',
          altText: 'Champions League stadium illuminated for knockout stage football match under floodlights',
          caption: 'European knockout football in full intensity',
          filename: 'champions-league-stadium.jpg',
          mimeType: 'image/jpeg',
          fileSize: 340000,
          width: 1200,
          height: 630,
          uploadedAt: '2026-03-20T10:00:00Z'
        },
        {
          id: 'media-2',
          url: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&h=630&fit=crop&q=80',
          title: 'Premier League Match Pitch',
          altText: 'Tactical whiteboard with player magnets illustrating inverted full-back movements and pitch geometry',
          caption: 'Modern pitch geometry and positional play',
          filename: 'premier-league-tactics.jpg',
          mimeType: 'image/jpeg',
          fileSize: 290000,
          width: 1200,
          height: 630,
          uploadedAt: '2026-03-22T09:00:00Z'
        },
        {
          id: 'media-3',
          url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1200&h=630&fit=crop&q=80',
          title: 'Football Data Scouting Analytics',
          altText: 'Tactical scouting tablet showing heatmaps, passing vectors, and player recruitment metrics',
          caption: 'Data-driven player recruitment models',
          filename: 'scouting-data-analytics.jpg',
          mimeType: 'image/jpeg',
          fileSize: 310000,
          width: 1200,
          height: 630,
          uploadedAt: '2026-03-23T08:00:00Z'
        }
      ],
      memoryItems: DEFAULT_MEMORY_ITEMS,
      automationRules: DEFAULT_AUTOMATION_RULES,
      aiPermissions: DEFAULT_PERMISSIONS,
      agentActivityLogs: [
        {
          id: 'act-1',
          timestamp: new Date().toISOString(),
          agent: 'MAGIC',
          action: 'SYSTEM_BOOTSTRAP',
          targetType: 'system',
          details: 'Initialized The Continental Pitch database with European football categories, tactical topics, and author Marcus Sterling.',
          status: 'SUCCESS'
        }
      ],
      aiUsageLogs: [],
      settings: DEFAULT_SETTINGS,
      aiProviders: DEFAULT_AI_PROVIDERS,
      aiTaskRouting: DEFAULT_TASK_ROUTING,
      researchSources: [],
      workflowDraft: null
    };

    this.saveDirect(initial);
    return initial;
  }

  // Atomic file write using temporary file + rename to prevent corruption
  private save(): void {
    this.saveDirect(this.data);
  }

  private saveDirect(payload: DatabaseSchema): void {
    this.ensureDataDir();
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(payload, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  }

  // --- Article Methods ---

  public getArticles(filters?: { status?: string; categoryId?: string; tag?: string; search?: string }): Article[] {
    let list = [...this.data.articles];
    if (filters?.status) {
      list = list.filter(a => a.status === filters.status);
    }
    if (filters?.categoryId) {
      list = list.filter(a => a.categoryId === filters.categoryId);
    }
    if (filters?.tag) {
      list = list.filter(a => a.tags.some(t => t.toLowerCase() === filters.tag?.toLowerCase()));
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(a =>
        a.title.toLowerCase().includes(q) ||
        a.content.toLowerCase().includes(q) ||
        a.primaryFocusKeyword.toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());
  }

  public getArticleById(id: string): Article | undefined {
    return this.data.articles.find(a => a.id === id);
  }

  public getArticleBySlug(slug: string): Article | undefined {
    return this.data.articles.find(a => a.slug === slug);
  }

  public saveArticle(article: Partial<Article> & { title: string }): Article {
    const now = new Date().toISOString();
    const existingIndex = article.id ? this.data.articles.findIndex(a => a.id === article.id) : -1;

    let finalArticle: Article;

    if (existingIndex >= 0) {
      const existing = this.data.articles[existingIndex];
      if (article.content && article.content !== existing.content) {
        this.addRevision({
          articleId: existing.id,
          author: article.authorName || existing.authorName,
          action: 'Content edited',
          title: existing.title,
          content: existing.content,
          seoScore: existing.aiSeoScore
        });
      }

      finalArticle = {
        ...existing,
        ...article,
        updatedAt: now
      };
      this.data.articles[existingIndex] = finalArticle;
    } else {
      const newId = `art-${Date.now()}`;
      const slug = article.slug || this.generateSlug(article.title);
      finalArticle = {
        id: newId,
        title: article.title,
        slug,
        excerpt: article.excerpt || '',
        leadSummary: article.leadSummary || '',
        content: article.content || '<p></p>',
        featuredImage: article.featuredImage || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=1200&h=630&fit=crop&q=80',
        featuredImageAlt: article.featuredImageAlt || article.title,
        categoryId: article.categoryId || (this.data.categories[0]?.id || 'cat-1'),
        tags: article.tags || [],
        primaryFocusKeyword: article.primaryFocusKeyword || '',
        secondaryKeywords: article.secondaryKeywords || [],
        seoTitle: article.seoTitle || article.title,
        metaDescription: article.metaDescription || article.excerpt || '',
        canonicalUrl: article.canonicalUrl || '',
        authorName: article.authorName || this.data.settings.authorProfile.name,
        authorSlug: article.authorSlug || this.data.settings.authorProfile.slug,
        status: article.status || 'draft',
        scheduledAt: article.scheduledAt,
        publishedAt: article.status === 'published' ? (article.publishedAt || now) : undefined,
        createdAt: now,
        updatedAt: now,
        workflowStage: article.workflowStage || 1,
        aiSeoScore: article.aiSeoScore,
        aiSeoAnalysis: article.aiSeoAnalysis,
        sourceRssId: article.sourceRssId,
        sourceUrl: article.sourceUrl,
        sourceTitle: article.sourceTitle
      };
      this.data.articles.unshift(finalArticle);
    }

    this.save();
    return finalArticle;
  }

  public deleteArticle(id: string): boolean {
    const initialLen = this.data.articles.length;
    this.data.articles = this.data.articles.filter(a => a.id !== id);
    this.data.articleRevisions = this.data.articleRevisions.filter(r => r.articleId !== id);
    if (this.data.articles.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Revisions ---

  public addRevision(params: { articleId: string; author: string; action: string; title: string; content: string; seoScore?: number }): void {
    const rev: ArticleRevision = {
      id: `rev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      articleId: params.articleId,
      timestamp: new Date().toISOString(),
      author: params.author,
      action: params.action,
      title: params.title,
      content: params.content,
      seoScore: params.seoScore
    };
    this.data.articleRevisions.unshift(rev);
    const articleRevs = this.data.articleRevisions.filter(r => r.articleId === params.articleId);
    if (articleRevs.length > 25) {
      const toRemove = articleRevs.slice(25).map(r => r.id);
      this.data.articleRevisions = this.data.articleRevisions.filter(r => !toRemove.includes(r.id));
    }
    this.save();
  }

  public getArticleRevisions(articleId: string): ArticleRevision[] {
    return this.data.articleRevisions.filter(r => r.articleId === articleId);
  }

  public restoreRevision(articleId: string, revisionId: string): Article | null {
    const rev = this.data.articleRevisions.find(r => r.id === revisionId && r.articleId === articleId);
    const art = this.data.articles.find(a => a.id === articleId);
    if (!rev || !art) return null;

    this.addRevision({
      articleId: art.id,
      author: 'Editor (Pre-Restore)',
      action: `Snapshot before restoring revision from ${new Date(rev.timestamp).toLocaleString()}`,
      title: art.title,
      content: art.content,
      seoScore: art.aiSeoScore
    });

    art.title = rev.title;
    art.content = rev.content;
    art.updatedAt = new Date().toISOString();
    this.save();
    return art;
  }

  // --- Category Methods ---

  public getCategories(): Category[] {
    const articles = this.data.articles;
    return this.data.categories.map(c => ({
      ...c,
      articleCount: articles.filter(a => a.categoryId === c.id).length
    }));
  }

  public getCategoryById(id: string): Category | undefined {
    return this.data.categories.find(c => c.id === id);
  }

  public getCategoryBySlug(slug: string): Category | undefined {
    return this.data.categories.find(c => c.slug === slug);
  }

  public saveCategory(category: Partial<Category> & { name: string }): Category {
    const existingIndex = category.id ? this.data.categories.findIndex(c => c.id === category.id) : -1;
    const slug = category.slug ? this.generateSlug(category.slug) : this.generateSlug(category.name);

    if (existingIndex >= 0) {
      const updated: Category = {
        ...this.data.categories[existingIndex],
        ...category,
        slug
      };
      this.data.categories[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: Category = {
        id: `cat-${Date.now()}`,
        name: category.name,
        slug,
        description: category.description || '',
        seoTitle: category.seoTitle || `${category.name} | The Continental Pitch`,
        seoDescription: category.seoDescription || category.description || '',
        parentCategoryId: category.parentCategoryId,
        isIndexable: category.isIndexable !== undefined ? category.isIndexable : true,
        imageUrl: category.imageUrl,
        createdAt: new Date().toISOString()
      };
      this.data.categories.push(created);
      this.save();
      return created;
    }
  }

  public deleteCategory(id: string): boolean {
    const initialLen = this.data.categories.length;
    const remaining = this.data.categories.filter(c => c.id !== id);
    if (remaining.length === 0) return false;
    this.data.categories = remaining;
    const fallbackId = remaining[0].id;
    this.data.articles.forEach(a => {
      if (a.categoryId === id) a.categoryId = fallbackId;
    });
    this.save();
    return this.data.categories.length !== initialLen;
  }

  // --- Tag Methods ---

  public getTags(): Tag[] {
    const articles = this.data.articles;
    return this.data.tags.map(t => ({
      ...t,
      articleCount: articles.filter(a =>
        a.tags.some(at => at.toLowerCase() === t.name.toLowerCase() || at.toLowerCase() === t.slug.toLowerCase())
      ).length
    }));
  }

  public saveTag(tagInput: Partial<Tag> & { name: string }): Tag {
    const trimmed = tagInput.name.trim();
    const slug = tagInput.slug ? this.generateSlug(tagInput.slug) : this.generateSlug(trimmed);
    const existingIndex = tagInput.id
      ? this.data.tags.findIndex(t => t.id === tagInput.id)
      : this.data.tags.findIndex(t => t.slug === slug || t.name.toLowerCase() === trimmed.toLowerCase());

    if (existingIndex >= 0) {
      const updated: Tag = {
        ...this.data.tags[existingIndex],
        ...tagInput,
        name: trimmed,
        slug
      };
      this.data.tags[existingIndex] = updated;
      this.save();
      return updated;
    }

    const newTag: Tag = {
      id: `tag-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      name: trimmed,
      slug,
      description: tagInput.description,
      createdAt: new Date().toISOString()
    };
    this.data.tags.push(newTag);
    this.save();
    return newTag;
  }

  public bulkAddTags(input: string): Tag[] {
    const rawTokens = input.split(/[,;\n\r]+/).map(t => t.trim()).filter(t => t.length > 0);
    const unique = Array.from(new Set(rawTokens));
    return unique.map(t => this.saveTag({ name: t }));
  }

  public deleteTag(id: string): boolean {
    const tag = this.data.tags.find(t => t.id === id);
    if (!tag) return false;
    this.data.tags = this.data.tags.filter(t => t.id !== id);
    this.data.articles.forEach(a => {
      a.tags = a.tags.filter(t => t.toLowerCase() !== tag.name.toLowerCase() && t.toLowerCase() !== tag.slug.toLowerCase());
    });
    this.save();
    return true;
  }

  // --- RSS Sources & Items ---

  public getRSSSources(): RSSSource[] {
    return this.data.rssSources;
  }

  public saveRSSSource(source: Partial<RSSSource> & { name: string; url: string }): RSSSource {
    const existingIndex = source.id ? this.data.rssSources.findIndex(s => s.id === source.id) : -1;
    if (existingIndex >= 0) {
      const updated: RSSSource = {
        ...this.data.rssSources[existingIndex],
        ...source
      };
      this.data.rssSources[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: RSSSource = {
        id: `rss-${Date.now()}`,
        name: source.name,
        url: source.url,
        websiteName: source.websiteName || source.name,
        enabled: source.enabled !== undefined ? source.enabled : true,
        defaultCategoryId: source.defaultCategoryId || (this.data.categories[0]?.id || 'cat-1'),
        defaultTags: source.defaultTags || [],
        priority: source.priority || 'medium',
        fetchFrequencyMinutes: source.fetchFrequencyMinutes || 60,
        itemCount: 0,
        createdAt: new Date().toISOString()
      };
      this.data.rssSources.push(created);
      this.save();
      return created;
    }
  }

  public deleteRSSSource(id: string): boolean {
    const initialLen = this.data.rssSources.length;
    this.data.rssSources = this.data.rssSources.filter(s => s.id !== id);
    this.data.rssItems = this.data.rssItems.filter(i => i.sourceId !== id);
    if (this.data.rssSources.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public getRSSItems(filters?: { status?: string; sourceId?: string }): RSSItem[] {
    let list = [...this.data.rssItems];
    if (filters?.status) {
      list = list.filter(i => i.status === filters.status);
    }
    if (filters?.sourceId) {
      list = list.filter(i => i.sourceId === filters.sourceId);
    }
    return list.sort((a, b) => new Date(b.importedAt).getTime() - new Date(a.importedAt).getTime());
  }

  public getRSSItemById(id: string): RSSItem | undefined {
    return this.data.rssItems.find(i => i.id === id);
  }

  public addRSSItems(items: Array<Omit<RSSItem, 'id' | 'importedAt' | 'status'>>): number {
    let addedCount = 0;
    const now = new Date().toISOString();

    for (const item of items) {
      const exists = this.data.rssItems.some(existing => existing.originalUrl === item.originalUrl);
      if (!exists) {
        const newItem: RSSItem = {
          ...item,
          id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          importedAt: now,
          status: 'NEW'
        };
        this.data.rssItems.unshift(newItem);
        addedCount++;
      }
    }

    if (addedCount > 0) {
      this.save();
    }
    return addedCount;
  }

  public updateRSSItem(id: string, updates: Partial<RSSItem>): RSSItem | null {
    const item = this.data.rssItems.find(i => i.id === id);
    if (!item) return null;
    Object.assign(item, updates);
    this.save();
    return item;
  }

  public deleteRSSItem(id: string): boolean {
    const initialLen = this.data.rssItems.length;
    this.data.rssItems = this.data.rssItems.filter(i => i.id !== id);
    if (this.data.rssItems.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Topics ---

  public getTopics(): Topic[] {
    return this.data.topics;
  }

  public saveTopic(topic: Partial<Topic> & { name: string }): Topic {
    const existingIndex = topic.id ? this.data.topics.findIndex(t => t.id === topic.id) : -1;
    if (existingIndex >= 0) {
      const updated: Topic = { ...this.data.topics[existingIndex], ...topic };
      this.data.topics[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: Topic = {
        id: `top-${Date.now()}`,
        name: topic.name,
        description: topic.description || '',
        keywords: topic.keywords || [],
        secondaryKeywords: topic.secondaryKeywords || [],
        searchIntent: topic.searchIntent || 'Informational',
        targetAudience: topic.targetAudience || 'Football followers & analysts',
        associatedCategoryIds: topic.associatedCategoryIds || [],
        priority: topic.priority || 'medium',
        enabled: topic.enabled !== undefined ? topic.enabled : true,
        instructions: topic.instructions || '',
        autoPublishEnabled: topic.autoPublishEnabled || false,
        minSeoScore: topic.minSeoScore || 85
      };
      this.data.topics.push(created);
      this.save();
      return created;
    }
  }

  public deleteTopic(id: string): boolean {
    const initialLen = this.data.topics.length;
    this.data.topics = this.data.topics.filter(t => t.id !== id);
    if (this.data.topics.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Editorial Tones ---

  public getEditorialTones(): EditorialTone[] {
    return this.data.editorialTones;
  }

  public saveEditorialTone(tone: Partial<EditorialTone> & { name: string; prompt: string }): EditorialTone {
    const existingIndex = tone.id ? this.data.editorialTones.findIndex(t => t.id === tone.id) : -1;
    if (existingIndex >= 0) {
      const updated: EditorialTone = { ...this.data.editorialTones[existingIndex], ...tone };
      if (updated.isDefault) {
        this.data.editorialTones.forEach(t => { if (t.id !== updated.id) t.isDefault = false; });
      }
      this.data.editorialTones[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: EditorialTone = {
        id: `tone-${Date.now()}`,
        name: tone.name,
        description: tone.description || '',
        prompt: tone.prompt,
        isDefault: tone.isDefault || false,
        enabled: tone.enabled !== undefined ? tone.enabled : true
      };
      if (created.isDefault) {
        this.data.editorialTones.forEach(t => { t.isDefault = false; });
      }
      this.data.editorialTones.push(created);
      this.save();
      return created;
    }
  }

  public deleteEditorialTone(id: string): boolean {
    if (this.data.editorialTones.length <= 1) return false;
    const initialLen = this.data.editorialTones.length;
    this.data.editorialTones = this.data.editorialTones.filter(t => t.id !== id);
    if (this.data.editorialTones.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Instructions ---

  public getAIInstructions(): AIInstruction[] {
    return this.data.aiInstructions;
  }

  public saveAIInstruction(inst: Partial<AIInstruction> & { title: string; instruction: string }): AIInstruction {
    const existingIndex = inst.id ? this.data.aiInstructions.findIndex(i => i.id === inst.id) : -1;
    if (existingIndex >= 0) {
      const updated = { ...this.data.aiInstructions[existingIndex], ...inst };
      this.data.aiInstructions[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: AIInstruction = {
        id: `inst-${Date.now()}`,
        level: inst.level || 'global',
        targetId: inst.targetId,
        targetName: inst.targetName,
        title: inst.title,
        instruction: inst.instruction,
        enabled: inst.enabled !== undefined ? inst.enabled : true,
        createdAt: new Date().toISOString()
      };
      this.data.aiInstructions.push(created);
      this.save();
      return created;
    }
  }

  public deleteAIInstruction(id: string): boolean {
    const initialLen = this.data.aiInstructions.length;
    this.data.aiInstructions = this.data.aiInstructions.filter(i => i.id !== id);
    if (this.data.aiInstructions.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public composeInstructions(options: { categoryId?: string; topic?: string } = {}): string {
    const parts: string[] = [];

    // Global instructions
    const globalInst = this.data.aiInstructions.filter(i => i.enabled && i.level === 'global');
    if (globalInst.length > 0) {
      parts.push('### Editorial Directives:\n' + globalInst.map(i => `- ${i.title}: ${i.instruction}`).join('\n'));
    }

    // Category instructions
    if (options.categoryId) {
      const catInst = this.data.aiInstructions.filter(i => i.enabled && i.level === 'category' && i.targetId === options.categoryId);
      if (catInst.length > 0) {
        parts.push('### Desk-Specific Guidelines:\n' + catInst.map(i => `- ${i.title}: ${i.instruction}`).join('\n'));
      }
    }

    // Topic instructions
    if (options.topic) {
      const topicInst = this.data.aiInstructions.filter(i => i.enabled && i.level === 'topic' && (i.targetName === options.topic || i.targetId === options.topic));
      if (topicInst.length > 0) {
        parts.push('### Topical Focus Instructions:\n' + topicInst.map(i => `- ${i.title}: ${i.instruction}`).join('\n'));
      }
    }

    // Guidelines from memory
    const guidelines = this.data.memoryItems.filter(m => m.type === 'guideline');
    if (guidelines.length > 0) {
      parts.push('### Publication Constitution & Tone Memory:\n' + guidelines.map(g => `[${g.title}]: ${g.content}`).join('\n'));
    }

    return parts.join('\n\n');
  }

  // --- AI Providers ---

  public getAIProviders(): AIProviderConfig[] {
    if (!this.data.aiProviders) {
      this.data.aiProviders = [...DEFAULT_AI_PROVIDERS];
    }
    return this.data.aiProviders;
  }

  public saveAIProvider(provider: Partial<AIProviderConfig> & { id: string }): AIProviderConfig {
    if (!this.data.aiProviders) this.data.aiProviders = [...DEFAULT_AI_PROVIDERS];
    const idx = this.data.aiProviders.findIndex(p => p.id === provider.id);
    if (idx >= 0) {
      const updated = { ...this.data.aiProviders[idx], ...provider };
      if (updated.isDefault) {
        this.data.aiProviders.forEach(p => { if (p.id !== updated.id) p.isDefault = false; });
      }
      this.data.aiProviders[idx] = updated;
      this.save();
      return updated;
    } else {
      const created: AIProviderConfig = {
        id: provider.id || `prov-${Date.now()}`,
        provider: provider.provider || 'gemini',
        name: provider.name || 'Custom Provider',
        apiKey: provider.apiKey || '',
        model: provider.model || 'gemini-3.8-flash',
        endpoint: provider.endpoint || '',
        temperature: provider.temperature ?? 0.7,
        maxTokens: provider.maxTokens ?? 4096,
        timeoutMs: provider.timeoutMs ?? 30000,
        enabled: provider.enabled ?? true,
        isDefault: provider.isDefault ?? false,
        isFallback: provider.isFallback ?? false
      };
      this.data.aiProviders.push(created);
      this.save();
      return created;
    }
  }

  public deleteAIProvider(id: string): boolean {
    if (!this.data.aiProviders) return false;
    const initialLen = this.data.aiProviders.length;
    this.data.aiProviders = this.data.aiProviders.filter(p => p.id !== id);
    if (this.data.aiProviders.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Task Routing ---

  public getTaskRouting(): AITaskRouting {
    return this.data.aiTaskRouting || DEFAULT_TASK_ROUTING;
  }

  public saveTaskRouting(routing: Partial<AITaskRouting>): AITaskRouting {
    this.data.aiTaskRouting = {
      ...(this.data.aiTaskRouting || DEFAULT_TASK_ROUTING),
      ...routing
    };
    this.save();
    return this.data.aiTaskRouting;
  }

  // --- Research Sources ---

  public getResearchSources(): ResearchSourceItem[] {
    return this.data.researchSources || [];
  }

  public saveResearchSource(source: ResearchSourceItem): ResearchSourceItem {
    if (!this.data.researchSources) this.data.researchSources = [];
    const idx = this.data.researchSources.findIndex(s => s.id === source.id || s.url === source.url);
    if (idx >= 0) {
      this.data.researchSources[idx] = { ...this.data.researchSources[idx], ...source };
    } else {
      this.data.researchSources.unshift(source);
    }
    this.save();
    return source;
  }

  public deleteResearchSource(id: string): boolean {
    if (!this.data.researchSources) return false;
    const initialLen = this.data.researchSources.length;
    this.data.researchSources = this.data.researchSources.filter(s => s.id !== id);
    if (this.data.researchSources.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Workflow Draft (Autosave & Persistence) ---

  public getWorkflowDraft(): WorkflowDraftState | null {
    return this.data.workflowDraft || null;
  }

  public saveWorkflowDraft(draft: WorkflowDraftState): WorkflowDraftState {
    this.data.workflowDraft = {
      ...draft,
      lastSavedAt: new Date().toISOString()
    };
    this.save();
    return this.data.workflowDraft;
  }

  public clearWorkflowDraft(): boolean {
    this.data.workflowDraft = null;
    this.save();
    return true;
  }

  // --- Prompt Templates ---

  public getPromptTemplates(): PromptTemplate[] {
    return this.data.promptTemplates;
  }

  public savePromptTemplate(template: Partial<PromptTemplate> & { name: string; template: string }): PromptTemplate {
    const existingIndex = template.id ? this.data.promptTemplates.findIndex(t => t.id === template.id) : -1;
    if (existingIndex >= 0) {
      const updated = { ...this.data.promptTemplates[existingIndex], ...template };
      this.data.promptTemplates[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: PromptTemplate = {
        id: template.id || `tmpl-${Date.now()}`,
        name: template.name,
        type: template.type || 'article',
        template: template.template,
        description: template.description || '',
        enabled: template.enabled !== undefined ? template.enabled : true
      };
      this.data.promptTemplates.push(created);
      this.save();
      return created;
    }
  }

  public deletePromptTemplate(id: string): boolean {
    const initialLen = this.data.promptTemplates.length;
    this.data.promptTemplates = this.data.promptTemplates.filter(t => t.id !== id);
    if (this.data.promptTemplates.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Media Library ---

  public getMedia(): MediaItem[] {
    return this.data.media;
  }

  public saveMedia(item: Omit<MediaItem, 'id' | 'uploadedAt'> & { id?: string }): MediaItem {
    const existingIndex = item.id ? this.data.media.findIndex(m => m.id === item.id) : -1;
    if (existingIndex >= 0) {
      const updated = { ...this.data.media[existingIndex], ...item };
      this.data.media[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: MediaItem = {
        ...item,
        id: `media-${Date.now()}`,
        uploadedAt: new Date().toISOString()
      };
      this.data.media.unshift(created);
      this.save();
      return created;
    }
  }

  public saveMediaItem(item: any): MediaItem {
    return this.saveMedia(item);
  }

  public updateMediaItem(id: string, item: any): MediaItem | null {
    return this.saveMedia({ ...item, id });
  }

  public deleteMedia(id: string): boolean {
    const initialLen = this.data.media.length;
    this.data.media = this.data.media.filter(m => m.id !== id);
    if (this.data.media.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public deleteMediaItem(id: string): boolean {
    return this.deleteMedia(id);
  }

  // --- Memory ---

  public getMemoryItems(search?: string): MemoryItem[] {
    if (!search) return this.data.memoryItems;
    const q = search.toLowerCase();
    return this.data.memoryItems.filter(m =>
      m.title.toLowerCase().includes(q) ||
      m.content.toLowerCase().includes(q) ||
      m.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  public saveMemoryItem(item: Partial<MemoryItem> & { title: string; content: string }): MemoryItem {
    const existingIndex = item.id ? this.data.memoryItems.findIndex(m => m.id === item.id) : -1;
    const now = new Date().toISOString();
    if (existingIndex >= 0) {
      const updated = {
        ...this.data.memoryItems[existingIndex],
        ...item,
        lastUpdated: now
      };
      this.data.memoryItems[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: MemoryItem = {
        id: `mem-${Date.now()}`,
        title: item.title,
        type: item.type || 'guideline',
        content: item.content,
        tags: item.tags || [],
        lastUpdated: now
      };
      this.data.memoryItems.push(created);
      this.save();
      return created;
    }
  }

  public deleteMemoryItem(id: string): boolean {
    const initialLen = this.data.memoryItems.length;
    this.data.memoryItems = this.data.memoryItems.filter(m => m.id !== id);
    if (this.data.memoryItems.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public clearAllMemory(): void {
    this.data.memoryItems = [];
    this.save();
  }

  // --- Automation Rules & Permissions ---

  public getAutomationRules(): AutomationRule[] {
    return this.data.automationRules;
  }

  public saveAutomationRule(rule: Partial<AutomationRule> & { name: string }): AutomationRule {
    const existingIndex = rule.id ? this.data.automationRules.findIndex(r => r.id === rule.id) : -1;
    if (existingIndex >= 0) {
      const updated = { ...this.data.automationRules[existingIndex], ...rule };
      this.data.automationRules[existingIndex] = updated;
      this.save();
      return updated;
    } else {
      const created: AutomationRule = {
        id: rule.id || `rule-${Date.now()}`,
        name: rule.name,
        enabled: rule.enabled !== undefined ? rule.enabled : true,
        mode: rule.mode || 'manual',
        minAiSeoScore: rule.minAiSeoScore ?? 85,
        requireFeaturedImage: rule.requireFeaturedImage ?? true,
        requireMetaDescription: rule.requireMetaDescription ?? true,
        requireFocusKeywordInTitle: rule.requireFocusKeywordInTitle ?? true,
        requireTagsCount: rule.requireTagsCount ?? 1,
        allowedCategories: rule.allowedCategories ?? []
      };
      this.data.automationRules.push(created);
      this.save();
      return created;
    }
  }

  public deleteAutomationRule(id: string): boolean {
    const initialLen = this.data.automationRules.length;
    this.data.automationRules = this.data.automationRules.filter(r => r.id !== id);
    if (this.data.automationRules.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }


  public getAIPermissions(): AIPermission[] {
    return this.data.aiPermissions;
  }

  public updateAIPermission(key: string, allowed: boolean): AIPermission | null {
    const perm = this.data.aiPermissions.find(p => p.key === key);
    if (!perm) return null;
    perm.allowed = allowed;
    this.save();
    return perm;
  }

  public checkPermission(key: string): boolean {
    const perm = this.data.aiPermissions.find(p => p.key === key);
    return perm ? perm.allowed : false;
  }

  // --- Logs ---

  public logAgentActivity(activity: Omit<AgentActivityLog, 'id' | 'timestamp'>): AgentActivityLog {
    const log: AgentActivityLog = {
      ...activity,
      id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    this.data.agentActivityLogs.unshift(log);
    if (this.data.agentActivityLogs.length > 200) {
      this.data.agentActivityLogs = this.data.agentActivityLogs.slice(0, 200);
    }
    this.save();
    return log;
  }

  public getAgentActivityLogs(): AgentActivityLog[] {
    return this.data.agentActivityLogs;
  }

  public logAIUsage(usage: Omit<AIUsageLog, 'id' | 'timestamp'>): AIUsageLog {
    const log: AIUsageLog = {
      ...usage,
      id: `ai-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    this.data.aiUsageLogs.unshift(log);
    if (this.data.aiUsageLogs.length > 200) {
      this.data.aiUsageLogs = this.data.aiUsageLogs.slice(0, 200);
    }
    this.save();
    return log;
  }

  public getAIUsageLogs(): AIUsageLog[] {
    return this.data.aiUsageLogs;
  }

  // --- Settings ---

  public getSettings(): SiteSettings {
    return this.data.settings;
  }

  public updateSettings(updates: Partial<SiteSettings>): SiteSettings {
    this.data.settings = {
      ...this.data.settings,
      ...updates
    };
    this.save();
    return this.data.settings;
  }

  // --- Users ---

  public findUserByEmail(email: string): User | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public getUserById(id: string): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  // Helper
  private generateSlug(text: string): string {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
}

export const db = new Database();
